<?php

    namespace MyApp;

	/**
	 * Template Helper
	 *
	 * It provides helper methods for use inside templates.  This
	 * helper should only be used inside templates.
	 *
	 * @version 1.0
	 */
	final class Template
	{
		/**
		 * creates a link tag for any controller
		 *
		 * @param string $title	title of link
		 * @param string $page name of page
		 * @param array $args array of args
		 * @return string
		 */
		static public function linkTo($title, $page, array $args = array())
		{
			$uri = \htmlentities(\System\HTTPAppServlet::getInstance()->getPageURI($page, $args));
			$title = \htmlentities($title);
			$response = new \System\IO\HTTPResponse();
			$response->write("<a href=\"{$uri}\" title=\"{$title}\">{$title}</a>");
			$response->send();
		}


		/**
		 * outputs the application base uri
		 *
		 * @return string
		 */
		static public function baseURI()
		{
			$uri = \htmlentities(\System\HTTPAppServlet::getInstance()->config->uri);
			$response = new \System\IO\HTTPResponse();
			$response->write($uri);
			$response->send();
		}


		/**
		 * outputs the application base uri
		 *
		 * @param string $page name of page
		 * @param array $args array of parameters
		 * @return string
		 */
		static public function pageURI($page, array $args = array())
		{
			$uri = \System\HTTPAppServlet::getInstance()->getPageURI($page, $args);
			$response = new \System\IO\HTTPResponse();
			$response->write($uri);
			$response->send();
		}
	}
?>