<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Collections;


	/**
	 * Represents a collection of keys
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class KeyCollection extends CollectionBase
	{
		/**
		 * return key at a specified index
		 *
		 * @param  int		$index			index of item
		 * @return string				   key
		 */
		public function itemAt( $index )
		{
			return parent::itemAt($index);
		}
	}
?>