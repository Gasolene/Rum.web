<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\Events;
	use \System\Events\EventBase;


	/**
	 * Provides event handling
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class MasterViewLoadEvent extends EventBase
	{
		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function MasterViewLoadEvent()
		{
			parent::EventBase("onMasterViewLoad");
		}
	}
?>