<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a LoginForm
	 *
	 * @property string $invalidCredentialsMsg Specifies the message when login failed
	 * @property string $emailNotFoundMsg Specifies the message when email address is not found
	 * @property string $passwordResetSentMsg Specifies the message when password reset has been sent
	 * @property string $passwordResetMsg Specifies the message when password has been reset
	 * @property string $emailFromAddress Specifies the from address of the email message
	 * @property string $emailSubject Specifies the subject line of the email message
	 * @property IMailClient $mailClient Specifies the mail client to send the message with
	 * @property TextBox $username username control
	 * @property TextBox $password password control
	 * @property TextBox $new_password new password control when reseting password
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class LoginForm extends Form
	{
		/**
		 * specifies the message when login failed
		 * @var string
		 */
		protected $invalidCredentialsMsg		= 'Invalid credentials';

		/**
		 * specifies the message when email address does not exist
		 * @var string
		 */
		protected $emailNotFoundMsg				= 'No account with that email address was found';

		/**
		 * specifies the message when email address does not exist
		 * @var string
		 */
		protected $passwordResetSentMsg			= 'Your account password has been sent to the email address specified';

		/**
		 * specifies the message when email address does not exist
		 * @var string
		 */
		protected $passwordResetMsg				= 'Your account password has been reset';

		/**
		 * Specifies the from address when email is sent
		 * @var string
		 */
		protected $emailFromAddress				= 'no-reply@localhost.local';

		/**
		 * Specifies the subject line when email is sent
		 * @var string
		 */
		protected $emailSubject					= 'Password reset confirmation';

		/**
		 * Specifies the mail client for sending
		 * @var IMailClient
		 */
		protected $mailClient;


		/**
		 * Constructor
		 *
		 * @param  string   $controlId  Control Id
		 *
		 * @return void
		 */
		public function LoginForm( $controlId )
		{
			parent::__construct( $controlId );

			$this->mailClient = new \System\Comm\Mail\PHPMailClient();
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'invalidCredentialsMsg' )
			{
				$this->invalidCredentialsMsg = (string)$value;
			}
			elseif( $field === 'emailNotFoundMsg' )
			{
				$this->emailNotFoundMsg = (string)$value;
			}
			elseif( $field === 'passwordResetSentMsg' )
			{
				$this->passwordResetSentMsg = (string)$value;
			}
			elseif( $field === 'passwordResetMsg' )
			{
				$this->passwordResetMsg = (string)$value;
			}
			elseif( $field === 'emailFromAddress' )
			{
				$this->emailFromAddress = (string)$value;
			}
			elseif( $field === 'emailSubject' )
			{
				$this->emailSubject = (string)$value;
			}
			elseif( $field === 'mailClient' )
			{
				if($value instanceof \System\Comm\Mail\IMailClient)
				{
					$this->mailClient = $value;
				}
				else
				{
					throw new \System\BadMemberCallException("mailClient must be type IMailClient");
				}
			}
			else
			{
				parent::__set( $field, $value );
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'invalidCredentialsMsg' )
			{
				return $this->invalidCredentialsMsg;
			}
			elseif( $field === 'emailNotFoundMsg' )
			{
				return $this->emailNotFoundMsg;
			}
			elseif( $field === 'passwordResetSentMsg' )
			{
				return $this->passwordResetSentMsg;
			}
			elseif( $field === 'passwordResetMsg' )
			{
				return $this->passwordResetMsg;
			}
			elseif( $field === 'emailFromAddress' )
			{
				return $this->emailFromAddress;
			}
			elseif( $field === 'emailSubject' )
			{
				return $this->emailSubject;
			}
			elseif( $field === 'mailClient' )
			{
				return $this->mailClient;
			}
			elseif( $field === 'username' )
			{
				return $this->getControl('username');
			}
			elseif( $field === 'password' )
			{
				return $this->getControl('password');
			}
			elseif( $field === 'new_password' )
			{
				return $this->getControl('new_password');
			}
			else
			{
				return parent::__get( $field );
			}
		}


		/**
		 * called when control is initiated
		 *
		 * @return void
		 */
		protected function onInit()
		{
			parent::onInit();

			$this->legend = "Login";
			$this->add( new TextBox( 'username' ));
			$this->add( new TextBox( 'password' ));
			$this->add( new CheckBox( 'permanent' ));
			$this->add( new Button( 'login', 'Login' ));
			$this->add( new Button( 'forgot_password', 'Forgot password' ));

			$this->add( new TextBox( 'email' ));
			$this->add( new Button( 'send_email', 'Reset password' ));

			$this->add( new TextBox( 'new_password' ));
			$this->add( new TextBox( 'confirm_password' ));
			$this->add( new Button( 'reset_password', 'Reset password' ));

			$this->getControl( 'username' )->label = 'User name';
			$this->getControl( 'password' )->label = 'Password';
			$this->getControl( 'password' )->mask = true;
			$this->getControl( 'password' )->enableViewState = false;
			$this->getControl( 'permanent' )->label = 'Remember me';
			$this->getControl( 'forgot_password' )->visible = false;

			$this->getControl( 'email' )->visible = false;
			$this->getControl( 'email' )->enableViewState = false;
			$this->getControl( 'email' )->label = 'Email address';
			$this->getControl( 'send_email' )->visible = false;

			$this->getControl( 'new_password' )->visible = false;
			$this->getControl( 'new_password' )->mask = true;
			$this->getControl( 'new_password' )->enableViewState = false;
			$this->getControl( 'new_password' )->label = 'New password';
			$this->getControl( 'confirm_password' )->visible = false;
			$this->getControl( 'confirm_password' )->mask = true;
			$this->getControl( 'confirm_password' )->enableViewState = false;
			$this->getControl( 'confirm_password' )->label = 'Confirm your password';
			$this->getControl( 'reset_password' )->visible = false;

			$this->new_password->addValidator(new \System\UI\Validators\RequiredValidator());
			$this->new_password->addValidator(new \System\UI\Validators\MatchValidator($this->confirm_password, "Your passwords must match"));
			$this->new_password->addValidator(new \System\UI\Validators\PatternValidator('^(?=.*\d).{6,16}$^', $this->new_password->label . ' must contain 6 to 16 characters with at least one numeric digit'));
		}


		/**
		 * process the HTTP request array
		 *
		 * @param  array	&$request	request array
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			$app = \System\HTTPAppServlet::getInstance();

			foreach($app->config->authenticationCredentialsTables as $table)
			{
				if(isset($table["emailaddress-field"]))
				{
					$this->forgot_password->visible = true;
				}
			}

			if( $this->login->submitted )
			{
				// Authenticate User based on credentials
				if( \System\Security\Authentication::authenticate( $this->getControl( 'username' )->value, $this->getControl( 'password' )->value ))
				{
					// Set Auth Cookie
					\System\Security\FormsAuthentication::redirectFromLoginPage( $this->getControl( 'username' )->value, $this->getControl( 'permanent' )->value );
				}

				// flash invalidCredentials message
				$app->messages->add( new \System\AppMessage( $this->invalidCredentialsMsg, \System\AppMessageType::Notice() )) ;
			}
			elseif( $this->forgot_password->submitted || $this->send_email->submitted )
			{
				// Show password request email form
				$this->legend = "Reset password";
				$this->getControl( 'username' )->visible = false;
				$this->getControl( 'password' )->visible = false;
				$this->getControl( 'permanent' )->visible = false;
				$this->getControl( 'login' )->visible = false;
				$this->getControl( 'login' )->disabled = true;
				$this->getControl( 'forgot_password' )->visible = false;
				$this->getControl( 'forgot_password' )->disabled = true;

				$this->getControl( 'email' )->visible = true;
				$this->getControl( 'send_email' )->visible = true;

				if( $this->send_email->submitted )
				{
					// Send password request email
					$found = false;
					foreach($app->config->authenticationCredentialsTables as $table)
					{
						if( isset( $table['dsn'] )) {
							$ds = \System\Data\DataAdapter::create( $table['dsn'] )->openDataSet( $table['source'] );
						}
						else {
							$ds = $app->dataAdapter->openDataSet( $table['source'] );
						}

						if( $ds->seek( $table['emailaddress-field'], $this->email->value ))
						{
							$found = true;
							$url = __PROTOCOL__ . '://' . __HOST__ . $app->getPageURI( $app->config->authenticationFormsLoginPage, array($this->controlId.'_reset'=>$ds[$table['emailaddress-field']], 'e'=>md5($ds[$table['username-field']].time()), 't'=>time()) );

							$mailMessage = new \System\Comm\Mail\MailMessage();
							$mailMessage->to = $ds[$table["emailaddress-field"]];
							if($this->emailFromAddress)$mailMessage->from = $this->emailFromAddress;
							$mailMessage->subject = $this->emailSubject;
							$mailMessage->body = "<p>Hi {$ds[$table["username-field"]]},</p>
<p>You recently requested a new password.</p>
<p>Please click the link below to complete your new password request:<br />
<a href=\"{$url}\">{$url}</a>
</p>
<p>The link will remain active for one hour.</p>
<p>If you did not authorize this request, please ignore this email.</p>";

							$this->mailClient->send($mailMessage);
							$app->messages->add(new \System\AppMessage($this->passwordResetSentMsg, \System\AppMessageType::Success()));
							$app->setForwardPage($app->config->authenticationFormsLoginPage);
						}
					}

					// No email address found
					if(!$found)
					{
						$app->messages->add(new \System\AppMessage($this->emailNotFoundMsg, \System\AppMessageType::Notice()));
					}
				}
			}
			elseif( isset( $request[$this->controlId . "_reset"] ) && isset( $request["e"] ) && isset( $request["t"] ))
			{
				// show reset password form
				foreach($app->config->authenticationCredentialsTables as $table)
				{
					if( isset( $table['dsn'] )) {
						$ds = \System\Data\DataAdapter::create( $table['dsn'] )->openDataSet( $table['source'] );
					}
					else {
						$ds = $app->dataAdapter->openDataSet( $table['source'] );
					}

					if($ds->seek($table["emailaddress-field"], $request[$this->controlId . "_reset"]))
					{
						$t = $request["t"];
						$e = $request["e"];
						$hash = md5($ds[$table["username-field"]].$t);

						if($hash === $e && $t > time() - 3600)
						{
							if( $this->reset_password->submitted  )
							{
								// Reset password
								if($this->new_password->validate($errMsg))
								{
									$ds[$table["password-field"]] = \System\Security\Authentication::getHash($this->new_password->value);
									$ds->update();

									$app->messages->add(new \System\AppMessage($this->passwordResetMsg, \System\AppMessageType::Success()));
									$app->setForwardPage($app->config->authenticationFormsLoginPage);
								}
								else
								{
									$app->messages->add(new \System\AppMessage($errMsg, \System\AppMessageType::Fail()));
								}
							}

							$this->legend = "Please enter your new password";
							$this->getControl( 'username' )->visible = false;
							$this->getControl( 'password' )->visible = false;
							$this->getControl( 'permanent' )->visible = false;
							$this->getControl( 'login' )->visible = false;
							$this->getControl( 'login' )->disabled = true;
							$this->getControl( 'forgot_password' )->visible = false;
							$this->getControl( 'forgot_password' )->disabled = true;

							$this->getControl( 'new_password' )->visible = true;
							$this->getControl( 'confirm_password' )->visible = true;
							$this->getControl( 'reset_password' )->visible = true;
						}
						else
						{
							$app->messages->add(new \System\AppMessage("The URL is invalid", \System\AppMessageType::Fail()));
						}
					}
					else
					{
						$app->messages->add(new \System\AppMessage($this->emailNotFoundMsg, \System\AppMessageType::Notice()));
					}
				}
			}

			parent::onRequest( $request );
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$dom = parent::getDomObject();
			$dom->appendAttribute( 'class', ' loginform' );
			return $dom;
		}
	}
?>