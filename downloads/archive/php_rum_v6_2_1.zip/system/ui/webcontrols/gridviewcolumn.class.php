<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a GridView column
	 * 
	 * @property string $dataField datefield
	 * @property string $headerText header text
	 * @property string $itemText item text
	 * @property string $footerText footer text
	 * @property string $className class name
	 * @property string $onPostParameter event request parameter
	 * @property EventCollection $events event collection
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class GridViewColumn implements \ArrayAccess
	{
		/**
		 * datefield
		 * @var string
		 */
		protected $dataField			= '';

		/**
		 * header text
		 * @var string
		 */
		protected $headerText			= '';

		/**
		 * item text
		 * @var string
		 */
		protected $itemText				= '';

		/**
		 * footer text
		 * @var string
		 */
		protected $footerText			= '';

		/**
		 * class name
		 * @var string
		 */
		protected $className			= '';

		/**
		 * event request parameter
		 * @var string
		 */
		protected $onPostParameter			= '';

		/**
		 * event collection
		 * @var EventCollection
		 */
		protected $events				= null;


		/**
		 * @param  string		$dataField			name of data field to bind column to
		 * @param  string		$headerText			column header text
		 * @param  string		$itemText			column item text (can be formatted)
		 * @param  string		$footerText			column footer text
		 * @param  string		$className			column css class name
		 * @return void
		 */
		public function GridViewColumn( $dataField, $headerText = '', $itemText = '', $footerText = '', $className = '' )
		{
			$this->dataField = (string) $dataField;
			$this->headerText = (string) $headerText?$headerText:$dataField;
			$this->itemText = (string) $itemText;
			$this->footerText = (string) $footerText;
			$this->className = (string) $className;
			$this->events = new \System\Events\EventCollection();

			// event handling
			$this->events->add(new \System\UI\Events\GridViewColumnPostEvent());
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return void
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'dataField' ) {
				return $this->dataField;
			}
			elseif( $field === 'headerText' ) {
				return $this->headerText;
			}
			elseif( $field === 'itemText' ) {
				return $this->itemText;
			}
			elseif( $field === 'footerText' ) {
				return $this->footerText;
			}
			elseif( $field === 'className' ) {
				return $this->className;
			}
			elseif( $field === 'onPostParameter' ) {
				return $this->onPostParameter;
			}
			elseif( $field === 'events' ) {
				return $this->events;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return void
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'dataField' ) {
				$this->dataField = (string) $value;
			}
			elseif( $field === 'headerText' ) {
				$this->headerText = (string) $value;
			}
			elseif( $field === 'itemText' ) {
				$this->itemText = (string) $value;
			}
			elseif( $field === 'footerText' ) {
				$this->footerText = (string) $value;
			}
			elseif( $field === 'className' ) {
				$this->className = (string) $value;
			}
			elseif( $field === 'onPostParameter' ) {
				$this->onPostParameter = (string) $value;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		public function offsetExists($index)
		{
			if(\in_array($this->getName($index), array_keys(\get_class_vars(\get_class($this)))))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		public function offsetGet($index)
		{
			if($this->offsetExists($index))
			{
				return $this->{$this->getName($index)};
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		public function offsetSet($index, $item)
		{
			if($this->offsetExists($index))
			{
				$this->{$this->getName($index)} = (string) $item;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		public function offsetUnset($index)
		{
			if($this->offsetExists($index))
			{
				$this->{$this->getName($index)} = null;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * trigger event
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		final public function triggerEvent( &$request )
		{
			if( isset( $request[$this->onPostParameter] ))
			{
				$this->events->raise(new \System\UI\Events\GridViewColumnPostEvent(), $this, $request);
			}
		}


		/**
		 * getName
		 * @param string $index
		 * @return string new index
		 * @ignore
		 */
		private function getName($index)
		{
			if($index=='DataField') return 'dataField';
			elseif($index=='Header-Text') return 'headerText';
			elseif($index=='Item-Text') return 'itemText';
			elseif($index=='Footer-Text') return 'footerText';
			elseif($index=='Classname') return 'className';
			else {throw new \Exception("{$index} is not a valid property");}
		}
	}
?>