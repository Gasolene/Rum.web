<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a ListBox Control
	 *
	 * @property int $listSize Size of listbox
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class ListBox extends ListControlBase
	{
		/**
		 * Size of listbox, default is 6
		 * @var int
		 */
		protected $listSize				= 6;

		/**
		 * specify javascript to execute on change
		 * @var string
		 */
		private $_onchange			= '';


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'listSize' )
			{
				return $this->listSize;
			}
			else
			{
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'listSize' )
			{
				$this->listSize = (int)$value;
			}
			else
			{
				parent::__set($field,$value);
			}
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			parent::onLoad();

			if( $this->renderMode == RenderMode::AJAX() )
			{
				$page = $this->getParentByType( '\System\UI\WebControls\Page' );

				$page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/init.js' );
				$this->_onchange = $this->ajaxHTTPRequest . ' = PHPRum.sendHttpRequest( \'' . $this->ajaxCallback . '\', \'' . \System\HTTPAppServlet::getInstance()->config->requestParameter.'='.\System\HTTPAppServlet::getInstance()->thisPage.'&'.$this->getHTMLControlIdString().'__post=1&'.$this->getHTMLControlIdString().'=\'+this.value+\'&' . \System\AppServlet::getInstance()->config->asyncParameter . '=null\', \'get\', ' . ( $this->ajaxEventHandler?'\'' . addslashes( (string) $this->ajaxEventHandler ) . '\'':'null' ) . ' ); return false;';
			}
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$select = $this->createDomObject( 'select' );
			$select->setAttribute( 'id', $this->getHTMLControlIdString());
			$select->appendAttribute( 'class', ' listbox' );
			$select->setAttribute( 'size', $this->listSize );

			if( $this->multiple )
			{
				$select->setAttribute( 'multiple', 'multiple' );
				$select->setAttribute( 'name', $this->getHTMLControlIdString() .'[]' );
			}
			else
			{
				$select->setAttribute( 'name', $this->getHTMLControlIdString());
			}

			if( $this->submitted && !$this->validate() )
			{
				$select->appendAttribute( 'class', ' invalid' );
			}

			if( $this->autoPostBack )
			{
				$select->appendAttribute( 'onchange', 'document.getElementById(\''.$this->getParentByType( '\System\UI\WebControls\Form')->getHTMLControlIdString().'\').submit();' );
			}

			if( $this->readonly )
			{
				$select->setAttribute( 'disabled', 'disabled' );
			}

			if( $this->disabled )
			{
				$select->setAttribute( 'disabled', 'disabled' );
			}

			if( !$this->visible )
			{
				$select->setAttribute( 'style', 'display: none;' );
			}

			if( $this->_onchange )
			{
				$select->appendAttribute( 'onchange', $this->_onchange );
			}

			// create options
			$keys = $this->items->keys;
			$values = $this->items->values;

			for( $i = 0, $count = $this->items->count; $i < $count; $i++ )
			{
				$option = '<option';

				if( is_array( $this->value ))
				{
					if( array_search( $values[$i], $this->value ) !== false )
					{
						$option .= ' selected="selected"';
					}
				}
				else
				{
					if( $this->value === $values[$i])
					{
						$option .= ' selected="selected"';
					}
				}

				$option .= ' value="' . $values[$i] . '">';
				$option .= $keys[$i] . '</option>';

				$select->innerHtml .= $option;
			}

			return $select;
		}
	}
?>