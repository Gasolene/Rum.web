<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents an Page Control
	 *
	 * @property string $docType Specifies document type
	 * @property string $lang Specifies the language code
	 * @property string $xmlns Specifies the xml namespace
	 * @property string $title Specifies document title
	 * @property string $onload Specifies jscript events for page load
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class Page extends View
	{
		/**
		 * specifies content-Type
		 * @var string
		 */
		protected $contentType			= 'text/html';

		/**
		 * specify charset, default is utf-8
		 * @var string
		 */
		protected $charset				= 'utf-8';

		/**
		 * specify docType
		 * @var string
		 */
		protected $docType				= '<!DOCTYPE html>';

		/**
		 * specify language code
		 * @var string
		 */
		protected $lang					= 'en';

		/**
		 * specify xml namespace
		 * @var string
		 */
		protected $xmlns				= '';

		/**
		 * specify title of page document
		 * @var string
		 */
		protected $title				= '';

		/**
		 * specify javascript to execute on page load
		 * @var string
		 */
		protected $onload				= '';

		/**
		 * array of script elements
		 * @var array
		 */
		protected $scriptElements		= array();

		/**
		 * array of meta elements
		 * @var array
		 */
		protected $metaElements			= array();

		/**
		 * array of link elements
		 * @var array
		 */
		protected $linkElements			= array();

		/**
		 * array of object elements
		 * @var array
		 */
		protected $objectElements		= array();

		/**
		 * array of comments to include
		 * @var array
		 */
		protected $comments				= array();

		/**
		 * specifies whether object is currently rendering
		 * @var bool
		 */
		private $_rendering				= false;


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'docType' ) {
				return $this->docType;
			}
			elseif( $field === 'lang' ) {
				return $this->lang;
			}
			elseif( $field === 'xmlns' ) {
				return $this->xmlns;
			}
			elseif( $field === 'title' ) {
				return $this->title;
			}
			elseif( $field === 'onload' ) {
				return $this->onload;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'docType' ) {
				$this->docType = (string)$value;
			}
			elseif( $field === 'lang' ) {
				$this->lang = (string)$value;
			}
			elseif( $field === 'xmlns' ) {
				$this->xmlns = (string)$value;
			}
			elseif( $field === 'title' ) {
				$this->title = (string)$value;
			}
			elseif( $field === 'onload' ) {
				$this->onload = (string)$value;
			}
			else {
				parent::__set($field,$value);
			}
		}


		/**
		 * sets the controlId and prepares the control attributes
		 *
		 * @param  string   $controlId  Control Id
		 * @return void
		 */
		public function Page( $controlId )
		{
			parent::WebControlBase($controlId);

			// event handling
			$this->events->add(new \System\UI\Events\PageCreateEvent());
			$this->events->add(new \System\UI\Events\PageInitEvent());
			$this->events->add(new \System\UI\Events\PageLoadEvent());
			$this->events->add(new \System\UI\Events\PageRequestEvent());
			$this->events->add(new \System\UI\Events\PagePostEvent());
			$this->events->add(new \System\UI\Events\PagePreRenderEvent());

			if(__BACKWARDS_COMPATIBILITY_MODE__)
			{
				$onInitMethod = 'oldInit';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onInitMethod))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageInitEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onInitMethod));
				}
				$onLoad = 'oldLoad';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onLoad))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageLoadEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onLoad));
				}
				$onRequest = 'oldRequest';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onRequest))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageRequestEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onRequest));
				}
				$onPost = 'oldPost';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPost))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PagePostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPost));
				}
				$onPreRender = 'oldPreRender';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPreRender))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PagePreRenderEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPreRender));
				}
			}
			else
			{
				$onCreateMethod = 'on'.ucwords($this->controlId).'Create';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onCreateMethod))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageCreateEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onCreateMethod));
				}
				$onInitMethod = 'on'.ucwords($this->controlId).'Init';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onInitMethod))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageInitEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onInitMethod));
				}
				$onLoad = 'on'.ucwords($this->controlId).'Load';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onLoad))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageLoadEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onLoad));
				}
				$onRequest = 'on'.ucwords($this->controlId).'Request';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onRequest))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PageRequestEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onRequest));
				}
				$onPost = 'on'.ucwords($this->controlId).'Post';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPost))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PagePostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPost));
				}
				$onPreRender = 'on'.ucwords($this->controlId).'PreRender';
				if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPreRender))
				{
					$this->events->registerEventHandler(new \System\UI\Events\PagePreRenderEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPreRender));
				}
			}

			$this->events->raise(new \System\UI\Events\PageCreateEvent(), $this);
		}


		/**
		 * add metatag
		 *
		 * @param   string		$name			the meta tag name to add
		 * @param   string		$content		the meta tag content value to add
		 * @return  int
		 */
		public function addMetaTag( $name, $content )
		{
			if(!$this->_rendering)
			{
				$metaElement = array( 'name' => (string) $name
									, 'content' => (string) $content );

				if( !in_array( $metaElement, $this->metaElements ))
				{
					return (int) array_push( $this->metaElements, $metaElement );
				}
				return 0;
			}
			else
			{
				throw new \System\InvalidOperationException("cannot add meta data while rendering");
			}
		}


		/**
		 * add script element
		 *
		 * @param   string		$src			source
		 * @param   string		$type			type, default is text/javascript
		 * @param   string		$language		script language, default is 'Javascript'
		 * @param   string		$charset		character set, default is iso-8859-1
		 * @return  int
		 */
		public function addScript( $src, $type='text/javascript', $language='Javascript', $charset='iso-8859-1' )
		{
			if(!$this->_rendering)
			{
				$scriptElement = array( 'src' => (string) $src
									  , 'type' => (string) $type
									  , 'language' => (string) $language
									  , 'charset' => (string) $charset );

				if( !in_array( $scriptElement, $this->scriptElements ))
				{
					return (int) array_push( $this->scriptElements, $scriptElement );
				}
				return 0;
			}
			else
			{
				throw new \System\InvalidOperationException("cannot add script while rendering");
			}
		}


		/**
		 * add link element
		 *
		 * @param   string		$href			source
		 * @param   string		$rel			relationship, default is stylesheet
		 * @param   string		$type			type, default is text/css
		 * @param   string		$media			media, default is 'all'
		 * @param   string		$charset		character set, default is iso-8859-1
		 * @return  int
		 */
		public function addLink( $href, $rel='stylesheet', $type='text/css', $media='all', $charset='iso-8859-1' )
		{
			if(!$this->_rendering)
			{
				$linkElement = array( 'href' => (string) $href
									, 'rel' => (string) $rel
									, 'type' => (string) $type
									, 'media' => (string) $media
									, 'charset' => (string) $charset );

				if( !in_array( $linkElement, $this->linkElements ))
				{
					return (int) array_push( $this->linkElements, $linkElement );
				}
				return 0;
			}
			else
			{
				throw new \System\InvalidOperationException("cannot add link while rendering");
			}
		}


		/**
		 * add comment
		 *
		 * @param   string		$comment	the comment to include in the head. note that you should not include any comment delimiters
		 * @return  int
		 */
		public function addComment( $comment )
		{
			if(!$this->_rendering)
			{
				return (int) array_push( $this->comments, str_replace( '--', '', $comment ));
			}
			else
			{
				throw new \System\InvalidOperationException("cannot add comment while rendering");
			}
		}


		/**
		 * returns an html string
		 *
		 * @param   array		$args			widget parameters
		 * @return  string
		 */
		public function fetch( array $args = array() )
		{
			if(!$this->_rendering)
			{
				$content = (string) $this->fetchPageHeader();
				$this->_rendering = true;
				$content .= parent::fetch($args);
				$this->_rendering = false;
				$content .= (string) $this->fetchPageFooter();

				return $content;
			}
			else
			{
				throw new \System\InvalidOperationException("cannot fetch while rendering");
			}
		}


		/**
		 * Event called when control is initiated
		 *
		 * @return void
		 */
		protected function onInit()
        {
			parent::onInit();

			$this->events->raise(new \System\UI\Events\PageInitEvent(), $this);
        }


		/**
		 * Event called when page and all controls are loaded
		 *
		 * @return void
		 */
		protected function onLoad()
        {
			parent::onLoad();

			$this->events->raise(new \System\UI\Events\PageLoadEvent(), $this);
        }


		/**
		 * Event called when request is processed
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			$this->events->raise(new \System\UI\Events\PageRequestEvent(), $this, $request);
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		protected function onPost( array &$request )
		{
			$this->events->raise(new \System\UI\Events\PagePostEvent(), $this, $request);
		}


		/**
		 * handle pre render events
		 *
		 * @return void
		 */
		protected function onPreRender()
		{
			$this->events->raise(new \System\UI\Events\PagePreRenderEvent(), $this);
		}


		/**
		 * return page header
		 *
		 * @return  string
		 */
		protected function fetchPageHeader()
		{
			if(!$this->_rendering)
			{
				ob_start();
?>
<?php echo $this->docType ?>
<?php echo "\n<html lang=\"".$this->lang."\" ".($this->xmlns?"xmlns=\"".$this->xmlns."\"":"").">\n" ?>
<head>
<meta http-equiv="Content-Type" content="<?php echo $this->contentType ?>; charset=<?php echo $this->charset ?>" />
<title><?php echo htmlentities( $this->title ) ?></title>
<?php foreach( $this->metaElements as $metaElement ) : ?>
<meta name="<?php echo htmlentities( $metaElement['name'] ) ?>" content="<?php echo $metaElement['content'] ?>" />
<?php endforeach; ?>
<?php foreach( $this->linkElements as $linkElement ) : ?>
<link href="<?php echo htmlentities( $linkElement['href'] ) ?>" rel="<?php echo htmlentities( $linkElement['rel'] ) ?>" type="<?php echo htmlentities( $linkElement['type'] ) ?>" media="<?php echo htmlentities( $linkElement['media'] ) ?>" />
<?php endforeach; ?>
<?php foreach( $this->scriptElements as $scriptElement ) : ?>
<script src="<?php echo htmlentities( $scriptElement['src'] ) ?>" type="<?php echo htmlentities( $scriptElement['type'] ) ?>"></script>
<?php endforeach; ?>
<?php foreach( $this->comments as $comment ) : ?>
<!--<?php echo $comment ?>-->
<?php endforeach; ?>
<?php if( $this->onload ) : ?>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
window.onload = function () {<?php echo $this->onload ?>};
//--><!]]>
</script>
<?php endif; ?>
</head>
<body>
<?php
				return ob_get_clean();
			}
			else
			{
				throw new \System\InvalidOperationException("cannot fetch while rendering");
			}
		}


		/**
		 * return page footer
		 *
		 * @return  string
		 */
		protected function fetchPageFooter() {

			if(!$this->_rendering)
			{
				ob_start();
?>

</body>
</html>

<?php
				return ob_get_clean();
			}
			else
			{
				throw new \System\InvalidOperationException("cannot fetch while rendering");
			}
		}
	}
?>