<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents the application messages control
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class ApplicationMessages extends WebControlBase
	{
		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$ul = $this->createDomObject('ul');
			$ul->appendAttribute('class', ' messages');

			if( \System\AppServlet::getInstance()->messages->count > 0 )
			{
				foreach(\System\AppServlet::getInstance()->messages as $message)
				{
					if($message->type == \System\AppMessageType::Fail())
					{
						$li = '<li class="fail">';
					}
					elseif($message->type == \System\AppMessageType::Notice())
					{
						$li = '<li class="warning">';
					}
					elseif($message->type == \System\AppMessageType::Success())
					{
						$li = '<li class="success">';
					}
					else
					{
						$li = '<li>';
					}
					$li .= nl2br(htmlentities($message->message)) . '</li>';
					$ul->innerHtml .= $li;
				}
			}
			else
			{
				return new \System\XML\TextNode();
			}

			return $ul;
		}
	}
?>