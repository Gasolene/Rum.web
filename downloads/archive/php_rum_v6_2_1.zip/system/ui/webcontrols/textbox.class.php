<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a TextBox Control
	 *
	 * @property bool $multiline Specifies whether textbox will accept multiple lines of text
	 * @property bool $mask Specifies whether to characters will be masked
	 * @property int $maxLength Specifies Max Length of value when defined
	 * @property bool $disableAutoComplete Specifies whether to disable the browsers auto complete feature
	 * @property bool $disableEnterKey Specifies whether to disable the enter key
	 * @property string $blankFieldText Specifies message to display if field is empty (DHTML mode only)
	 * @property int $size Specifies the size of a textbox
	 * @property int $rows Specifies that number of rows in multiline textbox
	 * @property int $cols Specifies that number of columns in multiline textbox
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class TextBox extends InputBase
	{
		/**
		 * Specifies whether textbox will accept multiple lines of text, default is false
		 * @var bool
		 */
		protected $multiline				= false;

		/**
		 * Specifies whether to characters will be masked, default is false
		 * @var bool
		 */
		protected $mask						= false;

		/**
		 * Max Length of value when set to non zero, default is 0
		 * @var int
		 */
		protected $maxLength				= 0;

		/**
		 * Specifies whether to disable the browsers auto complete feature, default is false
		 * @var bool
		 */
		protected $disableAutoComplete		= false;

		/**
		 * Specifies whether to disable the enter key, default is false
		 * @var bool
		 */
		protected $disableEnterKey			= false;

		/**
		 * Specifies message to display if field is empty
		 * @var string
		 */
		protected $blankFieldText			= '';

		/**
		 * Specifies the size of a textbox, default is 30
		 * @var int
		 */
		protected $size						= 30;

		/**
		 * Specifies that number of rows in multiline textbox, default is 5
		 * @var int
		 */
		protected $rows						= 5;

		/**
		 * Specifies that number of columns in multiline textbox, default is 60
		 * @var int
		 */
		protected $cols						= 60;


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'multiline' ) {
				return $this->multiline;
			}
			elseif( $field === 'mask' ) {
				return $this->mask;
			}
			elseif( $field === 'maxLength' ) {
				return $this->maxLength;
			}
			elseif( $field === 'disableAutoComplete' ) {
				return $this->disableAutoComplete;
			}
			elseif( $field === 'disableEnterKey' ) {
				return $this->disableEnterKey;
			}
			elseif( $field === 'blankFieldText' ) {
				return $this->blankFieldText;
			}
			elseif( $field === 'size' ) {
				return $this->size;
			}
			elseif( $field === 'rows' ) {
				return $this->rows;
			}
			elseif( $field === 'cols' ) {
				return $this->cols;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'multiline' ) {
				$this->multiline = (bool)$value;
			}
			elseif( $field === 'mask' ) {
				$this->mask = (bool)$value;
			}
			elseif( $field === 'maxLength' ) {
				$this->maxLength = (int)$value;
			}
			elseif( $field === 'disableAutoComplete' ) {
				$this->disableAutoComplete = (bool)$value;
			}
			elseif( $field === 'disableEnterKey' ) {
				$this->disableEnterKey = (bool)$value;
			}
			elseif( $field === 'blankFieldText' ) {
				$this->blankFieldText = (string)$value;
			}
			elseif( $field === 'size' ) {
				$this->size = (int)$value;
			}
			elseif( $field === 'rows' ) {
				$this->rows = (int)$value;
			}
			elseif( $field === 'cols' ) {
				$this->cols = (int)$value;
			}
			else {
				parent::__set($field,$value);
			}
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$input = null;

			// create widget
			if( $this->multiline )
			{
				$textarea = $this->createDomObject( 'textarea' );
				$textarea->setAttribute( 'name', $this->getHTMLControlIdString() );
				$textarea->setAttribute( 'id', $this->getHTMLControlIdString() );
				$textarea->appendAttribute( 'class', ' textbox' );
				$textarea->setAttribute( 'cols', $this->cols );
				$textarea->setAttribute( 'rows', $this->rows );
				$textarea->setAttribute( 'title', $this->tooltip );
				$textarea->nodeValue = $this->value;

				if( $this->submitted && !$this->validate() )
				{
					$textarea->appendAttribute( 'class', ' invalid' );
				}

				if( $this->autoPostBack )
				{
					$textarea->appendAttribute( 'onchange', 'document.getElementById(\''.$this->getParentByType( '\System\UI\WebControls\Form')->getHTMLControlIdString().'\').submit();' );
				}

				if( $this->readonly )
				{
					$textarea->setAttribute( 'readonly', 'readonly' );
				}

				if( $this->disabled )
				{
					$textarea->setAttribute( 'disabled', 'disabled' );
				}

				if( !$this->visible )
				{
					$textarea->setAttribute( 'style', 'display: none;' );
				}

				if( $this->maxLength )
				{
					// KLUDGY: -2 is bug fix
					$textarea->appendAttribute( 'onkeyup', 'if(this.value.length > '.(int)($this->maxLength-2).'){ alert(\'You have exceeded the maximum number of characters allowed\'); this.value = this.value.substring(0, '.(int)($this->maxLength-2).') }' );
				}

				$input =& $textarea;
			}
			else
			{
				$input = $this->getInputDomObject();
				$input->setAttribute( 'size', $this->size );
				$input->setAttribute( 'value', $this->value );
				$input->appendAttribute( 'class', ' textbox' );

				if( $this->visible )
				{
					if( $this->mask )
					{
						$input->setAttribute( 'type', 'password' );
					}
					else
					{
						$input->setAttribute( 'type', 'text' );
					}
				}

				if( $this->maxLength )
				{
					$input->setAttribute( 'maxlength', (int)$this->maxLength );
				}
			}

			if( $this->disableEnterKey )
			{
				$input->appendAttribute( 'onkeydown', 'if(event.keyCode==13){return false;}' );
			}

			if( $this->disableAutoComplete )
			{
				$input->setAttribute( 'autocomplete', 'off' ); // not xhtml compliant
			}

			return $input;
		}


		/**
		 * process the HTTP request array
		 *
		 * @param  object	$request	HTTPRequest Object
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( !$this->disabled )
			{
				$page = $this->getParentByType( '\System\UI\WebControls\Page' );
			}

			parent::onRequest( $request );
		}
	}
?>