<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
     * handles date control element creation (string)
	 * abstracts away the presentation logic and data access layer
     * the server-side control for WebWidgets
	 *
     * @property int $yearMin
     * @property int $yearMax
     *
	 * @author			Darnell Shinbine
	 * @copyright		copyright (c) 2007
	 * @version			1.0.0
	 * @package			PHPRum
	 * @subpackage		CommonControls.webcontrols
	 */
	class DateSelector extends InputBase
	{
		/**
		 * specifies the year range
		 * @access protected
		 */
		protected $yearMin				= 1900;

		/**
		 * specifies the year range
		 * @access protected
		 */
		protected $yearMax				= 2020;


		/**
		 * Constructor
		 *
		 * @return void
		 * @access public
		 */
		public function DateSelector( $controlId, $default = null )
		{
			parent::InputBase( $controlId, $default );

			$this->yearMin = (int) date( 'Y', time() ) - 70;
			$this->yearMax = (int) date( 'Y', time() ) + 4;
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @access protected
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field == 'yearMin' ) {
				return $this->yearMin;
			}
			elseif( $field == 'yearMax' ) {
				return $this->yearMax;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * 
		 * @return mixed
		 * @access protected
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field == 'yearMin' ) {
				$this->yearMin = (int)$value;
			}
			elseif( $field == 'yearMax' ) {
				$this->yearMax = (int)$value;
			}
			else {
				parent::__set($field,$value);
			}
		}


		/**
		 * process the HTTP request array
		 *
		 * @return void
		 * @access public
		 */
		protected function onRequest( array &$httpRequest ) {

			if( $this->readonly ) {
				$this->submitted = true;

				return;
			}

			if( isset( $httpRequest[$this->getHTMLControlIdString().'__month'] ) &&
				isset( $httpRequest[$this->getHTMLControlIdString().'__day'] ) &&
				isset( $httpRequest[$this->getHTMLControlIdString().'__year'] ))
			{
				$this->submitted = true;

				if( isset( $httpRequest[$this->getHTMLControlIdString().'__null'] ))
				{
					if( $this->value != $httpRequest[$this->getHTMLControlIdString().'__year'] . '-' .
							$httpRequest[$this->getHTMLControlIdString().'__month'] . '-' .
							$httpRequest[$this->getHTMLControlIdString().'__day'] ) {
						$this->changed = true;
					}

					$this->value = $httpRequest[$this->getHTMLControlIdString().'__year'] . '-' .
						$httpRequest[$this->getHTMLControlIdString().'__month'] . '-' .
						$httpRequest[$this->getHTMLControlIdString().'__day'];

					unset( $httpRequest[$this->getHTMLControlIdString().'__null'] );
				}
				else
				{
					if( $this->value ) {
						$this->changed = true;
					}

					$this->value = null; // bug fix: changed to null
				}

				unset( $httpRequest[$this->getHTMLControlIdString().'__month'] );
				unset( $httpRequest[$this->getHTMLControlIdString().'__day'] );
				unset( $httpRequest[$this->getHTMLControlIdString().'__year'] );
			}

			parent::onRequest($httpRequest);
		}


		/**
		 * called when control is loaded
		 * 
		 * @return void
		 */
		protected function onLoad()
		{
			parent::onLoad();

			$this->defaultHTMLControlId = $this->getHTMLControlIdString().'__month';
		}


		/**
		 * returns widget object
		 *
		 * @param  none
		 * @return void
		 * @access public
		 */
		public function getDomObject()
		{
			// create widgets
			$editRegion = $this->createDomObject( 'span' );
			$editRegion->appendAttribute( 'class', ' dateselector' );

			$select_day = new \System\XML\DomObject( 'select' );
			$select_month = new \System\XML\DomObject( 'select' );
			$select_year = new \System\XML\DomObject( 'select' );
			$null = new \System\XML\DomObject( 'input' );

			$null->setAttribute( 'type', 'checkbox' );
			$null->setAttribute( 'name', $this->getHTMLControlIdString() . '__null' );
			$null->setAttribute( 'id', $this->getHTMLControlIdString() . '__null' );

			if( $this->value )
			{
				$null->setAttribute( 'checked', 'checked' );
			}

			if( $this->autoPostBack )
			{
				$null->setAttribute( 'onclick', 'document.getElementById(\''.$this->getParentByType('\System\UI\WebControls\Form')->getHTMLControlIdString().'\').submit();' );
			}

			$select_day->setAttribute( 'class', 'dateselector_day' );
			$select_month->setAttribute( 'class', 'dateselector_month' );
			$select_year->setAttribute( 'class', 'dateselector_year' );
			$null->setAttribute( 'class', 'dateselector_null' );

			$select_day->setAttribute( 'name', $this->getHTMLControlIdString() . '__day' );
			$select_month->setAttribute( 'name', $this->getHTMLControlIdString() . '__month' );
			$select_year->setAttribute( 'name', $this->getHTMLControlIdString() . '__year' );

			$select_day->setAttribute( 'id', $this->getHTMLControlIdString() . '__day' );
			$select_month->setAttribute( 'id', $this->getHTMLControlIdString() . '__month' );
			$select_year->setAttribute( 'id', $this->getHTMLControlIdString() . '__year' );

			$select_month->setAttribute( 'tabIndex', $this->tabIndex++ );
			$select_day->setAttribute( 'tabIndex', $this->tabIndex++ );
			$select_year->setAttribute( 'tabIndex', $this->tabIndex++ );
			$null->setAttribute( 'tabIndex', $this->tabIndex );

			// set date to today if no date set
			$value=$this->value?strtotime($this->value)?$this->value:date('m/d/y', time()):date('m/d/y', time());

			// auto set on date
			$select_day->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true;' );
			$select_month->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true;' );
			$select_year->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true;' );

			// set onchange attribute
			if( $this->autoPostBack )
			{
				$select_day->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true; submit();' );
				$select_month->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true; submit();' );
				$select_year->setAttribute( 'onchange', 'getElementById(\'' . $this->getHTMLControlIdString() . '__null\').checked = true; submit();' );
				$null->setAttribute( 'onchange', 'document.getElementById(\''.$this->getParentByType('\System\UI\WebControls\Form')->getHTMLControlIdString().'\').submit();' );
			}

			// set invalid class
			if( $this->submitted && !$this->validate() ) {
				$select_day->setAttribute( 'class', 'invalid' );
				$select_month->setAttribute( 'class', 'invalid' );
				$select_year->setAttribute( 'class', 'invalid' );
			}

			// set readonly attribute
			if( $this->readonly )
			{
				$select_day->setAttribute( 'disabled', 'disabled' );
				$select_month->setAttribute( 'disabled', 'disabled' );
				$select_year->setAttribute( 'disabled', 'disabled' );
				$null->setAttribute( 'disabled', 'disabled' );
			}

			// set readonly attribute
			if( $this->disabled )
			{
				$select_day->setAttribute( 'disabled', 'disabled' );
				$select_month->setAttribute( 'disabled', 'disabled' );
				$select_year->setAttribute( 'disabled', 'disabled' );
				$null->setAttribute( 'disabled', 'disabled' );
			}

			// set visibility attribute
			if( !$this->visible )
			{
				$editRegion->setAttribute( 'style', 'display: none;' );
			}

			// select initial items
			$timestamp = strtotime( $value );
			if( $timestamp )
			{
				$day = (int)date( 'd', $timestamp );
				$month = (int)date( 'm', $timestamp );
				$year = (int)date( 'Y', $timestamp );

				// create month element
				for( $i=1; $i <= 12; $i++ )
				{
					$option = new \System\XML\DomObject( 'option' );
					$option->setAttribute( 'value', $i );
					$option->nodeValue = date( 'M', strtotime( "$i/01/01" ));
 
					if( $i == $month )
					{
						$option->setAttribute( 'selected', 'selected' );
					}

					$select_month->addChild( $option );
					unset( $option );
				}

				// create day element
				for( $i=1; $i <= 31; $i++ )
				{
					$option = new \System\XML\DomObject( 'option' );
					$option->setAttribute( 'value', $i );
					$option->nodeValue = $i;

					if( $i == $day )
					{
						$option->setAttribute( 'selected', 'selected' );
					}

					$select_day->addChild( $option );
					unset( $option );
				}

				$thisyear = (int) date( 'Y', time() );

				// create year element
				for( $i=($this->yearMin); $i <= ($this->yearMax); $i++ )
				{
					$option = new \System\XML\DomObject( 'option' );
					$option->setAttribute( 'value', $i );
					$option->nodeValue = $i;

					if( $i == $year )
					{
						$option->setAttribute( 'selected', 'selected' );
					}

					$select_year->addChild( $option );
					unset( $option );
				}

				$editRegion->addChild( $select_month );
				$editRegion->addChild( $select_day );
				$editRegion->addChild( $select_year );
				$editRegion->addChild( $null );
			}

			/*
			if( !($this->renderMode==\System\UI\WebControls\RenderMode::HTML()) ) {

				$editRegion->setAttribute( 'id', $this->getHTMLControlIdString() . '__node' );
				$editRegion->setAttribute( 'class', 'webctrl_editregion' );
				$editRegion->appendAttribute( 'onmouseover', 'if( document.getElementById( \'' . $this->getHTMLControlIdString() . '__month\' ).style.display == \'none\' ) this.className = \'webctrl_editregion_hover\';' );
				$editRegion->appendAttribute( 'onmouseout', 'this.className = \'webctrl_editregion\';' );

				$editRegion->appendAttribute( 'onclick', 'dynamicDateSelectorRegion( \'' . $this->getHTMLControlIdString() . '\' );' );
			}
			 */

			return $editRegion;
		}
	}
?>