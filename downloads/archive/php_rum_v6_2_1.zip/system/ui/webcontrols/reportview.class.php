<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a ReportView Control
	 *
	 * @property string $title Report title
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class ReportView extends WebControlBase
	{
		/**
		 * report title
		 * @var string
		 */
		protected $title					= '';

		/**
		 * array holding report grouping fields
		 * @var array
		 */
		private $_grouping					= array();

		/**
		 * array holding report sorting fields
		 * @var array
		 */
		private $_sorting					= array();

		/**
		 * array holding report filtering fields and values
		 * @var array
		 */
		private $_filtering					= array();

		/**
		 * contains bound DataSet
		 * @var DataSet
		 */
		private $_data						= null;

		/**
		 * contains sum data for details
		 * @var array
		 */
		private $_sum						= array();


		/**
		 * Constructor
		 *
		 * @param  string   $controlId  Control Id
		 *
		 * @return void
		 */
		public function ReportView( $controlId )
		{
			parent::__construct( $controlId );

			$this->title = $this->title?$this->title:$controlId;
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'title' )
			{
				return $this->title;
			}
			elseif( $field === 'attributes' )
			{
				throw new \System\BadMemberCallException("call to undefined property attributes in ".get_class($this));
			}
			else
			{
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'title' )
			{
				$this->title = (string)$value;
			}
			elseif( $field === 'attributes' )
			{
				throw new \System\BadMemberCallException("call to undefined property attributes in ".get_class($this));
			}
			else
			{
				parent::__set( $field, $value );
			}
		}


		/**
		 * adds a grouping field to the report
		 *
		 * @return void
		 */
		public function addGrouping( $field, $ascending = true )
		{
			$this->_grouping[$field] = $ascending;
		}


		/**
		 * adds a sorting field to the report
		 *
		 * @return void
		 */
		public function addSorting( $field, $ascending = true )
		{
			$this->_sorting[$field] = $ascending;
		}


		/**
		 * adds a filter to the report
		 *
		 * @return void
		 */
		public function addFilter( $field, $operator, $value )
		{
			$filter = array();
			$filter['field']	= $field;
			$filter['operator'] = $operator;
			$filter['value']	= $value;
			$this->_filtering[] = $filter;
		}


		/**
		 * returns an html string
		 *
		 * @param   array		$args			widget parameters
		 * @return  string
		 */
		public function fetch( array $array = array() )
		{
			ob_start();

			if( !$this->_data )
			{
				throw new \System\InvalidOperationException("no valid DataSet object");
			}

			$this->_data->first();

			// filter
			foreach( $this->_filtering as $filter )
			{
				$this->_data->filter( $filter['field'], $filter['operator'], $filter['value'] );
			}

			// render report header
			$this->onReportHeader( $this->_data );
			$this->onGroupHeader( $this->_data );

			// render details
			$this->_level( $this->_data );

			// render report footer
			$this->onGroupFooter( $this->_data );
			$this->onReportFooter( $this->_data );

			return ob_get_clean();
		}


		/**
		 * returns a DomObject for rendering
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			throw new \System\MethodNotImplementedException();
		}


		/**
		 * bind control to data
		 *
		 * @param  $default			value
		 * @return void
		 */
		protected function onDataBind()
		{
			if( $this->dataSource )
			{
				$this->_data = clone $this->dataSource;
			}
			else
			{
				throw new \System\InvalidOperationException( 'DataReport::dataBind() called with no dataSource' );
			}
		}


		/**
		 * return grouping array
		 *
		 * @return void
		 */
		protected function getGrouping()
		{
			return $this->_grouping;
		}


		/**
		 * generic method for handling report header
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @return void
		 */
		protected function onReportHeader( \System\Data\DataSet &$ds )
		{
			echo '<table class="datareport" id="'.$this->getHTMLControlIdString().'">';
			echo '<caption>' . htmlentities( $this->title ) . '</caption>';

			echo '<thead>';

			echo '<tr>';
			foreach( $ds->fields as $field ) {
				if(( array_search( $field->name, array_keys( $this->getGrouping() ))) === FALSE ) {
					echo '<th style="width:'.(int) (100 / ((int)($ds->fields->count-count($this->getGrouping()))+1)).'%">' . $field->name . '</th>';
				}
			}
			echo '</tr>';

			echo '</thead>';
			echo '<tfoot>';
			echo '</tfoot>';

			echo '<tbody>';
		}


		/**
		 * generic method for handling grouped field headers
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @param  string		$group		current grouping
		 * @param  int			$level		current level
		 * @return void
		 */
		protected function onGroupHeader( \System\Data\DataSet &$ds, $group = '', $level = 0 )
		{
			echo '<tr class="group_header">';
			if( isset( $ds[$group] )) {
				echo '<th colspan="' . $ds->fields->count . '">' . htmlentities( $group ) . ' : &quot;' . htmlentities( $ds[$group] ) . '&quot;</th>';
			}
			echo '</tr>';
		}


		/**
		 * generic method for handling report details
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @param  string		$group		current grouping
		 * @param  int			$level		current level
		 * @return void
		 */
		protected function onGroupDetail( \System\Data\DataSet &$ds, $group = '', $level = 0 )
		{
			$this->_sum = array();

			// details
			foreach( $ds->rows as $record ) {
				echo '<tr class="group_detail">';

				foreach( $ds->fields as $field ) {

					if( $field->numeric ) {
						if( isset( $this->_sum[$field->name] )) {
							$this->_sum[$field->name] += (real) $record[$field->name];
						}
						else {
							$this->_sum[$field->name] = (real) $record[$field->name];
						}
					}

					if(( array_search( $field->name, array_keys( $this->getGrouping() ))) === FALSE ) {
						if( $field->numeric ) {
							echo '<td style="text-align:right;">' . htmlentities( $record[$field->name] ) . '</td>';
						}
						else {
							echo '<td>' . htmlentities( $record[$field->name] ) . '</td>';
						}
					}
				}

				echo '</tr>';
			}
		}


		/**
		 * generic method for handling grouped field footers
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @param  string		$group		current grouping
		 * @param  int			$level		current level
		 * @return void
		 */
		protected function onGroupFooter( \System\Data\DataSet &$ds, $group = '', $level = 0 )
		{
			echo '<tr class="group_footer">';
			foreach( $ds->fields as $field ) {
				if(( array_search( $field->name, array_keys( $this->getGrouping() ))) === FALSE ) {
					if( isset( $this->_sum[$field->name] )) {
						echo '<td>' . htmlentities( $this->_sum[$field->name] ) . '</td>';
					}
					else {
						echo '<td></td>';
					}
				}
			}
			echo '</tr>';
		}


		/**
		 * generic method for handling report footer
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @return void
		 */
		protected function onReportFooter( \System\Data\DataSet &$ds )
		{
			echo '</tbody>';
			echo '</table>';
		}


		/**
		 * render report grouping level
		 *
		 * @param  object	$param		DataSet object
		 * @param  level	$level		denotes the grouping level
		 * @return void
		 */
		private function _level( \System\Data\DataSet &$ds, $level = 0 )
		{
			/**
			 * the following code chunk will 
			 * get the field to group by
			 */
			$keys = array_keys( $this->_grouping );
			if( isset( $keys[$level] ))
			{
				if( $ds->fields->indexOf( $keys[$level] ) > -1 )
				{
					// we now have the name of the field to group by so lets sort the data by field
					$field = $keys[ $level ];
					$ds->sort( $field, $this->_grouping[$field] );
				}
			}

			$value = false;

			if( isset( $field ))
			{
				// iterate through records
				while( !$ds->eof() )
				{
					if( in_array( $field, array_keys( $ds->row )))
					{
						// start a new group
						if( !( $value === $ds[$field] ))
						{
							// this grouping value
							$value = $ds[$field];

							/*
							 * this will filter out all records that 
							 * are not part of this grouping
							 */
							$group_rs = clone $ds;
							$group_rs->filter( $field, '=', $value );
							$group_rs->first();

							// render group header
							$func = 'on' . ucwords( $field ) . 'Header';
							if( method_exists( $this, $func ))
							{
								$this->$func( $group_rs, $field );
							}
							else
							{
								$this->onGroupHeader( $group_rs, $field, $level );
							}

							/**
							 * if there is another level of grouping then repeat
							 * otherwise render
							 */
							if(( $level + 1 ) < sizeof( $keys ))
							{
								$this->_level( $group_rs, $level + 1 );
							}
							else
							{
								// sorting
								$sorting = array_reverse( $this->_sorting );
								foreach( $sorting as $key => $var )
								{
									$group_rs->sort( $key, $var );
								}

								// render details
								$func = 'on' . ucwords( $field ) . 'Detail';
								if( method_exists( $this, $func ))
								{
									$this->$func( $group_rs, $field );
								}
								else
								{
									$this->onGroupDetail( $group_rs, $field, $level );
								}
							}

							// render group footer (only if not details)
							$group_rs->first();
							$func = 'on' . ucwords( $field ) . 'Footer';
							if( method_exists( $this, $func ))
							{
								$this->$func( $group_rs, $field );
							}
							else
							{
								$this->onGroupFooter( $group_rs, $field, $level );
							}
						}
					}

					// move record pointer
					$ds->next();
				}
			}
			else
			{
				// sorting
				$sorting = array_reverse( $this->_sorting );
				foreach( $sorting as $key => $var )
				{
					$ds->sort( $key, $var );
				}

				// render details
				$this->onGroupDetail( $ds );
			}
		}
	}
?>