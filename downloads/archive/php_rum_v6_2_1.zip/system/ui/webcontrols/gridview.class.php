<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a GridView Control
	 *
	 * @property string $caption
	 * @property int $pageSize
	 * @property bool $sortable
	 * @property bool $showHeader
	 * @property bool $showFooter
	 * @property bool $showPageNumber
	 * @property bool $showPrimaryKey
	 * @property string $onmouseover
	 * @property string $onmouseout
	 * @property string $onclick
	 * @property string $ondblclick
	 * @property bool $autoGenerateColumns
	 * @property bool $showList
	 * @property bool $showSelectAll
	 * @property bool $multiple
	 * @property array $selected
	 * @property string $valueField
	 * @property string $listName
	 * @property GridViewColumnCollection $columns
	 * @property int $page
	 *
	 * @version			2.0
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class GridView extends WebControlBase
	{
		/**
		 * Table caption, Default is none
		 * @var string
		 */
		protected $caption					= '';

		/**
		 * Number of rows to display per page, Default is 20
		 * @var int
		 */
		protected $pageSize					= 20;

		/**
		 * Specifies if table is sortable, Default is true
		 * @var bool
		 */
		protected $sortable					= true;

		/**
		 * Set to display column headers, Default is true
		 * @var bool
		 */
		protected $showHeader				= true;

		/**
		 * Set to display table footer, Default is false
		 * @var bool
		 */
		protected $showFooter				= false;

		/**
		 * Set to display table footer, Default is true
		 * @var bool
		 */
		protected $showPageNumber			= true;

		/**
		 * Set to display primary key in view, Default is false
		 * @var bool
		 */
		protected $showPrimaryKey			= false;

		/**
		 * specifies the action to take on mouseover events
		 * @var string
		 */
		protected $onmouseover				= '';

		/**
		 * specifies the action to take on onmouseout events
		 * @var string
		 */
		protected $onmouseout				= '';

		/**
		 * specifies the action to take on click events
		 * @var string
		 */
		protected $onclick					= '';

		/**
		 * specifies the action to take on double click events
		 * @var string
		 */
		protected $ondblclick				= '';

		/**
		 * Specifies whether to generate columns from datasource, default is false
		 * @var bool
		 */
		protected $autoGenerateColumns		= false;

		/**
		 * Show list view, default is false
		 * @var bool
		 */
		protected $showList					= false;

		/**
		 * Show select all checkbox, default is false
		 * @var bool
		 */
		protected $showSelectAll			= false;

		/**
		 * specifies if list can have multiple values (used when showList is true), default is false
		 * @var bool
		 */
		protected $multiple					= false;

		/**
		 * array of values for selected items (used when showList is true)
		 * @var array
		 */
		protected $selected					= array();

		/**
		 * value field for checkboxes (used when showList is true)
		 * @var string
		 */
		protected $valueField				= '';

		/**
		 * optional name for the list
		 * @var string
		 */
		protected $listName					= '&nbsp;';

		/**
		 * current grid page
		 * @var int
		 */
		protected $page						= 1;

		/**
		 * current grid sorting field
		 * @var string
		 */
		protected $sortBy					= '';

		/**
		 * current grid sorting order
		 * @var string
		 */
		protected $sortOrder				= '';

		/**
		 * Array of actions
		 * @var array
		 */
		protected $actions					= array();

		/**
		 * collection of columns
		 * @var GridViewColumnCollection
		 */
		protected $columns;

		/**
		 * contains bound DataSet
		 * @var DataSet
		 */
		private $_data						= null;


		/**
		 * sets the controlId and prepares the control attributes
		 *
		 * @param  string   $controlId  Control Id
		 * @return void
		 */
		public function GridView( $controlId )
		{
			parent::__construct( $controlId );

			$this->columns = new GridViewColumnCollection();
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'caption' ) {
				return $this->caption;
			}
			elseif( $field === 'pageSize' ) {
				return $this->pageSize;
			}
			elseif( $field === 'sortable' ) {
				return $this->sortable;
			}
			elseif( $field === 'showHeader' ) {
				return $this->showHeader;
			}
			elseif( $field === 'showFooter' ) {
				return $this->showFooter;
			}
			elseif( $field === 'showPageNumber' ) {
				return $this->showPageNumber;
			}
			elseif( $field === 'showPrimaryKey' ) {
				return $this->showPrimaryKey;
			}
			elseif( $field === 'onmouseover' ) {
				return $this->onmouseover;
			}
			elseif( $field === 'onmouseout' ) {
				return $this->onmouseout;
			}
			elseif( $field === 'onclick' ) {
				return $this->onclick;
			}
			elseif( $field === 'ondblclick' ) {
				return $this->ondblclick;
			}
			elseif( $field === 'autoGenerateColumns' ) {
				return $this->autoGenerateColumns;
			}
			elseif( $field === 'showList' ) {
				return $this->showList;
			}
			elseif( $field === 'showSelectAll' ) {
				return $this->showSelectAll;
			}
			elseif( $field === 'multiple' ) {
				return $this->multiple;
			}
			elseif( $field === 'selected' ) {
				return $this->selected;
			}
			elseif( $field === 'valueField' ) {
				return $this->valueField;
			}
			elseif( $field === 'listName' ) {
				return $this->listName;
			}
			elseif( $field === 'page' ) {
				return $this->page;
			}
			elseif( $field === 'columns' ) {
				return $this->columns;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'caption' ) {
				$this->caption = (string)$value;
			}
			elseif( $field === 'pageSize' ) {
				$this->pageSize = (int)$value;
			}
			elseif( $field === 'sortable' ) {
				$this->sortable = (bool)$value;
			}
			elseif( $field === 'showHeader' ) {
				$this->showHeader = (bool)$value;
			}
			elseif( $field === 'showFooter' ) {
				$this->showFooter = (bool)$value;
			}
			elseif( $field === 'showPageNumber' ) {
				$this->showPageNumber = (bool)$value;
			}
			elseif( $field === 'showPrimaryKey' ) {
				$this->showPrimaryKey = (bool)$value;
			}
			elseif( $field === 'onmouseover' ) {
				$this->onmouseover = (string)$value;
			}
			elseif( $field === 'onmouseout' ) {
				$this->onmouseout = (string)$value;
			}
			elseif( $field === 'onclick' ) {
				$this->onclick = (string)$value;
			}
			elseif( $field === 'ondblclick' ) {
				$this->ondblclick = (string)$value;
			}
			elseif( $field === 'autoGenerateColumns' ) {
				$this->autoGenerateColumns = (bool)$value;
			}
			elseif( $field === 'showList' ) {
				$this->showList = (bool)$value;
			}
			elseif( $field === 'showSelectAll' ) {
				$this->showSelectAll = (bool)$value;
			}
			elseif( $field === 'multiple' ) {
				$this->multiple = (bool)$value;
			}
			elseif( $field === 'selected' ) {
				$this->selected = (array)$value;
			}
			elseif( $field === 'valueField' ) {
				$this->valueField = (string)$value;
			}
			elseif( $field === 'listName' ) {
				$this->listName = (string)$value;
			}
			elseif( $field === 'page' ) {
				$this->page = (int)$value;
			}
			else {
				parent::__set($field,$value);
			}
		}


		/**
		 * adds a bound column
		 *
		 * @param  string		$dataField			name of data field to bind column to
		 * @param  string		$headerText			column header text
		 * @param  string		$itemText			column item text (can be formatted)
		 * @param  string		$footerText			column footer text
		 * @param  string		$className			column css class name
		 * @return void
		 */
		public function addColumn( $dataField='', $headerText='', $itemText='', $footerText='', $className='' )
		{
			$column = new GridViewColumn($dataField, $headerText, $itemText, $footerText, $className);

			if($footerText)
			{
				$this->showFooter = true;
			}

			$this->columns->add( $column );
		}


		/**
		 * adds a bound column
		 *
		 * @param  string		$actionField			field name
		 * @param  string		$actionName				name of action
		 * @param  string		$actionParameter		parameter
		 * @param  string		$actionHeaderText		header text
		 * @param  string		$actionFooterText		footer text
		 * @param  string		$actionClassName		css class name
		 * @return void
		 */
		public function addActionColumn( $actionField, $actionName, $actionParameter='', $actionHeaderText='', $actionFooterText='', $actionClassName='' )
		{
			$actionEvent='on'.ucwords(str_replace(" ","_",$actionName)).'Click';
			$actionParameter=$actionParameter?$actionParameter:str_replace(" ","_",$actionName);

			$hiddenVars = '';
			foreach(new \System\IO\HttpRequest() as $key => $value)
			{
				$hiddenVars .= "<input type=\"hidden\" name=\"".(string)$key."\" value=\"".(string)$value."\" />";
			}

			if($actionFooterText)
			{
				$this->showFooter = true;
			}

			$column = new GridViewColumn( '', $actionHeaderText, "'<form class=\"gridview_action\" method=\"post\" action=\"".\System\AppServlet::getInstance()->config->uri."/\">{$hiddenVars}<input type=\"hidden\" name=\"{$actionParameter}\" value=\"'.%{$actionField}%.'\" /><input type=\"submit\" value=\"{$actionName}\" class=\"button\" /></form>'", $actionFooterText, $actionClassName );
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $actionEvent))
			{
				$column->onPostParameter = $actionParameter;
				$column->events->registerEventHandler(new \System\UI\Events\GridViewColumnPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $actionEvent));
			}

			$this->columns->add( $column );
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			// get data
			if( !$this->_data ) {
				throw new \System\InvalidOperationException("no valid DataSet object");
			}

			// get sort request
			if( $this->sortBy && $this->sortable ) {

				// sort DataSet
				$this->_data->sort( $this->sortBy, $this->sortOrder, true );
			}

			// validate grid page
			$this->_data->pageSize = $this->pageSize;
			if( $this->page > $this->_data->pageCount() ) {
				// if page is beyond DataSet, set to last page
				$this->page = $this->_data->pageCount();
			}
			elseif( $this->page < 1 ) {
				// if page is before DataSet, set to first page
				$this->page = 1;
			}

			$this->_data->page( $this->page );

			// create table Dom
			$table   = $this->createDomObject( 'table' );
			$caption = new \System\XML\DomObject( 'caption' );
			$thead   = new \System\XML\DomObject( 'thead' );
			$tbody   = new \System\XML\DomObject( 'tbody' );
			$tfoot   = new \System\XML\DomObject( 'tfoot' );

			// set some basic attributes/properties
			$table->setAttribute( 'id', $this->getHTMLControlIdString() );
			$table->appendAttribute( 'class', ' gridview' );

			$caption->nodeValue .= $this->caption;

			// check for valid datasource
			if( $this->_data )
			{
				// display all
				if( $this->pageSize === 0 ) {
					$this->pageSize = $this->_data->count;
					$this->showPageNumber = FALSE;
				}



				/*
				 * begin
				 */



				/**********************************************************************
				 *
				 * <thead>
				 *
				 **********************************************************************/

				$tr = $this->getRowHeader( $this->_data );

				// add thead to table
				$thead->addChild( $tr );


				/**********************************************************************
				 *
				 * <tbody>
				 *
				 **********************************************************************/

				$cssStyle='';

				// loop through each item (record)
				while( !$this->_data->eof() && $this->_data->page() === $this->page )
				{
					$tr = $this->getRowBody( $this->_data );

					// add row to tbody
					$tbody->addChild( $tr );

					// move record pointer
					$this->_data->next();
				}

				/**********************************************************************
				 *
				 * <tfoot>
				 *
				 **********************************************************************/

				/**
				 * Footer
				 */

				$tr = $this->getRowFooter( $this->_data );
				$tr->setAttribute( 'class', 'footer' );

				if( $this->showFooter ) {
					$tfoot->addChild( $tr );
				}

				/**
				 * RecordNavigation
				 */
				$tr = new \System\XML\DomObject( 'tr' );
				$tr->setAttribute( 'class', 'pagenumbers' );

				$td = new \System\XML\DomObject( 'td' );
				if( $this->valueField && $this->showList ) {
					$td->setAttribute( 'colspan', sizeof( $this->columns ) + 1 );
				}
				else {
					$td->setAttribute( 'colspan', sizeof( $this->columns ));
				}

				$span = new \System\XML\DomObject( 'span' );
				$span->setAttribute( 'style', 'float: right;' );

				// prev
				if( $this->page > 1 ) {
					$a = new \System\XML\DomObject( 'a' );
					$a->setAttribute( 'href', $this->getQueryString('?'.$this->getHTMLControlIdString().'__page='.($this->page-1).'&'.$this->getHTMLControlIdString().'__sort_by='.$this->sortBy.'&'.$this->getHTMLControlIdString().'__sort_order='.($this->sortOrder?'desc':'asc' )));
					$a->nodeValue .= 'prev';
					$span->addChild( $a );
				}

				// page jump
				$count = $this->_data->count;
				for( $page=1; $this->pageSize && (( $page * $this->pageSize ) - $this->pageSize ) < $count; $page++ )
				{
					$start = ((( $page * $this->pageSize ) - $this->pageSize ) + 1 );

					if( $page * $this->pageSize < $this->_data->count )
					{
						$end = ( $page * $this->pageSize );
					}
					else
					{
						$end = $this->_data->count;
					}

					// page select
					if( $this->page <> $page )
					{
						$a = new \System\XML\DomObject( 'a' );
						$a->setAttribute( 'href', $this->getQueryString('?'.$this->getHTMLControlIdString().'__page='.$page.'&'.$this->getHTMLControlIdString().'__sort_by='.$this->sortBy.'&'.$this->getHTMLControlIdString().'__sort_order='.($this->sortOrder?'desc':'asc' )));
						$a->nodeValue .= $page;
						$span->addChild( $a );
					}
					else
					{
						$span->addChild( new \System\XML\TextNode( $page ));
					}
				}

				// next
				if(( $this->page * $this->pageSize ) < $this->_data->count && $this->pageSize )
				{
					$a = new \System\XML\DomObject( 'a' );
					$a->setAttribute( 'href', $this->getQueryString('?'.$this->getHTMLControlIdString().'__page='.($this->page+1).'&'.$this->getHTMLControlIdString().'__sort_by='.$this->sortBy.'&'.$this->getHTMLControlIdString().'__sort_order='.($this->sortOrder?'desc':'asc' )));
					$a->nodeValue .= 'next';
					$span->addChild( $a );
				}

				$td->addChild( $span );

				// get page info
				$start = ((( $this->page * $this->pageSize ) - $this->pageSize ) + 1 );
				if( !$this->_data->count ) $start = 0;

				$end = 0;
				if( $this->page * $this->pageSize < $this->_data->count )
				{
					$end = ( $this->page * $this->pageSize );
				}
				else
				{
					$end = $this->_data->count;
				}

				$span = new \System\XML\DomObject( 'span' );
				$span->nodeValue .= "showing $start to $end of " . $this->_data->count;

				$td->addChild( $span );
				$tr->addChild( $td );

				if( $this->showPageNumber ) {
					$tfoot->addChild( $tr );
				}

				// empty table
				if( !$this->_data->count ) {
					$tr = new \System\XML\DomObject( 'tr' );
					$td = new \System\XML\DomObject( 'td' );

					// list item
					if( $this->valueField && $this->showList ) {
						$td->setAttribute( 'colspan', sizeof( $this->columns ) + 1 );
					}
					else {
						$td->setAttribute( 'colspan', sizeof( $this->columns ));
					}

					$tr->addChild( $td );
					$tbody->addChild( $tr );
				}

				/*
				 * end
				 */

				if( $this->caption )				$table->addChild( $caption );
				if( $this->showHeader )				$table->addChild( $thead );
				if( $this->showPageNumber ||
					$this->showFooter )				$table->addChild( $tfoot );
													$table->addChild( $tbody );
			}
			else {
				throw new \System\InvalidOperationException("no valid DataSet object");
			}

			return $table;
		}


		/**
		 * read view state from session
		 *
		 * @param  array	$session	session data
		 * @return void
		 */
		protected function onLoadViewState( array &$session )
		{
			if( $this->enableViewState )
			{
				if( isset( $session['page'] ) &&
					isset( $session['sort_by'] ) &&
					isset( $session['sort_order'] ) &&
					isset( $session['selected'] ))
				{
					$this->page = (int) $session['page'];
					$this->sortBy = $session['sort_by'];
					$this->sortOrder = $session['sort_order'];
					$this->selected = $session['selected'];
				}
			}
		}


		/**
		 * bind control to data
		 *
		 * @param  $default			value
		 * @return void
		 */
		protected function onDataBind()
		{
			$this->_data = clone $this->dataSource;

			if( $this->autoGenerateColumns || $this->columns->count === 0 )
			{
				$this->_generateColumns();
			}
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			$page = $this->getParentByType( '\System\UI\WebControls\Page' );
			if( $page )
			{
				$page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/init.js' );
				$page->addLink(   \System\HTTPAppServlet::getInstance()->config->assets . '/gridview/gridview.css' );
				$page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/gridview/gridview.js' );
			}
		}


		/**
		 * process the HTTP request array
		 *
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( isset( $request[$this->getHTMLControlIdString().'__sort_by'] ))
			{
				$this->sortBy = $request[$this->getHTMLControlIdString().'__sort_by'];
				unset( $request[$this->getHTMLControlIdString().'__sort_by'] );
			}

			if( isset( $request[$this->getHTMLControlIdString().'__sort_order'] ))
			{
				$this->sortOrder = $request[$this->getHTMLControlIdString().'__sort_order']=='desc'?TRUE:FALSE;
				unset( $request[$this->getHTMLControlIdString().'__sort_order'] );
			}

			if( isset( $request[$this->getHTMLControlIdString().'__page'] ))
			{
				$this->page = (int) $request[$this->getHTMLControlIdString().'__page'];
				unset( $request[$this->getHTMLControlIdString().'__page'] );
			}

			if( isset( $request[$this->getHTMLControlIdString().'__selected'] ))
			{
				$this->selected = $request[$this->getHTMLControlIdString().'__selected'];
				unset( $request[$this->getHTMLControlIdString().'__selected'] );
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		protected function onPost( array &$request )
		{
			$this->columns->triggerEvent( $request );
		}


		/**
		 * write view state to session
		 *
		 * @param  object	$session	session array
		 * @return void
		 */
		protected function onSaveViewState( array &$session )
		{
			if( $this->enableViewState )
			{
				$session['page'] = $this->page;
				$session['sort_by'] = $this->sortBy;
				$session['sort_order'] = $this->sortOrder;
				$session['selected'] = $this->selected;
			}
		}


		/**
		 * generic method for handling the row header
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @return DomObject
		 */
		protected function getRowHeader( \System\Data\DataSet &$ds )
		{
			// create header node
			$tr = new \System\XML\DomObject( 'tr' );

			// list item
			if( $this->valueField && $this->showList ) {

				// create column node (field)
				$th = new \System\XML\DomObject( 'th' );

				// set column attributes
				$th->setAttribute( 'class', 'listcolumn' );
				$th->innerHtml .= $this->listName;

				if( $this->multiple && $this->showSelectAll )
				{
					$input = new \System\XML\DomObject( 'input' );
					$input->setAttribute( 'type', 'checkbox' );
					$input->setAttribute( 'onclick', 'PHPRum.gridViewSelectAll(\''.$this->getHTMLControlIdString().'\');' );
					$input->setAttribute( 'id', $this->getHTMLControlIdString() . '__selectall' );
					$input->setAttribute( 'name', $this->getHTMLControlIdString() . '__selectall' );

					// add input to th
					$th->addChild( $input );
				}

				// add thead to table
				$tr->addChild( $th );
			}

			// loop through each column
			foreach( $this->columns as $column )
			{
				// create column node
				$th = new \System\XML\DomObject( 'th' );
				if($column['Classname']) {
					$th->setAttribute( 'class', $column['Classname'] );
				}

				// get class based on sort field and order
				$class = '';
				if( $this->sortBy === $column['DataField'] ) {
					if( $this->sortOrder ) {
						$class = 'down';
					}
					else {
						$class = 'up';
					}
				}

				// column is sortable
				if( $this->sortable && $column['DataField'] )
				{
					$a = new \System\XML\DomObject( 'a' );

					// set column attributes
					$a->innerHtml .= $column['Header-Text'];
					if( $class ) $a->setAttribute( 'class', $class );

					// generate sort URL
					if(( $this->sortBy === $column['DataField'] ) && !$this->sortOrder ) {
						$a->setAttribute( 'href', $this->getQueryString('?'.$this->getHTMLControlIdString().'__page='.$this->page.'&'.$this->getHTMLControlIdString().'__sort_by='.rawurlencode($column['DataField']).'&'.$this->getHTMLControlIdString().'__sort_order=desc' ));
					}
					else {
						$a->setAttribute( 'href', $this->getQueryString('?'.$this->getHTMLControlIdString().'__page='.$this->page.'&'.$this->getHTMLControlIdString().'__sort_by='.rawurlencode($column['DataField']).'&'.$this->getHTMLControlIdString().'__sort_order=asc' ));
					}

					// add link node to column
					$th->addChild( $a );
				}

				// column is not sortable
				else
				{
					// set column attributes
					$th->innerHtml .= ($column['Header-Text']?$column['Header-Text']:'&nbsp;');
				}

				// add column to header
				$tr->addChild( $th );
			}

			return $tr;
		}


		/**
		 * generic method for handling the row body
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @return DomObject
		 */
		protected function getRowBody( \System\Data\DataSet &$ds )
		{
			// js events
			$onmouseover = $this->onmouseover;
			$onmouseout  = $this->onmouseout;
			$onclick	 = $this->onclick;
			$ondblclick  = $this->ondblclick;

			// create item node
			$tr = new \System\XML\DomObject( 'tr' );

			// set row attributes
			$tr->setAttribute( 'class', ($ds->cursor & 1)?'row_alt':'row' );

			// set row attributes
			$tr->setAttribute( 'id', $this->getHTMLControlIdString() . '__' . $ds->cursor );

			// list item
			if( $this->valueField && $this->showList ) {

				// create column node (field)
				$td = new \System\XML\DomObject( 'td' );

				// set column attributes
				$td->setAttribute( 'class', 'list' );

				$input = new \System\XML\DomObject( 'input' );
				$input->setAttribute( 'type',	( $this->multiple?'checkbox':'radio' ) );
				$input->setAttribute( 'onclick', 'if(this.checked)this.checked=false;else this.checked=true;' );
				$input->setAttribute( 'id', $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds[$this->valueField] ));
				$input->setAttribute( 'name', $this->getHTMLControlIdString() . '__selected' . ( $this->multiple?'[]':'' ));
				$input->setAttribute( 'value', $ds[$this->valueField] );
				$input->setAttribute( 'class', $this->getHTMLControlIdString() . '__checkbox' );

				if( $this->multiple ) {
					if( is_array( $this->selected )) {
						if( array_search( $ds[$this->valueField], $this->selected ) !== false ) {
							$input->setAttribute( 'checked', 'checked' );
							$tr->appendAttribute( 'class', ' selected' );
						}
					}
				}
				else {
					if( $this->selected === $ds[$this->valueField] ) {
						$input->setAttribute( 'checked', 'checked' );
						$tr->appendAttribute( 'class', ' selected' );
					}

					$tr->appendAttribute( 'onclick', 'PHPRum.gridViewUnSelectAll( \'' . $this->getHTMLControlIdString() . '\' );' );
				}

				$tr->appendAttribute( 'onclick', 'if( document.getElementById(\'' . (string) $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds->row[$this->valueField] ) . '\').checked ) { document.getElementById(\''. (string) $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds->row[$this->valueField] ) . '\').checked = false; } else { document.getElementById(\'' . (string) $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds->row[$this->valueField] ) . '\').checked = true; }' );
				$tr->appendAttribute( 'onclick', 'if( document.getElementById(\'' . (string) $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds->row[$this->valueField] ) . '\').checked ) { if(this.className === \'row\' ) { this.className = \'selected row\'; } else { this.className = \'selected row_alt\'; }}' );
				$tr->appendAttribute( 'onclick', 'if(!document.getElementById(\'' . (string) $this->getHTMLControlIdString() . '__item_' . \rawurlencode( $ds->row[$this->valueField] ) . '\').checked ) { if(this.className === \'selected row\' ) { this.className = \'row\'; } else { this.className = \'row_alt\'; }}' );

				// add td element to tr
				$td->addChild( $input );
				$tr->addChild( $td );
			}

			$values = array();

			// loop through each column (field name)
			foreach( $this->columns as $column )
			{
				// create column node (field)
				$td = new \System\XML\DomObject( 'td' );

				// set column attributes
				if( $column['Classname'] ) {
					$td->setAttribute( 'class', $column['Classname'] );
				}

				// auto format with column value
				if( !$column['Item-Text'] && $column['DataField'] ) {

					// get all field values in array
					foreach( $ds->fields as $field ) {
						$values[$field->name] = $ds[$field->name];
					}

					$td->nodeValue = $values[$column['DataField']];
				}
				elseif( $column['Item-Text'] ) {

					// get all field values in array
					$html = $column['Item-Text'];
					foreach( $ds->fields as $field ) {
						$values[$field->name] = $ds[$field->name];
						$html = str_replace( '%' . $field->name . '%', '$values[\''.addslashes($field->name).'\']', $html );
					}

					// eval
					eval( '$html = ' . $html . ';' );

					$td->innerHtml = $html?$html:'&nbsp;';
				}

				// add td element to tr
				$tr->addChild( $td );
			}

			// parse event string
			foreach( $ds->fields as $field ) {

				if( $onmouseover ) {
					$onmouseover = str_replace( '%' . $field->name . '%', $ds[$field->name], $onmouseover );
				}
				if( $onmouseout ) {
					$onmouseout = str_replace( '%' . $field->name . '%', $ds[$field->name], $onmouseout );
				}
				if( $onclick ) {
					$onclick = str_replace( '%' . $field->name . '%', $ds[$field->name], $onclick );
				}
				if( $ondblclick ) {
					$ondblclick = str_replace( '%' . $field->name . '%', $ds[$field->name], $ondblclick );
				}
			}

			if( $this->onmouseover ) {
				$tr->setAttribute( 'onmouseover', $onmouseover );
			}
			if( $this->onmouseout ) {
				$tr->setAttribute( 'onmouseout', $onmouseout );
			}
			if( $this->onclick ) {
				$tr->setAttribute( 'onclick', $onclick );
			}
			if( $this->ondblclick ) {
				$tr->setAttribute( 'ondblclick', $ondblclick );
			}

			return $tr;
		}


		/**
		 * generic method for handling the row footer
		 *
		 * @param  DataSet	$ds			DataSet object with current resultset
		 * @return DomObject
		 */
		protected function getRowFooter( )
		{
			// create footer node
			$tr = new \System\XML\DomObject( 'tr' );

			// add blank listcolumn
			if( $this->valueField && $this->showList ) {
				$td = new \System\XML\DomObject( 'td' );
				$tr->addChild( $td );
			}

			// loop through each column
			foreach( $this->columns as $column )
			{
				// create column node
				$td = new \System\XML\DomObject( 'td' );

				// set column attributes
				if( $column['Classname'] ) {
					$td->setAttribute( 'class', $column['Classname'] );
				}

				if( $column['Footer-Text'] ) {
					$td->innerHtml .= $column['Footer-Text'];
				}

				$tr->addChild( $td );
			}

			return $tr;
		}


		/**
		 * generates grid columns using datsource
		 *
		 * @return void
		 */
		private function _generateColumns()
		{
			if( $this->_data )
			{
				$this->columns = new GridViewColumnCollection();

				foreach( $this->_data->fields as $field )
				{
					if( !$field->primaryKey || $this->showPrimaryKey )
					{
						if( $field->boolean )
						{
							$this->addColumn( $field->name, ucwords( str_replace( '_', ' ', $field->name )), "%{$field->name}%?'Yes':'No'" );
						}
						elseif( $field->blob )
						{
							continue;
						}
						else
						{
							$this->addColumn( $field->name, ucwords( str_replace( '_', ' ', $field->name )));
						}
					}
				}
			}
		}
	}
?>