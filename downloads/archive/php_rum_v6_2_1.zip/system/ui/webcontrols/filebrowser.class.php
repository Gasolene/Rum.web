<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a FileBrowser Control
	 *
	 * @property int $maxSize Specifies the max size in kb, leave 0 for no size
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class FileBrowser extends InputBase
	{
		/**
		 * Specifies the size of a file browser box, default is 30
		 * @var int
		 */
		protected $size					= 30;


		/**
		 * Constructor
		 *
		 * @param  string   $controlId	  Control Id
		 * @return void
		 */
		public function FileBrowser( $controlId )
		{
			parent::__construct( $controlId, '' );

			$this->addValidator(new \System\UI\Validators\FileSizeValidator(( (int) str_replace( 'M', '', ini_get( 'upload_max_filesize' ))) * 1024)); // 1024 = Kb
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'maxSize' )
			{
				return $this->maxSize;
			}
			elseif( $field === 'size' )
			{
				return $this->size;
			}
			else
			{
				return parent::__get( $field );
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'maxSize' )
			{
				$this->maxSize = (int)$value;
			}
			elseif( $field === 'size' )
			{
				$this->size = (int)$value;
			}
			else
			{
				parent::__set($field,$value);
			}
		}


		/**
		 * returns information on the uploaded file
		 *
		 * @return array				array of file details
		 */
		public function getFileInfo()
		{
			if( isset( $_FILES[$this->getHTMLControlIdString()] ))
			{
				return $_FILES[$this->getHTMLControlIdString()];
			}
			else
			{
				throw new \System\InvalidOperationException("FileBrowser::getFileInfo() called on null file");
			}
		}


		/**
		 * return raw file data
		 *
		 * @return string				raw file data
		 */
		public function getFileRawData()
		{
			$info = $this->getFileInfo();

			if( $info['size'] > 0 )
			{
				if( $info['error'] === UPLOAD_ERR_OK )
				{
					$fp = fopen( $info['tmp_name'], 'rb' );
					if( $fp )
					{
						$data = fread( $fp, filesize( $info['tmp_name'] ));
						fclose( $fp );
						return $data;
					}
					else
					{
						throw new \System\InvalidOperationException("could not open file for reading");
					}
				}
				else
				{
					if( $info['error'] === UPLOAD_ERR_INI_SIZE )
					{
						throw new \System\InvalidOperationException("the uploaded file exceeds the upload_max_filesize directive");
					}
					elseif( $info['error'] === UPLOAD_ERR_FORM_SIZE )
					{
						throw new \System\InvalidOperationException("the uploaded file exceeds the MAX_FILE_SIZE directive");
					}
					elseif( $info['error'] === UPLOAD_ERR_PARTIAL )
					{
						throw new \System\InvalidOperationException("the uploaded file was only partially uploaded");
					}
					elseif( $info['error'] === UPLOAD_ERR_NO_FILE )
					{
						throw new \System\InvalidOperationException("no file was uploaded");
					}
					elseif( $info['error'] === UPLOAD_ERR_NO_TMP_DIR )
					{
						throw new \System\IO\FileLoadException("missing temporary folder");
					}
					elseif( $info['error'] === UPLOAD_ERR_CANT_WRITE )
					{
						throw new \System\InvalidOperationException("failed to write file to disk");
					}
					elseif( $info['error'] === UPLOAD_ERR_EXTENSION )
					{
						throw new \System\InvalidOperationException("file upload stopped by extension");
					}
					else
					{
						throw new \System\InvalidOperationException("unknown file upload failure");
					}
				}
			}
			else
			{
				return '';
			}
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$input = $this->getInputDomObject();
			$input->setAttribute( 'type', 'file' );
			$input->setAttribute( 'size', $this->size );
			$input->appendAttribute( 'class', ' filebrowser' );

			return $input;
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			parent::onLoad();

			$form = $this->getParentByType( '\System\UI\WebControls\Form' );
			if( $form )
			{
				$form->encodeType = 'multipart/form-data';
			}
		}


		/**
		 * process the HTTP request array
		 *
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( !$this->disabled )
			{
				if( isset( $_FILES[$this->getHTMLControlIdString()] ))
				{
					$this->submitted = true;
					$this->value = $_FILES[$this->getHTMLControlIdString()]['tmp_name'];
				}
			}

			parent::onRequest( $request );
		}
	}
?>