<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a MasterView Control
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class MasterView extends View
	{
		/**
		 * specifies content id string
		 * @var string
		 */
		private $_contentId = '';


		/**
		 * Constructor
		 *
		 * sets the controlId and prepares the control attributes
		 *
		 * @param  string   $controlId  Control Id
		 * @return void
		 */
		public function MasterView( $controlId )
		{
			parent::__construct($controlId);

			$this->_contentId = $this->controlId . '0004544'; // TODO:??
			$this->template = \System\HTTPAppServlet::getInstance()->config->templates . '/' . $this->controlId . __TEMPLATE_EXTENSION__;

			// event handling
			$this->events->add(new \System\UI\Events\MasterViewInitEvent());
			$this->events->add(new \System\UI\Events\MasterViewLoadEvent());

			$onInitMethod = 'on' . ucwords( $this->controlId ) . 'Init';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onInitMethod))
			{
				$this->events->registerEventHandler(new \System\UI\Events\MasterViewInitEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onInitMethod));
			}

			$onLoadMethod = 'on' . ucwords( $this->controlId ) . 'Load';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onLoadMethod))
			{
				$this->events->registerEventHandler(new \System\UI\Events\MasterViewLoadEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onLoadMethod));
			}
		}


		/**
		 * render content
		 *
		 * @return  void
		 */
		public function content()
		{
			$response = new \System\IO\HTTPResponse();
			$response->write( $this->_contentId );
			$response->send();
		}


		/**
		 * get content area id string
		 *
		 * @return  string
		 */
		public function getContentAreaIdString()
		{
			return $this->_contentId;
		}


		/**
		 * called when control is initiated
		 *
		 * @return void
		 */
		final public function initMasterView()
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
                $this->controls->itemAt( $i )->init();
			}

			$this->onInit();

			$this->events->raise(new \System\UI\Events\MasterViewInitEvent(), $this);
		}


		/**
		 * read view state from session
		 *
		 * @param  array	&$session	session data
		 * @return void
		 */
		final public function loadMasterViewViewState( array &$session )
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
                $this->controls->itemAt( $i )->loadViewState( $session );
			}
		}


		/**
		 * called when all controls are loaded
		 *
		 * @return void
		 */
		final public function loadMasterView()
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
                $this->controls->itemAt( $i )->load();
			}

			$this->onLoad();

			$this->events->raise(new \System\UI\Events\MasterViewLoadEvent(), $this);
		}


		/**
		 * process the HTTP request array
		 *
		 * @param  RequestParameterCollection	&$request	request data
		 * @return void
		 */
		final public function masterViewRequestProcessor( array &$request )
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
                $this->controls->itemAt( $i )->requestProcessor( $request );
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		final public function handleMasterViewPostEvents( array &$request )
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
				$this->controls->itemAt( $i )->handlePostEvents( $request );
			}
		}


		/**
		 * write view state to session
		 *
		 * @param  array	&$session	session data
		 * @return void
		 */
		final public function saveMasterViewViewState( array &$session )
		{
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
                $this->controls->itemAt( $i )->saveViewState($session);
			}
		}
	}
?>