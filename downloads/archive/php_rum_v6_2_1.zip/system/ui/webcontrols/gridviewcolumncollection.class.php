<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of GridViewColumn objects
	 * 
	 * @author			Darnell Shinbine
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class GridViewColumnCollection extends CollectionBase
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof GridViewColumn )
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of class GridViewColumn in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add TreeNode to Collection
		 *
		 * @param  GridViewColumn $item
		 * 
		 * @return bool
		 */
		public function add( $item )
		{
			if( $item instanceof GridViewColumn )
			{
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of class GridViewColumn");
			}
		}


		/**
		 * return GridViewColumn at a specified index
		 *
		 * @param  int		$index			index of ActiveRecord
		 *
		 * @return GridViewColumn				 GridViewColumn
		 */
		public function itemAt( $index )
		{
			return parent::itemAt($index);
		}


		/**
		 * trigger event
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		final public function triggerEvent( &$request )
		{
			foreach($this->items as $column)
			{
				$column->triggerEvent( $request );
			}
		}
	}
?>