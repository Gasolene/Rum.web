<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System;


	/**
	 * Provides the base HTTP funcionality of the application.  This class recieves request data from
	 * the client, identifies the action to perform, and initiates a Controller
	 * to handle the requested action.  Once the Controller has been executed, this class will regain control
	 * and render the View selected by the Controller unless there are additional actions to perform.
	 *
	 * @property   ControllerBase $requestHandler Reference to the current ControllerBase
	 * @property   string $prevPage Previous page
	 * @property   string $thisPage Current page
	 * @property   string $forwardPage Page to forward to
	 * @property   string $forwardURI URI to forward to
	 * @property   Session $session Reference to the Session
	 * @property   AppMessageCollection $messages Contains the AppMessageCollection object
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class HTTPAppServlet extends AppServlet
	{
		/**
		 * Contains the current ControllerBase
		 * @var ControllerBase
		 */
		private $_requestHandler			= null;

		/**
		 * Specifies the id of the current page
		 * @var string
		 */
		private $_thisPage					= '';

		/**
		 * Specifies the id of the previous page
		 * @var string
		 */
		private $_prevPage					= '';

		/**
		 * Specifies the id of the next page
		 * @var string
		 */
		private $_forwardPage				= '';

		/**
		 * Specifies the id of the forward URI Resource
		 * @var string
		 */
		private $_forwardURI				= '';

		/**
		 * Specifies the forward URI parameters
		 * @var array
		 */
		private $_forwardParams			= array();

		/**
		 * Contains an array of runtime errors
		 * @var array
		 */
		private $_warnings					= array();

		/**
		 * Contains the _session object
		 * @var _session
		 */
		private $_session					= null;

		/**
		 * Contains the AppMessageCollection object
		 * @var AppMessageCollection
		 */
		private $_messages					= null;


		/**
		 * Constructor
		 *
		 * Creates an instance of the controller and sets default action map.
		 *
		 * @return  void
		 */
		public function HTTPAppServlet()
		{
			parent::__construct();

			$this->_session  = new \System\IO\Session();
			$this->_messages = new \System\AppMessageCollection();
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		final public function __get( $field )
		{
			if( $field === 'requestHandler' ) {
				return $this->_requestHandler;
			}
			elseif( $field === 'prevPage' ) {
				return $this->_prevPage;
			}
			elseif( $field === 'thisPage' ) {
				return $this->_thisPage;
			}
			elseif( $field === 'forwardPage' ) {
				return $this->_forwardPage;
			}
			elseif( $field === 'forwardURI' ) {
				return $this->_forwardURI;
			}
			elseif( $field === 'forwardParams' ) {
				return $this->_forwardParams;
			}
			elseif( $field === 'session' ) {
				return $this->_session;
			}
			elseif( $field === 'messages' ) {
				return $this->_messages;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * return the _requestHandler
		 *
		 * @param   string			$controller		name of the controller
		 * @return  ControllerBase					Controller
		 */
		final public function getRequestHandler( $controller )
		{
			// reset state
			$this->_thisPage = $controller;
			$this->_forwardURI = null;
			$this->_forwardPage = null;
			$this->_forwardParams = array();

			// replace dashes with underscores
			$controller = str_replace( '-', '_', $controller );

			// get include path
			$includePath = $this->config->controllers . '/' . strtolower( $controller ) . __CONTROLLER_EXTENSION__;
			$className = $this->namespace . "\\" . ucwords( str_replace( '/', '\\', $controller ));

			if( !defined( INCLUDEPREFIX . $includePath ))
			{
				define( INCLUDEPREFIX . $includePath, true );

				if( !include $includePath )
				{
					\System\HTTPAppServlet::getInstance()->sendHTTPError(404);
				}
			}

			if( class_exists( $className ))
			{
				// Assign reference
				$this->_requestHandler = new $className( $controller );
				return $this->_requestHandler;
			}
			else
			{
				throw new InvalidOperationException( "class `{$className}` not found" );
			}
		}


		/**
		 * returns a URI based on the requested page and parameters
		 *
		 * @param   string		$page			name of page
		 * @param   array		$args			array of parameters
		 * @return  string						raw URI
		 */
		final public function getPageURI( $page = '', array $args = array() )
		{
			$cookieless_session = true;

			if( isset( $args['PHPSESSID'] ))
			{
				unset( $args['PHPSESSID'] );
			}
			else
			{
				$cookieless_session = $this->config->cookielessSession;
			}

			$uri = $this->config->uri;

			// get controller
			$page = strtolower( urldecode( $page?str_replace( '.', '/', str_replace( '_', '-', $page ) ):\System\AppServlet::getInstance()->thisPage ));

			if( $this->config->rewriteURIS )
			{
				$id = __PAGE_EXTENSION__;

				if( !empty( $args['id'] ))
				{
					$id = '/' . $args['id'];
					unset( $args['id'] );
				}

				// build uri
				$uri .= ($cookieless_session?'/('.$this->_session->sessionId.')':'') . '/' . $page . $id;
			}
			else {
				// append _session to parameter list
				if( $cookieless_session ) {
					$args['PHPSESSID'] = $this->_session->sessionId;
				}

				// append page to parameter list
				if( $page ) {
					$args[$this->config->requestParameter] = $page;
				}

				// build uri
				$uri .= substr( $_SERVER['SCRIPT_NAME'], strrpos( $_SERVER['SCRIPT_NAME'], '/' ));
			}

			// add parameters to query string
			$params = '';
			foreach( $args as $key => $value )
			{
				if( $params )
				{
					$params .= "&$key=$value";
				}
				else {
					$params .= "?$key=$value";
				}
			}

			// create query string
			return $uri . $params;
		}


		/**
		 * send HTTP status message to client
		 *
		 * @param   int			$statuscode		HTTP status code
		 * @return void
		 */
		final public function sendHTTPError( $statuscode = 500 )
		{
			$response = new \System\IO\HTTPResponse(); // start output buffer

			// check if error code is mapped to controller
			if( isset( $this->config->errors[$statuscode] ))
			{
				$page = $this->config->errors[$statuscode];

				$requestHandler = $this->getRequestHandler( $page );
				$requestHandler->requestProcessor( new \System\IO\HTTPRequest() );

				// Render View
				$requestHandler->getView()->render();
			}
			else
			{
				$response->statusCode = $statuscode;
			}

			$response->end(); // flush and end output buffer
		}


		/**
		 * This method sets the next URI once the current controller is finished executing, the servlet will
		 * re-request the page with the requested action.  This method allows you to replace post data
		 * with keep friendly urls that can be bookmarked.
		 *
		 * @param   string				$nextPage					Name of requested page
		 * @param   array				$args						args for next action
		 * @param   ForwardMethodType	$method						forward method as constant of ForwardMethodType::URI() or ForwardMethodType::Request()
		 * @return  void
		 */
		final public function setForwardPage( $nextPage = '', array $args = array(), ForwardMethodType $method = null )
		{
			$method = $method?$method:ForwardMethodType::URI();
			$nextPage = (string)$nextPage?(string)$nextPage:$this->_thisPage;
			$nextPage = str_replace( '.', '/', $nextPage );

			$this->_prevPage = $this->_thisPage;
			$this->_forwardParams = $args;

			if( $method == ForwardMethodType::URI() )
			{
				$this->_forwardURI = $nextPage;
			}
			else
			{
				$this->_forwardPage = $nextPage;
			}
		}


		/**
		 * Returns a static instance of the http app server.
		 *
		 * @param  AppServlet		$initialize		new instance of an AppServlet object
		 * @return HTTPAppServlet						static reference to an HTTPAppServlet
		 */
		final static public function & getInstance( AppServlet $initialize = null )
		{
			$HTTPAppServlet = AppServlet::getInstance($initialize);

			if($HTTPAppServlet instanceof HTTPAppServlet)
			{
				return $HTTPAppServlet;
			}
			else
			{
				throw new \Exception( 'The HTTPAppServlet has not been initialized' );
			}
		}


		/**
		 * execute the application
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 * @return  void
		 */
		final protected function execute($argc, $argv)
		{
			if($_SERVER[__ENV_PARAMETER__]==__DEV_ENV__||$_SERVER[__ENV_PARAMETER__]==__TEST_ENV__) $this->_handleRequestParams(new \System\IO\HTTPRequest());

			// Start _session
			$this->_startSession();

			// Load Application State
			$this->loadApplicationState();

			// Process Request
			$this->requestProcessor( new \System\IO\HTTPRequest() );

			// Save Spplication State
			$this->saveApplicationState();

			// End _session
			$this->_endSession();
		}


		/**
		 * This method retrieves an instance of the previous action and the servlet _messages.  These can then
		 * be used by the servlet to populate the view.
		 *
		 * @return  void
		 */
		final protected function loadApplicationState()
		{
			if( isset( $this->_session[$this->applicationId.'.configuration.messages'] ))
			{
				$this->_messages = unserialize( $this->_session[$this->applicationId.'.configuration.messages'] );
			}
			if( isset( $this->_session[$this->applicationId.'.configuration.forward'] ))
			{
				$this->_prevPage = $this->_session[$this->applicationId.'.configuration.forward'];
			}

			if( $this->debug )
			{
				if( isset( $this->_session[$this->applicationId.'.debug.warnings'] ))
				{
					$this->_warnings = array_merge( $this->_warnings, unserialize( $this->_session[$this->applicationId.'.debug.warnings'] ));
				}
			}
		}


		/**
		 * This method stores an instance of the previous action and the servlet _messages.  These can then
		 * be used by the servlet after a page request to populate the view.
		 *
		 * @return  void
		 */
		final protected function saveApplicationState()
		{
			$this->_session[$this->applicationId.'.configuration.messages'] = serialize( $this->_messages );
			$this->_session[$this->applicationId.'.configuration.forward'] = $this->_prevPage;

			if( $this->debug )
			{
				$this->_session[$this->applicationId.'.debug.warnings'] = serialize( $this->_warnings );
			}
		}


		/**
		 * Processe HTTP Request and create actions to handle business logic.  Then render the view.
		 * Can be overwridden to provide additional or alternaitive private functionality.
		 *
		 * @param   HTTPRequest		$request	HTTPRequest object
		 * @return  void
		 */
		protected function requestProcessor( \System\IO\HTTPRequest &$request )
		{
			// get controller from request
			if( isset( $request->post[$this->config->requestParameter] ))
			{
				// Get Controller based on HTTP POST page parameter
				$this->_forwardPage = $request->post[$this->config->requestParameter];
			}
			elseif( isset( $request->get[$this->config->requestParameter] ))
			{
				// Get Controller based on HTTP GET page parameter
				$this->_forwardPage = $request->get[$this->config->requestParameter];
			}
			else
			{
				// Get Controller based on XML configuration
				$this->_forwardPage = $this->config->defaultController;
			}

			$requestData =& $request->getRequestData();
			$requestData[$this->config->requestParameter] = strtolower( $this->_forwardPage );

			while( $this->_forwardPage )
			{
				// Dispatch controller
				$_requestHandler = $this->getRequestHandler( $this->_forwardPage );

				// Handle Security
				if( \System\Security\Authentication::isProtected( $_requestHandler->controllerId ))
				{
					// Basic Authentication
					if( \System\Security\Authentication::method() === 'basic' )
					{
						if( !\System\Security\BasicAuthentication::authenticated() )
						{
							// Send HTTP authenticate headers
							\System\Security\BasicAuthentication::sendAuthHeaders();
							return;
						}
					}
					// Forms Authentication
					elseif( \System\Security\Authentication::method() === 'forms' )
					{
						if( !\System\Security\FormsAuthentication::authenticated() )
						{
							// Redirect to login page
							\System\Security\FormsAuthentication::redirectToLoginPage();
							return;
						}
					}
				}

				$headersCacheId = '';
				$outputCacheId = '';

				// Handle Output Cache
				if( $_requestHandler->outputCache > 0 )
				{
					$hashId = 'hash:' . $_requestHandler->controllerId;

					// Output Caching Enabled
					if( $request->getRequestMethod() === 'GET' )
					{
						$hash = '';

						if(\System\IO\Cache::exists($hashId, $_requestHandler->outputCache))
						{
							$hash = \System\IO\Cache::get($hashId);
						}
						else
						{
							$hash = (string)time() . '/' . $_requestHandler->controllerId . '/';

							if( $this->config->cacheEnabled )
							{
								\System\IO\Cache::put($hashId, $hash);
							}
						}

						// Generate Cache ID's
						$headersCacheId = 'output_headers:'.$hash.$_requestHandler->getCacheId($request);
						$outputCacheId = 'output:'.$hash.$_requestHandler->getCacheId($request);

						// Output Cache Exists
						if( \System\IO\Cache::exists( $outputCacheId, $_requestHandler->outputCache ))
						{
							$response = new \System\IO\HTTPResponse();

							// Send Headers
							if( \System\IO\Cache::exists( $headersCacheId, $_requestHandler->outputCache ))
							{
								$headers = unserialize( \System\IO\Cache::get($headersCacheId));
								foreach( $headers as $header )
								{
									$response->addHeader($header);
								}
							}

							// Send Output
							$response->write( \System\IO\Cache::get( $outputCacheId ));

							$this->_insertDebug($response, $_requestHandler->outputCache );

							$response->send(); // end output buffer

							return;
						}
					}
					else
					{
						\System\IO\Cache::clear($hashId);
					}
				}

				// Process request
				$_requestHandler->requestProcessor( $request );

				if( !$this->_forwardPage )
				{
					if( $this->_forwardURI && !isset( $request[AppServlet::getInstance()->config->asyncParameter] ))
					{
						// Forward URI (redirect)
						$this->_forwardURI( $this->_forwardURI, (array)$this->_forwardParams );
						return;
					}

					$response = new \System\IO\HTTPResponse(); // start output buffer

					// Render View
					$_requestHandler->getView()->render();

					// Capture output for cache
					if( $_requestHandler->outputCache > 0 &&
						$request->getRequestMethod() === 'GET' &&
						$this->_messages->count === 0 &&
						$this->config->cacheEnabled )
					{
						\System\IO\Cache::put( $headersCacheId, serialize( $response->headers ));
						\System\IO\Cache::put( $outputCacheId, $response->contents );
					}

					$this->_insertDebug($response);

					$response->send(); // flush and end output buffer

					// Cleanup
					$this->_messages->removeAll();
					$this->_warnings = array();
					$this->_prevPage = '';
				}
				else
				{
					// handle forward params
					foreach( $this->_forwardParams as $key => $value )
					{
						$request[$key] = $value;
					}
					$this->_forwardParams = array();
				}

				// Remove reference
				unset($this->_requestHandler);
			}
		}


		/**
		 * event triggered by an uncaught Exception thrown in the application, can be overridden to provide error handling.
		 *
		 * @param  Exception	$e
		 *
		 * @return void
		 */
		protected function handleException(\Exception $e)
		{
			if( $this->debug )
			{
				$backtrace = $e->getTrace();

				foreach( $backtrace as $trace )
				{
					if( strstr( $trace['file'], __SYSTEM_PATH__ ) === false )
					{
						$file = $trace['file'];
						$line = $trace['line'];
						break;
					}
				}

				$source = '';
				$line = isset($line)?$line:$e->getLine();
				$file = isset($file)?$file:$e->getFile();
				$contents = file($file);
				$filename = str_replace( __ROOT__, '', $file );

				for( $i = $line > 3 ? $line - 3 : 0, $ii = 0; $ii <= 5; $ii++, $i++ )
				{
					$current_line = (string)$i.':';
					while( strlen( $current_line ) < 6 ) $current_line .= ' ';

					if( isset( $contents[$i-1] ))
					{
						$contents[$i-1] = htmlentities($contents[$i-1]);

						if( $i === $line )
						{
							$source .= "<span style=\"font-weight:bold;color:#AA0000\">Line $current_line{$contents[$i-1]}</span>";
						}
						else
						{
							$source .= "<span>Line $current_line{$contents[$i-1]}</span>";
						}
					}
				}

				// bad form, not structured - but the only way to clear the output buffer
				ob_clean();

				$response = new \System\IO\HTTPResponse();

				$response->addHeader( "Content-Type: text/html" );
				$response->write( "<!DOCTYPE html>
<html lang=\"en\">
<head>
<title>Unhandled Exception: {$e->getMessage()}</title>
<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\">
<link href=\"" . $this->config->assets . "/debug/exception.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\">
</head>
<body>

<div id=\"tl\">
<div id=\"tr\">
<div id=\"bl\">
<div id=\"br\">

<h1>Unhandled Exception in " . strrchr( $e->getFile(), '/' ) . "</h1>

<div id=\"details\" class=\"fail\">
<h2>Runtime Error: {$e->getMessage()}</h2>
<p><strong>Description:</strong> An unhandled exception occurred during execution</p>
<p><strong>Details:</strong> " . get_class($e) . ": {$e->getMessage()}</p>
<p><strong>Source File:</strong> {$filename} <strong>on line:</strong> {$line}
</div>

<pre>
<strong>Source Information:</strong>

{$source}
</pre>

<pre>
<strong>Stack Trace:</strong>\r\n\r\n");

				$this->_dumpCallStack($e->getTrace());
				$response->write( "
</pre>

<p class=\"dump\" id=\"debug_show\"><a href=\"#debug_dump\" onclick=\"document.getElementById('debug_dump').style.display='block';document.getElementById('debug_show').style.display='none';\">Show Debug Information</a></p>
<div style=\"display:none;\" id=\"debug_dump\">");

				// {$e->getTraceAsString()}
				$this->_dumpDebug();

				$response->write( "
</div>

<div id=\"version\">
<p><strong>Framework Version:</strong> ".FRAMEWORK_VERSION_STRING."</p>
</div>

</div>
</div>
</div>
</div>

</body>
</html>" );

				$response->send();
			}
			else
			{
				$this->log( "Uncaught Exception: {$e->getMessage()} in {$e->getFile()} on line {$e->getLine()}", 'error.log' );
				\System\HTTPAppServlet::getInstance()->sendHTTPError( 500 );
			}
		}


		/**
		 * event triggered by an error in the application, can be overridden to provide error handling.
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 * @return void
		 */
		protected function handleError($errno, $errstr, $errfile, $errline)
		{
			$errcode = array (
			   E_ERROR				=> "Error",
			   E_WARNING			=> "Warning",
			   E_PARSE				=> "Parsing Error",
			   E_NOTICE				=> "Notice",
			   E_RECOVERABLE_ERROR	=> "Recoverable Fatal Error",
			   E_CORE_ERROR			=> "Core Error",
			   E_CORE_WARNING		=> "Core Warning",
			   E_COMPILE_ERROR		=> "Compile Error",
			   E_COMPILE_WARNING	=> "Compile Warning",
			   E_USER_ERROR			=> "User Error",
			   E_USER_WARNING		=> "User Warning",
			   E_USER_NOTICE		=> "User Notice",
			   E_STRICT				=> "Runtime Notice"
			   );

			if( $errno & ( E_ERROR | E_RECOVERABLE_ERROR | E_USER_ERROR | E_COMPILE_ERROR | E_CORE_ERROR ))
			{
				// throw ErrorException on fatal errors
				throw new \ErrorException($errstr, $errno, 0, $errfile, $errline);
			}
			else
			{
				$backtrace = debug_backtrace();
				array_shift( $backtrace );
				array_shift( $backtrace );

				// add error to _warnings
				array_push( $this->_warnings, array('errno'	 => $errno,
													'errstr'	=> $errstr,
													'errfile'   => $errfile,
													'errline'   => $errline,
													'backtrace' => $backtrace ));
			}
		}


		/**
		 * Start _session, sets _session id (using request parameter)
		 *
		 * @return  void
		 */
		private function _startSession()
		{
			if( isset( $_POST['PHPSESSID'] ))
			{
				$this->_session->start( $_POST['PHPSESSID'] );
			}
			elseif( isset( $_GET['PHPSESSID'] ))
			{
				$this->_session->start( $_GET['PHPSESSID'] );
			}
			else
			{
				$this->_session->start();
			}

			unset( $_POST['PHPSESSID'] );
			unset( $_GET['PHPSESSID'] );
		}


		/**
		 * endSession
		 *
		 * @return  void
		 */
		private function _endSession()
		{
			$this->_session[$this->applicationId.'.version'] = FRAMEWORK_BUILD_VERSION . '.' . FRAMEWORK_BUILD_NUMBER;
			$this->_session->close();
		}


		/**
		 * run helper commands
		 *
		 * @param   HTTPRequest		$request		HTTPRequest object
		 * @return  void
		 */
		private function _handleRequestParams( \System\IO\HTTPRequest &$request )
		{
			if(isset($request["flush_cache"]))
			{
				IO\Cache::flush();
			}
			elseif(isset($request["run_all"]))
			{
				$this->runAllTestCases($this->_getTestCaseReporter());
				exit;
			}
			elseif(isset($request["run_unit_test"]))
			{
				$this->runUnitTestCase($request["run_unit_test"], $this->_getTestCaseReporter());
				exit;
			}
			elseif(isset($request["run_functional_test"]))
			{
				$this->runFunctionalTestCase($request["run_functional_test"], $this->_getTestCaseReporter());
				exit;
			}
		}


		/**
		 * Forward the HTTP request to another HTTP request (redirect)
		 *
		 * @param   string		$page			page name
		 * @param   array		$args			args
		 * @return  void
		 */
		private function _forwardURI( $page, array $args = array() )
		{
			$response = new \System\IO\HTTPResponse();
			$response->redirect( $this->getPageURI( $page, $args ), false );
		}


		/**
		 * output debugging information
		 *
		 * @param  HTTPResponse		$response		HTTPResponse object
		 * @param  int				$mode			debug mode
		 * @return void
		 */
		private function _insertDebug( \System\IO\HTTPResponse $response, $ttl=0 )
		{
			$raw = $response->contents;
			$response->clear();

			$this->_dumpDebug($ttl);

			$debug = $response->contents;
			$response->clear();

			if( strpos( $raw, '</html>' ) !== FALSE )
			{
				$raw = str_replace( '</body>', '', $raw );
				$raw = str_replace( '</html>', '', $raw );

				$response->write( "$raw\n\n$debug\n\n</body>\n</html>" );
			}
			else
			{
				$response->write( $raw );
			}
		}


		/**
		 * output debugging information
		 *
		 * @param  int		 	$ttl		time to live (used for output caching)
		 * @return void
		 */
		private function _dumpDebug( $ttl=0 )
		{
			if( $this->debug )
			{
				$elapsed = $this->timer->elapsed();
				$response = new \System\IO\HTTPResponse();

				$errcode = array (
				   E_ERROR		   => "Fatal Error",
				   E_WARNING		 => "Warning",
				   E_PARSE		   => "Parsing Error",
				   E_NOTICE		  => "Notice",
				   E_CORE_ERROR	  => "Core Error",
				   E_CORE_WARNING	=> "Core Warning",
				   E_COMPILE_ERROR   => "Compile Error",
				   E_COMPILE_WARNING => "Compile Warning",
				   E_USER_ERROR	  => "User Error",
				   E_USER_WARNING	=> "User Warning",
				   E_USER_NOTICE	 => "User Notice",
				   E_STRICT		  => "Runtime Notice"
				   );

				// dump app stats
				$response->write( "<pre class=\"debug_dump\">" );
				$response->write( "<strong>Debug Dump:</strong>\r\n\r\n" );
				$response->write( "application running in debug mode\n" );
				$response->write( "environment: ".$_SERVER[__ENV_PARAMETER__]."\n" );
				$response->write( "framework version: ".FRAMEWORK_VERSION_STRING."\n" );
				$response->write( "PHP version: ".phpversion()."\n" );
				if($ttl>0) $response->write( "caching: output is cached {$ttl}s\n" );
				if(ini_get('apc.enabled')==1) $response->write( "apc is enabled: ".ini_get("apc.ttl")."s\n" );
				$response->write( "execution time: " . $elapsed . "s\n" );

				// mem usage
				if( function_exists( 'memory_get_usage' )) {
					//$response->write( "memory usage: " . \number_format(( memory_get_usage( true ) / 1048576 ), 2, '.', '' ) . " MB\n" ); // MB = 1048576, Kb = 1024
				}

				// dump data adapter info
				if( $this->config->dsn )
				{
					$adapter = '';
					if( strrchr( get_class($this->dataAdapter), '\\') !== false )
					{
						$adapter = substr( strrchr( str_replace( 'dataadapter', '', strtolower( get_class( $this->dataAdapter ))), '\\' ), 1 );
					}
					else
					{
						$adapter = str_replace( 'dataadapter', '', strtolower( get_class( $this->dataAdapter )));
					}

					$response->write( "adapter: " . $adapter . '; ' . $this->dataAdapter->getQueryCount() . " queries in " );
					$response->write( $this->dataAdapter->getQueryTime() . "s\n" );
				}

				// dump _warnings
				if( sizeof( $this->_warnings ) > 0 )
				{
					$response->write( "<strong>warnings: " . sizeof( $this->_warnings ) . "</strong>\n" );

					$response->write( "<a href=\"#errs\" onclick=\"document.getElementById( 'errs' ).style.display='block';\">dump warnings:</a>\n" );

					$response->write( "<span id=\"errs\" style=\"display:none;\">" );
					$i=0;
					foreach( $this->_warnings as $err ) {
						// print( "<pre>" );
						$response->write( "<a href=\"#err".$i."\" onclick=\"document.getElementById('err".$i."').style.display='block';\"><b>" . $errcode[$err['errno']] . ":</b> " . $err['errstr'] . " in <b>" . $err['errfile'] . "</b> on line <b>" . $err['errline'] . "</b></a>\n" );
						// print( "</pre>" );
						$response->write( "<span id=\"err".$i."\" style=\"display:none;\">" );

						$response->write( "<map name=\"errno".$i."\" id=\"errno".$i."\">" );
						$this->_dumpCallStack(  $err['backtrace'] );
						$response->write( "</map>" );

						$response->write( "</span>" );

						$i++;
					}
					$response->write( "</span>" );
				}

				// dump request data
				$response->write( "<a href=\"#req\" onclick=\"document.getElementById( 'req' ).style.display='block';\">dump request data:</a>\n" );
				$response->write( "<span id=\"req\" style=\"display:none;\">" );

				$response->write( "  <a href=\"#req_get\" onclick=\"document.getElementById( 'req_get' ).style.display='block';\">dump get data:</a>\n" );

				$response->write( "<a id=\"req_get\" style=\"display:none;\">" );
				ob_start();
				print_r($_GET);
				$output = ob_get_clean();
				$response->write( htmlentities( $output ));
				$response->write( "  </a>" );

				$response->write( "  <a href=\"#req_post\" onclick=\"document.getElementById( 'req_post' ).style.display='block';\">dump post data:</a>\n" );
				$response->write( "<a id=\"req_post\" style=\"display:none;\">" );
				ob_start();
				print_r($_POST);
				$output = ob_get_clean();
				$response->write( htmlentities( $output ));
				$response->write( "  </a>" );

				$response->write( "  <a href=\"#req_cookie\" onclick=\"document.getElementById( 'req_cookie' ).style.display='block';\">dump cookie data:</a>\n" );
				$response->write( "<a id=\"req_cookie\" style=\"display:none;\">" );

				ob_start();
				print_r($_COOKIE);
				$output = ob_get_clean();
				$response->write( htmlentities( $output ));

				$response->write( "  </a>" );

				$response->write( "</span>" );

				// dump request headers
				$response->write( "<a href=\"#req_headers\" onclick=\"document.getElementById( 'req_headers' ).style.display='block';\">dump request headers:</a>\n" );
				$response->write( "<a id=\"req_headers\" style=\"display:none;\">" );

				$req_headers = array( 'request headers only supported when running as apache module' );
				if( function_exists( 'apache_request_headers' )) {
					$req_headers = apache_request_headers();
				}

				ob_start();
				print_r( $req_headers );
				$output = ob_get_clean();
				$response->write( htmlentities( $output ));
				$response->write( "</a>" );

				// dump response headers
				$response->write( "<a href=\"#response_headers\" onclick=\"document.getElementById( 'response_headers' ).style.display='block';\">dump response headers:</a>\n" );
				$response->write( "<a id=\"response_headers\" style=\"display:none;\">" );

				ob_start();
				print_r( headers_list() );
				$output = ob_get_clean();
				$response->write( htmlentities( $this->_replaceNonPrinting( $output )));

				$response->write( "</a>" );

				// dump session
				$response->write( "<a href=\"#session\" onclick=\"document.getElementById( 'session' ).style.display='block';\">dump session:</a>\n" );
				$response->write( "<a id=\"session\" style=\"display:none;\">" );

				ob_start();
				print_r($_SESSION);
				$output = ob_get_clean();
				$response->write( htmlentities( $this->_replaceNonPrinting( $output )));

				$response->write( "</a>" );

				$response->write( '<a href="http://validator.w3.org/check?uri=' . htmlentities( $this->config->url . $this->getPageURI( $this->_thisPage )) . "\">validate markup</a>\n<a href=\"http://jigsaw.w3.org/css-validator/validator?uri=" . htmlentities( $this->config->url . $this->getPageURI( $this->_thisPage )) . '">validate CSS</a>' );

				$response->write( "</pre>" );

				$response->send();
			}
		}


		/**
		 * dump call stack
		 *
		 * @return void
		 */
		private function _dumpCallStack( array $callstack )
		{
			$response = new \System\IO\HTTPResponse();

			$i=0;
			foreach( $callstack as $call )
			{
				if(isset($call['file'])) {
					$current_level = '#'.$i++;
					while( strlen( $current_level ) < 3 ) $current_level .= ' ';

					$response->write( "<span style=\"color:#000000;\">{$current_level}</span> " );

					if( isset( $call['class'] ))
					{
						$response->write( "<span style=\"font-weight:bold;color:#0000AA;\">{$call['class']}-></span>" );
					}

					$response->write( "<span style=\"font-weight:bold;color:#0000AA;\">{$call['function']}(</span>" );

					$ii=0;
					foreach( $call['args'] as $arg ) {
						$trace = htmlentities(addslashes(print_r($arg,true)));
						if( $ii++ > 0 ) {
							$response->write( "," );
						}
						if( is_object( $arg )) {
							$response->write( "<span style=\"color:#0000FF\">Object</span>(<span onclick=\"getElementById('trace_{$call['line']}_{$i}_{$ii}').style.display='inline';\" style=\"text-decoration:underline;cursor:pointer;color:#000000\">".get_class($arg)."</span>)" );
						}
						elseif( is_array( $arg )) {
							$response->write( "<span style=\"text-decoration:underline;cursor:pointer;color:#0000FF\" onclick=\"getElementById('trace_{$call['line']}_{$i}_{$ii}').style.display='inline';\">Array</span>" );
						}
						elseif( is_string( $arg )) {
							$response->write( "<span style=\"color:#0000FF\">string</span>(<span style=\"color:#FF0000\">\"{$arg}\"</span>)" );
						}
						elseif( is_scalar( $arg )) {
							$response->write( "<span style=\"color:#0000FF\">".gettype($arg)."</span>(<span style=\"color:#FF0000\">".$arg."</span>)" );
						}
						else {
							$response->write( "<span style=\"color:#0000FF\">".gettype($arg)."</span>(<span style=\"color:#FF0000\">__PHP_Incomplete_Class</span>)" );
						}
						$response->write( "<span id=\"trace_{$call['line']}_{$i}_{$ii}\" style=\"display:none;\">$trace</span>" );
					}
					$response->write( "<span style=\"font-weight:bold;color:#0000AA;\">)</span>" );
					$response->write(" <strong>in</strong> " . str_replace( __ROOT__, '', $call['file'] ). " <strong>on line</strong> {$call['line']}\r\n");
				}
			}
		}


		/**
		 * replace non printing characters
		 *
		 * @param   string		$output		sting to format
		 * @return string
		 */
		private function _replaceNonPrinting( $output )
		{
			$output = str_replace( "\x00", '', $output );
			$output = str_replace( "\x01", '', $output );
			$output = str_replace( "\x02", '', $output );
			$output = str_replace( "\x03", '', $output );
			$output = str_replace( "\x04", '', $output );
			$output = str_replace( "\x05", '', $output );
			$output = str_replace( "\x06", '', $output );
			$output = str_replace( "\x07", '', $output );
			$output = str_replace( "\x08", '', $output );
			$output = str_replace( "\x09", '', $output );
			// $output = str_replace( "\x0A", '', $output );
			$output = str_replace( "\x0B", '', $output );
			$output = str_replace( "\x0C", '', $output );
			$output = str_replace( "\x0D", '', $output );
			$output = str_replace( "\x0E", '', $output );
			$output = str_replace( "\x0F", '', $output );

			$output = str_replace( "\x10", '', $output );
			$output = str_replace( "\x11", '', $output );
			$output = str_replace( "\x12", '', $output );
			$output = str_replace( "\x13", '', $output );
			$output = str_replace( "\x14", '', $output );
			$output = str_replace( "\x15", '', $output );
			$output = str_replace( "\x16", '', $output );
			$output = str_replace( "\x17", '', $output );
			$output = str_replace( "\x18", '', $output );
			$output = str_replace( "\x19", '', $output );
			$output = str_replace( "\x1A", '', $output );
			$output = str_replace( "\x1B", '', $output );
			$output = str_replace( "\x1C", '', $output );
			$output = str_replace( "\x1D", '', $output );
			$output = str_replace( "\x1E", '', $output );
			$output = str_replace( "\x1F", '', $output );

			return $output;
		}


		/**
		 * return test reporter
		 *
		 * @return  HTMLTestReporter
		 */
		private function _getTestCaseReporter() {
			require_once __SYSTEM_PATH__ . '/testcase/htmltestreporter' . __CLASS_EXTENSION__;
			return new \System\Testcase\HTMLTestReporter();
		}
	}
?>