<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System;


	/**
	 * Represents an application message type
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class AppMessageType
	{
		private $flags;

		private function __construct($flags)
		{
			$this->flags = (int)$flags;
		}

		/**
		 * Specifies the message type as Success
		 * @return AppMessageType
		 */
		public static function Success() {return new AppMessageType(1);}

		/**
		 * Specifies the message type as Fail
		 * @return AppMessageType
		 */
		public static function Fail() {return new AppMessageType(2);}

		/**
		 * Specifies the message type as Notice
		 * @return AppMessageType
		 */
		public static function Notice() {return new AppMessageType(4);}
	}
?>