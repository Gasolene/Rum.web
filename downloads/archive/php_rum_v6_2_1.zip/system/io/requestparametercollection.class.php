<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\IO;
	use \System\Collections\DictionaryBase;


	/**
	 * Represents a Collection of request parameters
	 * 
	 * @author			Darnell Shinbine
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class RequestParameterCollection extends DictionaryBase
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( is_string( $index ))
			{
				return $this->items[(string)$index] = $item;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("invalid index expected string in ".get_class($this));
			}
		}


		/**
		 * returns the key of a specified index
		 *
		 * @param  int			$index			index
		 * @return string					   key
		 */
		public function keyAt( $index )
		{
			return parent::keyAt($index);
		}
	}
?>