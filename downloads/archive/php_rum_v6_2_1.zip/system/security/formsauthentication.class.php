<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Security;


	/**
	 * Provides application wide authentication using Forms
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class FormsAuthentication extends Authentication
	{
		/**
		 * returns true if user authenticated
		 *
		 * @return  bool
		 */
		public static function authenticated()
		{
			if( Authentication::method() === 'forms' )
			{
				if( FormsAuthentication::isAuthCookieSet() )
				{
					if( Authentication::authenticateUser( FormsAuthentication::getAuthCookie() ))
					{
						Authentication::$identity = FormsAuthentication::getAuthCookie();
						return true;
					}
				}
			}
			return false;
		}


		/**
		 * sets auth cookie and redirects to original requested resource
		 *
		 * @param   string	$uid		unique value representing user
		 * @param   string	$permanent	specifies whether cookie is permanent
		 * @return  void
		 */
		public static function redirectFromLoginPage( $uid, $permanent = false )
		{
			$request = new \System\IO\HTTPRequest();
			$response = new \System\IO\HTTPResponse();
			FormsAuthentication::setAuthCookie( $uid, $permanent );
			\System\AppServlet::getInstance()->session->write();

			if( isset( $request['returnUrl'] ))
			{
				$response->redirect( $request['returnUrl'] );
			}
			else
			{
				$response->redirect( \System\HTTPAppServlet::getInstance()->getPageURI( \System\AppServlet::getInstance()->config->defaultController ));
			}
		}


		/**
		 * redirects to login page
		 *
		 * @return  void
		 */
		public static function redirectToLoginPage()
		{
			$response = new \System\IO\HTTPResponse();
			// fixed bug when request parameters present
			$response->redirect( \System\HTTPAppServlet::getInstance()->getPageURI( \System\AppServlet::getInstance()->config->authenticationFormsLoginPage, array( 'returnUrl' => $_SERVER["REQUEST_URI"] )));
			// $response->redirect( \System\HTTPAppServlet::getInstance()->getPageURI( \System\AppServlet::getInstance()->config->authenticationFormsLoginPage, array( 'returnUrl' => \System\AppServlet::getInstance()->thisPage )));
		}


		/**
		 * sets auth cookie
		 *
		 * @param   string	$uid		unique value representing user
		 * @param   string	$permanent	specifies whether cookie is permanent
		 * @return  void
		 */
		public static function setAuthCookie( $uid, $permanent = false )
		{
			if( $permanent )
			{
				// set cookie for 1 year
				$response = new \System\IO\HTTPResponse();
				$response->setCookie(\System\AppServlet::getInstance()->config->authenticationCookieName, $uid, \System\AppServlet::getInstance()->config->sessionTimeout, '/' );
				$response->send();
			}
			else
			{
				// set session cookie
				$session = \System\AppServlet::getInstance()->session;
				$session[\System\AppServlet::getInstance()->config->authenticationCookieName] = $uid;
			}
		}


		/**
		 * gets auth cookie
		 *
		 * @return  string
		 */
		public static function getAuthCookie()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName];
			}
			elseif( isset( $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName];
			}
			else
			{
				throw new \System\InvalidOperationException("Auth cookie does not exist, call FormsAuthentication::isAuthCookieSet()");
			}
		}


		/**
		 * returns true if auth cookie is set
		 *
		 * @return  bool
		 */
		public static function isAuthCookieSet()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return true;
			}
			elseif( isset( $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/**
		 * perform sign out (does not end session)
		 *
		 * @return  void
		 */
		public static function signout()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				unset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] );
			}

			$response = new \System\IO\HTTPResponse();
			$response->setCookie(\System\AppServlet::getInstance()->config->authenticationCookieName, '', time()-1000 );
			$response->send();

			\System\AppServlet::getInstance()->setForwardPage();
		}
	}
?>