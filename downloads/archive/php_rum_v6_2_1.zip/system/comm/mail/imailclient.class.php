<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Comm\Mail;


	/**
	 * Provides the interface for Mail Clients
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	interface IMailClient
	{
		/**
		 * sends email
		 *
		 * sends a single email to all addresses in message
		 *
		 * @param  MailMessage $mailMessage MailMessage object
		 * @return void
		 */
		public function send(MailMessage $mailMessage);
	}
?>