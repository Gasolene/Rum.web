<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Comm\Mail;


	/**
	 * Represents an E-Mail Message
	 *
	 * @property string $to E-mail address to send message to
	 * @property string $from Return address
	 * @property string $subject Message subject
	 * @property string $body Message body
	 * @property string $charset Message character set
	 * @property string $contentType Message content-type
	 * @property string $encoding Message encoding
	 * @property bool $html Specifies whether to send as html
	 * @property array $cc array of addresses to be copied
	 * @property array $bcc array of addresses to be blind copied
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class MailMessage
	{
		/**
		 * email address to send message to
		 * @var string
		 */
		protected $to				= '';

		/**
		 * email addresses to copy message to
		 * @var array
		 */
		protected $cc				= array();

		/**
		 * email addresses to blind copy message to
		 * @var array
		 */
		protected $bcc				= array();

		/**
		 * return address
		 * @var string
		 */
		protected $from				= '';

		/**
		 * message subject
		 * @var string
		 */
		protected $subject			= '';

		/**
		 * message body
		 * @var string
		 */
		protected $body				= '';

		/**
		 * message character set
		 * @var string
		 */
		protected $charset			= "iso-8859-1";

		/**
		 * message content-type
		 * @var string
		 */
		protected $contentType		= "text/plain";

		/**
		 * message encoding mode
		 * @var string
		 */
		protected $encoding			= "7bit";

		/**
		 * specifies whether to send as html
		 * @var bool
		 */
		protected $html				= true;

		/**
		 * file attachments
		 * @var array
		 */
		protected $attachments		= array();

		/**
		 * unique content seperator
		 * @var string
		 */
		private $_unique_sep		= "";


		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function MailMessage()
		{
			$this->_unique_sep = md5( uniqid( time() ));
		}


		/**
		 * returns an object property
		 *
		 * @return void
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'to' )
			{
				return $this->to;
			}
			elseif( $field === 'from' )
			{
				return $this->from;
			}
			elseif( $field === 'subject' )
			{
				return $this->subject;
			}
			elseif( $field === 'body' )
			{
				return $this->body;
			}
			elseif( $field === 'charset' )
			{
				return $this->charset;
			}
			elseif( $field === 'contentType' )
			{
				return $this->contentType;
			}
			elseif( $field === 'encoding' )
			{
				return $this->encoding;
			}
			elseif( $field === 'html' )
			{
				return $this->html;
			}
			elseif( $field === 'cc' )
			{
				return $this->cc;
			}
			elseif( $field === 'bcc' )
			{
				return $this->bcc;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @return void
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'to' )
			{
				$this->setTo( $value );
			}
			elseif( $field === 'from' )
			{
				$this->setFrom( $value );
			}
			elseif( $field === 'subject' )
			{
				$this->setSubject( $value );
			}
			elseif( $field === 'body' )
			{
				$this->setBody( $value );
			}
			elseif( $field === 'charset' )
			{
				$this->setCharset( $value );
			}
			elseif( $field === 'contentType' )
			{
				$this->setContentType( $value );
			}
			elseif( $field === 'encoding' )
			{
				$this->setEncoding( $value );
			}
			elseif( $field === 'html' )
			{
				$this->html = (bool)$value;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * set recipient email address
		 *
		 * multiple email addresses can be seperated by a comma
		 *
		 * @return void
		 */
		public function setTo( $to )
		{
			if( preg_match( '^.+@.+\\.[a-zA-Z]+^', $to ))
			{
				$this->to = $this->_sterilize( $to );
			}
			else
			{
				throw new \System\InvalidOperationException("invalid email address specified in Message::setTo()");
			}
		}


		/**
		 * set sender's email address
		 *
		 * multiple email addresses can be seperated by a comma
		 *
		 * @return void
		 */
		public function setFrom( $from )
		{
			if( preg_match( '^.+@.+\\.[a-zA-Z]+^', $from ))
			{
				$this->from = $this->_sterilize( $from );
			}
			else
			{
				throw new \System\InvalidOperationException("invalid email address specified in Message::setFrom()");
			}
		}


		/**
		 * set message subject
		 *
		 * @return void
		 */
		public function setSubject( $subject )
		{
			$this->subject = $this->_sterilize( $subject );
		}


		/**
		 * set message body
		 *
		 * @return void
		 */
		public function setBody( $body )
		{
			$this->body = $body;
		}


		/**
		 * set character set
		 *
		 * @return void
		 */
		public function setCharset( $charset )
		{
			$this->charset = $this->_sterilize( $charset );
		}


		/**
		 * set content type
		 *
		 * @return void
		 */
		public function setContentType( $contentType )
		{
			$this->contentType = $this->_sterilize( $contentType );
		}


		/**
		 * set character encoding
		 *
		 * @return void
		 */
		public function setEncoding( $encoding )
		{
			$this->encoding = $this->_sterilize( $encoding );
		}


		/**
		 * add a single email address to the cc list
		 *
		 * @return void
		 */
		public function addCc( $address )
		{
			if( preg_match( '^.+@.+\\.[a-zA-Z]+^', $address ))
			{
				array_push( $this->cc, $this->_sterilize( $address ));
			}
			else
			{
				throw new \System\InvalidOperationException("invalid email address specified in Message::addCc()");
			}
		}


		/**
		 * add a single email address to the bcc list
		 *
		 * @return void
		 */
		public function addBcc( $address )
		{
			if( preg_match( '^.+@.+\\.[a-zA-Z]+^', $address ))
			{
				array_push( $this->bcc, $this->_sterilize( $address ));
			}
			else
			{
				throw new \System\InvalidOperationException("invalid email address specified in Message::addBcc()");
			}
		}


		/**
		 * attach a file
		 *
		 * @return void
		 */
		public function attach( $path, $mimetype = 'application/octet-stream', $filename = '' )
		{
			if( file_exists( $path ))
			{
				$filename = $filename?$filename:substr( $path, strrpos( $path, '/' ) + 1, strlen( $path ));
				$this->attachments[] = array( 'file' => $path, 'mimetype' => $mimetype, 'filename' => $filename );
			}
			else
			{
				throw new \System\InvalidOperationException( 'file does not exist ' . $path );
			}
		}


		/**
		 * return message headers
		 *
		 * @return string				mail headers
		 */
		public function getHeaders()
		{
			$eol = $this->_getEOLSeperator();

			// build header
			$headers  = "MIME-Version: 1.0{$eol}";
			$headers .= 'To: ' . (string) $this->to . "{$eol}";
			$headers .= 'From: ' . (string) $this->from . "{$eol}";
			$headers .= 'Return-Path: ' . (string) $this->from . "{$eol}";
			$headers .= 'X-Sender: ' . (string) $this->from . "{$eol}";
			$headers .= 'Date: ' . gmdate('r') . "{$eol}";
			$headers .= 'X-Mailer: PHP/' . phpversion() . "{$eol}";
			$headers .= "Content-Type: multipart/mixed; boundary=\"{$this->_unique_sep}\"{$eol}";
			$headers .= 'Content-Transfer-Encoding: ' . (string) $this->encoding . "{$eol}";

			// recipients
			if( $this->cc ) {
				$headers .= 'Cc: ' . implode( ',', $this->cc ) . "$eol";
			}
			if( $this->bcc ) {
				$headers .= 'Bcc: ' . implode( ',', $this->bcc ) . "$eol";
			}

			return $headers;
		}


		/**
		 * return message content
		 *
		 * @return string				mail content
		 */
		public function getContent()
		{
			$eol = $this->_getEOLSeperator();

			// contentType selector
			if( $this->html )
			{
				$this->contentType = 'text/html';
			}

			$message = '';

			// add attachments
			if( sizeof( $this->attachments )) {

				// loop through attachments
				foreach( $this->attachments as $attachment ) {

					// read data from file
					$filedata = implode( file( $attachment['file'] ), '');

					$message .= "--{$this->_unique_sep}{$eol}";
					$message .= "Content-Type: {$attachment['mimetype']}; name=\"{$attachment['filename']}\"{$eol}";
					$message .= "Content-Transfer-Encoding: base64{$eol}";
					$message .= "Content-Disposition: attachment{$eol}{$eol}";
					$message .= chunk_split( base64_encode( $filedata ));
				}
			}

			// send actual message
			$message .= "--{$this->_unique_sep}{$eol}";
			$message .= 'Content-Type: ' . (string) $this->contentType . "; charset=" . (string) $this->charset . "{$eol}";
			$message .= 'Content-Transfer-Encoding: ' . (string) $this->encoding . "{$eol}{$eol}";
			$message .= $this->body . "{$eol}{$eol}";

			$message .= "--{$this->_unique_sep}--{$eol}";

			return $message;
		}


		/**
		 * return end of line seperator
		 *
		 * @return string
		 */
		private function _getEOLSeperator() {
			if( strtoupper( substr( PHP_OS, 0, 3 ) === 'WIN' )) {
				return "\r\n";
			} elseif( strtoupper( substr( PHP_OS, 0, 3 ) === 'MAC' )) {
				return "\r";
			} else {
				return "\n";
			}
		}


		/**
		 * test for header insertion hacks and sterilize output (removes any linebreaks)
		 *
		 * @param  string	$str	string to sterilize
		 * @return void
		 */
		private function _sterilize( $str )
		{
			// check for header insertion attacks
			if( preg_match( '/[\n\r]/', (string) $str )) {
				\System\AppServlet::getInstance()->log( 'header injection attack detected from IP ' . $_SERVER['REMOTE_ADDR'], 'mail.txt' );

				// clean output
				$str = str_replace( "\n", '', str_replace( "\r", '', (string) $str ));
			}

			return $str;
		}
	}
?>