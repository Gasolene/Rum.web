<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Comm\Mail;


	/**
	 * Handles email sending via PHP mail() function
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class PHPMailClient implements IMailClient
	{
		/**
		 * sends email
		 *
		 * sends a single email to all addresses in message
		 *
		 * @param  MailMessage $mailMessage MailMessage object
		 * @return void
		 */
		public function send(MailMessage $mailMessage)
		{
			if( !mail( $mailMessage->to, $mailMessage->subject, $mailMessage->getContent(), $mailMessage->getHeaders() ))
			{
				throw new \System\InvalidOperationException("mail was not accepted for delivery, check php mail configuration");
			}
		}
	}
?>