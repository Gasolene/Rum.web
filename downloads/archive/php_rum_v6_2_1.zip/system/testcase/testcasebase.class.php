<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Testcase;
	use \UnitTestCase;

	/**
	 * include simpletest framework
	 */
	require_once __LIB_PATH__ . '/simpletest/unit_tester.php';


	/**
	 * Provides base functionality for the TestCase
	 *
	 * @property string $fixtures comma seperated string containing fixture filenames
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class TestCaseBase extends UnitTestCase
	{
		/**
		 * fixtures to load
		 * @var string
		 */
		protected $fixtures				= '';


		/**
		 * Constructor
		 *
		 * @param   string			$testCase		Name of test case
		 * @return  void
		 * @ignore
		 */
		public function TestCaseBase( $testCase = '' ) {
			parent::__construct( $testCase );
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __set( $field, $value ) {
			throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
		}


		/**
		 * setup test module
		 *
		 * @return  void
		 * @ignore
		 */
		public function setUp() {
			parent::setUp();

			$this->loadFixtures( $this->fixtures );
			$this->prepare();
		}


		/**
		 * clean test module
		 *
		 * @return  void
		 * @ignore
		 */
		public function tearDown() {
			parent::tearDown();

			$this->cleanup();
		}


		/**
		 * run report
		 *
		 * @param   TestReporter	$reporter	TestReporter object
		 *
		 * @return  void
		 */
		public function run( \SimpleReporter &$reporter ) {
			$context = \SimpleTest::getContext();
			$context->setTest($this);
			$context->setReporter($reporter);
			$this->_reporter = &$reporter;
			$reporter->paintCaseStart($this->getLabel());
			$this->skip();
			if (! $this->_should_skip) {
				foreach ($this->getTests() as $method) {
					if ($reporter->shouldInvoke($this->getLabel(), $method)) {
						$invoker = &$this->_reporter->createInvoker($this->createInvoker());
						$invoker->before($method);
						$invoker->invoke($method);
						$invoker->after($method);
					}
				}
			}
			$reporter->setElapsedTime( \System\HTTPAppServlet::getInstance()->timer->elapsed() );
			$reporter->paintCaseEnd($this->getLabel());
			unset($this->_reporter);
			return $reporter->getStatus();
		}


		/**
		 * called before evey test
		 *
		 * @return  void
		 */
		protected function prepare() {
		}


		/**
		 * called after evey test
		 *
		 * @return  void
		 */
		protected function cleanup() {
		}


		/**
		 * load fixtures
		 *
		 * @param   array		$fixtures		array of fixtures
		 * @return  void
		 */
		final protected function loadFixtures( $fixtures )
		{
			if($fixtures)
			{
				\System\AppServlet::getInstance()->dataAdapter->setForeignKeyChecks(FALSE);

				foreach( \System\AppServlet::getInstance()->dataAdapter->getTables()->rows as $row )
				{
					$row = array_values($row);
					try
					{
						\System\AppServlet::getInstance()->dataAdapter->execute( 'TRUNCATE `' . $row[0] . '`;' );
					}
					catch(SQLException $e)
					{
						throw new \System\InvalidOperationException( "could not truncate table " . $e->getMessage() );
					}
				}

				if( strlen( $fixtures) > 0 )
				{
					$fixtures = explode( ',', $fixtures );

					foreach( $fixtures as $fixture )
					{
						if( strpos( $fixture, '.xml' ))
						{
							$this->loadXMLFixture( trim( $fixture ));
						}
						elseif( strpos( $fixture, '.csv' ))
						{
							$this->loadCSVFixture( trim( $fixture ));
						}
						elseif( strpos( $fixture, '.sql' ))
						{
							$this->loadSQLFixture( trim( $fixture ));
						}
						else
						{
							throw new \System\InvalidOperationException( "fixture must be one of type .xml, .csv, or .sql" );
						}
					}
				}

				\System\AppServlet::getInstance()->dataAdapter->setForeignKeyChecks(TRUE);
			}
		}


		/**
		 * load xml fixture
		 *
		 * @param   string		$fixture		name of fixture
		 * @return  void
		 */
		final protected function loadXMLFixture( $fixture )
		{
			if($fixture)
			{
				$tables = array();
				foreach( \System\AppServlet::getInstance()->dataAdapter->getTables()->rows as $row )
				{
					$row = array_values($row);
					$tables[] = $row[0];
				}

				$xmlParser = new \System\XML\XMLParser();
				$fail = false;

				$e = null;
				try
				{
					$xml = $xmlParser->parse( file_get_contents( \System\AppServlet::getInstance()->config->fixtures . '/' . $fixture ));

					foreach( $xml->children as $record )
					{
						$ds = \System\AppServlet::getInstance()->dataAdapter->openDataSet( $this->_arrayLsearch( $record->name, $tables ));

						$fields = array_keys( $ds->row );
						$fieldnames = '';
						$fieldvalues = '';

						foreach( $record->children as $column )
						{
							if( $fieldnames )
							{
								$fieldnames .= ',`' . $this->_arrayLsearch( $column->name, $fields ) . '`';
							}
							else
							{
								$fieldnames .= '`' . $this->_arrayLsearch( $column->name, $fields ) . '`';
							}

							if( isset( $column["EVAL"] ))
							{
								if( strtolower( $column["EVAL"] ) === 'true' )
								{
									eval('$column->value='.$column->value.';');
								}
							}

							if( $fieldvalues )
							{
								$fieldvalues .= ',"' . addslashes( $column->value ) . '"';
							}
							else
							{
								$fieldvalues .= '"' . addslashes( $column->value ) . '"';
							}
						}

						$sql = '
							INSERT INTO
								`' . $this->_arrayLsearch( $record->name, $tables ) . '` (' . $fieldnames . ')
							VALUES( ' . $fieldvalues . ');';

						try
						{
							\System\AppServlet::getInstance()->dataAdapter->execute( $sql );
						}
						catch(SQLException $e)
						{
							throw new \System\InvalidOperationException( "could not execute XML fixture " . $e->getMessage() );
						}
					}
				}
				catch(XMLException $e)
				{
					throw new \System\XMLException( "could not parse XML fixture " . $e->getMessage() );
				}
			}
		}


		/**
		 * load csv fixture
		 *
		 * @param   string		$fixture		name of fixture
		 * @return  bool
		 */
		final protected function loadCSVFixture( $fixture )
		{
			if($fixture)
			{
				throw new \System\MethodNotImplementedException();

				$ds = \System\AppServlet::getInstance()->dataAdapter->openDataSet( $fixture );
				$fp = fopen( \System\AppServlet::getInstance()->config->fixtures . '/' . $fixture, 'r' );
				$rows = fgetcsv($fp);

				foreach($rows as $row)
				{
					$ds->row = $row;
					$ds->insert();
				}
			}
		}


		/**
		 * load sql fixture
		 *
		 * @param   string		$fixture		name of fixture
		 * @return  void
		 */
		final protected function loadSQLFixture( $fixture )
		{
			if($fixture)
			{
				$sql = file_get_contents( \System\AppServlet::getInstance()->config->fixtures . '/' . $fixture );
				$fail = false;

				if( $sql )
				{
					// seperate into multiple queries
					$queries = explode( ";", $sql );

					foreach( $queries as $query )
					{
						if( trim( $query ))
						{
							$e = null;
							try
							{
								\System\AppServlet::getInstance()->dataAdapter->execute( $query );
							}
							catch(SQLException $e)
							{
								throw new \System\InvalidOperationException( "could not execute SQL fixture " . $e->getMessage() );
							}
						}
					}
				}
				else
				{
					throw new \System\IO\FileLoadException( 'could not open fixture file ' . \System\AppServlet::getInstance()->config->fixtures . '/' . $fixture );
				}
			}
		}


		/**
		 * search for string in array
		 *
		 * @param string $str
		 * @param array $array
		 * @return int index of element
		 */
		private function _arrayLsearch( $str, $array ) {
			foreach($array as $k=>$v){
				if(strtolower($v)===strtolower($str)){
					return $v;
				}
			}

			throw new \System\InvalidOperationException("{$str} does not exist in array");
		}
	}
?>