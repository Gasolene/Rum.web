<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Controllers;


	/**
	 * Provides base functionality for the Page Controller
	 *
	 * @property int $outputCache Output cache in seconds
	 * @property Page $page Page control
	 * @property bool $isPostBack Specifies if the request is a postback
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class PageControllerBase extends ControllerBase
	{
		/**
		 * instance of a Page component
		 * @var Page
		 */
		protected $page					= null;

		/**
		 * specifies the theme for this page
		 * @var string
		 */
		protected $theme				= '';

		/**
		 * specifies if the request is a postback
		 * @var bool
		 */
		private $isPostBack		   = false;


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		final public function __get( $field )
		{
			if( $field === 'controllerId' )
			{
				return (string)$this->controllerId;
			}
			elseif( $field === 'outputCache' )
			{
				return (int)$this->outputCache;
			}
			elseif( $field === 'isPostBack' )
			{
				return (bool)$this->isPostBack;
			}
			elseif( $field === 'page' )
			{
				return $this->page;
			}
			else
			{
				if( $this->page )
				{
					$control = $this->page->findControl($field);

					if( !is_null( $control ))
					{
						return $control;
					}
					else
					{
						throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
					}
				}
				else
				{
					throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
				}
			}
		}


		/**
		 * This method will process the request and impliment the page life cycles
		 *
		 * @param   HTTPRequest		&$request	HTTPRequest object
		 * @return  void
		 */
		public function requestProcessor( \System\IO\HTTPRequest &$request )
		{
			$this->theme = $this->theme?$this->theme:\System\AppServlet::getInstance()->config->theme;

			$requestData =& $request->getRequestData();
			$session =& \System\AppServlet::getInstance()->session->getSessionData();
			$docName = str_replace( '/', '.', strtolower( $this->controllerId ));

			$this->isPostBack = strtoupper($request->getRequestMethod())==='POST'?true:false;

			/**
			 * Page Creation
			 * create Page component
			**/
			$this->page = new \System\UI\WebControls\Page( 'page' );

			// set template implicitly
			$this->page->template = \System\AppServlet::getInstance()->config->views . '/' . strtolower( $this->controllerId ) . __TEMPLATE_EXTENSION__;

			// set title implicitly
			$this->page->title = str_replace( ' / ', '/', ucwords( str_replace( '/', ' / ' , strtolower( $this->controllerId ))));

			// include jscripts
			if( \System\AppServlet::getInstance()->config->state == \System\AppState::Debug() )
			{
				$this->page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/debug/debug.js' );
				$this->page->addLink( \System\HTTPAppServlet::getInstance()->config->assets . '/debug/debug.css' );
			}

			// include all css files for theme
			foreach( glob( \System\AppServlet::getInstance()->config->htdocs . substr( \System\AppServlet::getInstance()->config->themes, strlen( \System\AppServlet::getInstance()->config->uri )) . '/' . $this->theme . "/*.css" ) as $stylesheet )
			{
				$this->page->addLink( \System\AppServlet::getInstance()->config->themes . '/' . $this->theme . strrchr( $stylesheet, '/' ));
			}

			/**
			 * onInit Event
			 * create the initial components and set their default values
			**/
			$this->page->init(); // initiates onInit event for each control


			/**
			 * Load Viewstate
			 * restore each components to its previous viewstate
			**/
			if( isset( $session[ \System\AppServlet::getInstance()->applicationId
				. '.' . $docName
				. '.viewstate'] )) {

				$sessionArray = unserialize( $session[ \System\AppServlet::getInstance()->applicationId
				. '.' . $docName
				. '.viewstate'] );

				$this->page->loadViewState( $sessionArray );
			}


			/**
			 * onLoad Event
			 * components and component relationships have been established
			 * but their data has not been updated from the request
			**/
			$this->page->load( $requestData ); // initiates onLoad event for each control


			/**
			 * execute async handler for control if exists
			**/
			if( isset( $request[\System\AppServlet::getInstance()->config->asyncParameter] ))
			{
				$control = $this->page->findControl( $request[\System\AppServlet::getInstance()->config->asyncParameter] );
				if( $control )
				{
					// send DataSet as xml message
					$this->page = new \System\UI\WebControls\View( 'datasource' );
					$this->page->contentType = 'text/xml';
					$this->page->setData( $control->getXMLString() );
					return;
				}
			}


			/**
			 * Process Request
			**/


			/**
			 * Load Request
			 * update all components with data from the request
			**/
			$this->page->requestProcessor( $requestData );


			/**
			 * onPost Event
			 * post data has been submitted
			**/
			if( strtoupper( $request->getRequestMethod() ) === 'POST' )
			{
				/**
				 * Post Events
				 * each component will invoke an onPost event if data has been posted
				 * or an onChange event if component value has changed from it's last 
				 * viewstate
				**/
				$this->page->handlePostEvents( $requestData );
			}


			/**
			 * onPreRender event
			 * update all components with data from the request
			**/
			$this->page->preRender();


			/**
			 * Save Viewstate
			 * save the state of all components in a persistant layer
			**/
			$sessionArray = array();
			$this->page->saveViewState( $sessionArray );
			$session[ \System\AppServlet::getInstance()->applicationId
				. '.' . $docName
				. '.viewstate'] = serialize( $sessionArray );

			/**
			 * onAsync Event
			 * handle asnyc requests
			**/
			if( isset( $request[\System\AppServlet::getInstance()->config->asyncParameter] ))
			{
				$this->page->handleAjaxEvents( $requestData );
			}
		}


		/**
		 * return view component for rendering
		 *
		 * @return  object			view component
		 */
		public function getView()
		{
			return $this->page;
		}

		/* backwards compatibility */

		/**
		 * @ignore
		 */
		public function oldInit($request)
		{
			$this->onInit($request);
		}

		/**
		 * @ignore
		 */
		public function oldLoad($request)
		{
			$this->onLoad($request);
		}

		/**
		 * @ignore
		 */
		public function oldRequest($request)
		{
			$this->oldRequest($request);
		}

		/**
		 * @ignore
		 */
		public function oldPost($request)
		{
			$this->onPost($request);
		}

		/**
		 * @ignore
		 */
		public function oldPreRender($request)
		{
			$this->onPreRender($request);
		}
	}
?>