<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Provides access to a generic data source
	 *
	 * @property bool $opened Specifies whether the connection is open
	 * @property bool $closed Specifies whether the connection is closed
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class DataAdapter
	{
		/**
		 * A collection of connection variables
		 * @var array
		 */
		protected $args					= array();

		/**
		 * Handle to the open connection to the datasource
		 * @var resource
		 */
		protected $link					= null;


		/**
		 * Constructor
		 *
		 * @param   array	$args	connection arguments
		 * @return void
		 */
		final protected function DataAdapter( array $args ) {
			$this->args = $args;
			$this->open();
		}


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'opened' ) {
				return (bool) $this->link;
			}
			elseif( $field === 'closed' ) {
				return (bool) !$this->link;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * creates a connection object to a datasource
		 *
		 * Examples:
		 * <code>
		 * adapter=mysql;uid=root;pwd=;server=localhost;database=northwind;
		 * adapter=mssql;uid=root;pwd=;server=localhost;database=northwind;
		 * adapter=odbc;uid=root;pwd=;server=localhost;database=northwind;
		 * adapter=text;format=TabDelimited;source=/northwind.csv;
		 * adapter=dir;source=/northwind;
		 * adapter=xml;source=/northwind.xml;
		 * adapter=MyDataAdapter;myparam=northwind;
		 * </code>
		 *
		 * @param   string   $dsn   connection string
		 * @return  	DataAdapter
		 */
		final static public function create( $dsn )
		{
			$args = array( 'server' => 'localhost' );
			$var = explode( ';', (string) $dsn );
			$count = sizeof( $var );
			for( $i=0; $i < $count; $i++ ) {
				$pair = explode( '=', $var[$i] );
				if( isset( $pair[1] )) {
					$args[strtolower(trim($pair[0]))] = trim($pair[1]);
				}
			}

			if( isset( $args['adapter'] ) || isset( $args['driver'] )) {

				// get driver
				$adapter = isset( $args['adapter'] )?$args['adapter']:$args['driver'];
				$da = null;

				/**
				 * Create an object to handle this type of 
				 * connection based on the specified driver
				 */

				/* MySQL adapter */
				if( $adapter === 'mysql' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/mysqldataadapter' . __CLASS_EXTENSION__;
					$da = new MySQLDataAdapter( $args );
				}
				/* MySQLi improved adapter */
				elseif( $adapter === 'mysqli' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/mysqlidataadapter' . __CLASS_EXTENSION__;
					$da = new MySQLiDataAdapter( $args );
				}
				/* MSSQL adapter */
				elseif( $adapter === 'mssql' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/mssqldataadapter' . __CLASS_EXTENSION__;
					$da = new MSSQLDataAdapter( $args );
				}
				/* PostgreSQL adapter */
				elseif( $adapter === 'postgresql' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/postgresqldataadapter' . __CLASS_EXTENSION__;
					$da = new PostgreSQLDataAdapter( $args );
				}
				/* Text File adapter */
				elseif( $adapter === 'text' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/textdataadapter' . __CLASS_EXTENSION__;
					$da = new TextDataAdapter( $args );
				}
				/* File System adapter */
				elseif( $adapter === 'dir' ) {
					include_once __SYSTEM_PATH__ . '/data/adapters/dirdataadapter' . __CLASS_EXTENSION__;
					$da = new DirDataAdapter( $args );
				}
				else {
					if( class_exists( $adapter )) {
						$da = new $adapter( $args );
					}
					else {
						throw new DataAdapterException("DataAdapter $adapter adapter not supported");
					}
				}

				// return object
				return $da;
			}
			else {
				throw new DataAdapterException("no DataAdapter specified");
			}
		}


		/**
		 * opens a DataSet specified by the source
		 *
		 * @param  string		$source		source string (or QueryBuilder)
		 * @param  DataSetType	$lock_type	lock type as constant of DataSetType::OpenDynamic(), DataSetType::OpenStatic(), or DataSetType::OpenReadonly()
		 * @return DataSet					return DataSet
		 */
		final public function openDataSet( $source = '', DataSetType $lock_type = null )
		{
			return DataSet::addNew( $source, $this, $lock_type );
		}


		/**
		 * fetches DataSet from datasource string using source string
		 *
		 * @param  DataSet			&$ds			reference to a DataSet object
		 * @return void
		 */
		abstract public function fill( DataSet &$ds );


		/**
		 * opens a connection to a datasource
		 *
		 * @return bool					true if successfull
		 */
		abstract public function open();


		/**
		 * closes an open connection
		 *
		 * @return bool					true if successfull
		 */
		abstract public function close();


		/**
		 * attempt to insert a record into the datasource
		 *
		 * @param  DataSet	$ds		reference to a DataSet
		 * 
		 * @return bool					true if successfull
		 */
		abstract public function insertDataRecord( DataSet &$ds );


		/**
		 * attempt to update a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return bool						true if successfull
		 */
		abstract public function updateDataRecord( DataSet &$ds );


		/**
		 * attempt to delete a record in the datasource
		 * 
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return bool						true if successfull
		 */
		abstract public function deleteDataRecord( DataSet &$ds );
	}
?>