<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents an open connection to the file system
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class DirDataAdapter extends DataAdapter
	{
		/**
		 * fetches DataSet from datasource string using source string
		 *
		 * @param  DataSet	&$ds			empty DataSet object
		 * @return void
		 */
		public function fill( DataSet &$ds )
		{
			if( $this->link )
			{
				$fieldnames = array( 'name', 'path', 'size', 'modified', 'accessed', 'created', 'isfolder' );
				$files = array();
				$folders = array();

				while(( $file = readdir( $this->link )) !== false ) {
					if( $file != '.' && $file != '..') {
						if( is_file( $this->args['source'] . '/' . $file )) {
							$files[] = new \System\IO\File( $this->args['source'] . '/' . $file );
						}
						elseif( is_dir( $this->args['source'] . '/' . $file )) {
							$folders[] = new \System\IO\Folder( $this->args['source'] . '/' . $file );
						}
					}
				}

				/*
				 * create field objects
				 * 
				 * this code loops through fields of resultset
				 * checks is field is primary key, if so, set the primary key field name
				 * then adds all field names to an array
				 *
				 * cannot be used when resultset is emtpy (mysql_num_fields wil fail)
				 */
				$fields = array();
				foreach( $fieldnames as $fieldname )
				{
					$field = new DataField;
					$field->name = $fieldname;

					if( $fieldname === 'name' || $fieldname === 'path' ) {
						$field->type = 'string';
						$field->string = true;
					}
					else {
						$field->type = 'int';
						$field->integer = true;
					}

					// add field to field array
					$fields[] = $field;
				}

				// set fields
				$ds->setFields($fields);

				/*
				 * create record objects
				 * 
				 * this code loops through all rows and fields
				 * then creates the following array...
				 * DataSet[row number][field name] = value
				 */
				$rows = array();
				foreach( $folders as $folder ) {

					$row = array();
					$row[$fieldnames[0]] = $folder->name;
					$row[$fieldnames[1]] = $folder->path;
					$row[$fieldnames[2]] = 0;
					$row[$fieldnames[3]] = $folder->modified;
					$row[$fieldnames[4]] = $folder->accessed;
					$row[$fieldnames[5]] = $folder->created;
					$row[$fieldnames[6]] = 1;

					$rows[] = $row;
				}

				foreach( $files as $file ) {

					$row   = array();
					$row[$fieldnames[0]] = $file->name;
					$row[$fieldnames[1]] = $file->path;
					$row[$fieldnames[2]] = $file->size;
					$row[$fieldnames[3]] = $file->modified;
					$row[$fieldnames[4]] = $file->accessed;
					$row[$fieldnames[5]] = $file->created;
					$row[$fieldnames[6]] = 0;

					$rows[] = $row;
				}

				// set rows
				$ds->setRows($rows);
			}
			else
			{
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * opens a connection to a filesystem resource
		 *
		 * @return bool						TRUE if successfull
		 */
		public function open()
		{
			if( !$this->link )
			{
				if( isset( $this->args['source'] ))
				{
					if( is_dir( (string) $this->args['source'] ))
					{
						$this->link = opendir($this->args['source']);
						if( $this->link )
						{
							return true;
						}
						else
						{
							throw new \System\InvalidOperationException("could not open directory");
						}
					}
					else
					{
						throw new \System\InvalidOperationException("{$this->args['source']} is not a valid directory");
					}
				}
				else
				{
					throw new DataAdapterException("missing required connection string parameter {$this->args['source']}");
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection already open");
			}
		}


		/**
		 * closes an open connection
		 *
		 * @return bool					true if successfull
		 */
		public function close()
		{
			if( $this->link )
			{
				closedir($this->link);
				$this->link = null;
				return true;
			}
			else
			{
				throw new \System\InvalidOperationException("connection already closed");
			}
		}


		/**
		 * attempt to insert a record into the datasource
		 *
		 * @param  DataSet	$ds		reference to a DataSet
		 * @return void
		 */
		public function insertDataRecord( DataSet &$ds )
		{
			throw new \System\MethodNotImplementedException();
		}


		/**
		 * attempt to update a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		public function updateDataRecord( DataSet &$ds )
		{
			throw new \System\MethodNotImplementedException();
		}


		/**
		 * attempt to delete a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		public function deleteDataRecord( DataSet &$ds )
		{
			throw new \System\MethodNotImplementedException();
		}
	}
?>