<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents an open connection to a MySQL database
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class MySQLDataAdapter extends SQLDataAdapter
	{
		/**
		 * fetches DataSet from database string using source string
		 *
		 * @param  DataSet	&$ds		empty DataSet object
		 * @return void
		 */
		public function fill( DataSet &$ds )
		{
			if( $this->link )
			{
				$source = '';
				if( $ds->source instanceof QueryBuilder )
				{
					$source = $this->getQuery( $ds->source );
				}
				elseif( !strstr( strtolower($ds->source), 'select' ) &&
					!strstr( strtolower($ds->source), 'describe' ) &&
					!strstr( strtolower($ds->source), 'show' ))
				{
					// source is table name
					$source = 'select * from `' . $ds->source . '`';
				}
				else
				{
					$source = $ds->source;
				}

				// establish link to db resource
				// replaced mysql_query with $this->execute
				$result = $this->executeInternal( $source );
				if( $result )
				{
					// set properties
					$ds->setProperty('table', mysql_field_table( $result, 0 ));

					/*
					 * create field objects
					 *
					 * this code loops through fields of resultset
					 * checks is field is primary key, if so, set the primary key field name
					 * then adds all field names to an array
					 *
					 * cannot be used when resultset is emtpy (mysql_num_fields wil fail)
					 */
					$colcount = mysql_num_fields( $result );
					$fields = array();
					for( $i=0; $i < $colcount; $i++ )
					{
						if(false === \strpos(mysql_field_name( $result, $i ), '.'))
						{
							$field = new DataField();

							// mysql field info
							$field->name		  =		  mysql_field_name ( $result, $i );
							$field->table		  =		  mysql_field_table( $result, $i );
							$field->length		  =		  mysql_field_len  ( $result, $i );
							$field->type		  =		  mysql_field_type ( $result, $i );

							// mysql column types
							$field->string		  = (bool) ( mysql_field_type ( $result, $i ) === 'string' );
							$field->integer		  = (bool) ( mysql_field_type ( $result, $i ) === 'int' ||
															 mysql_field_type ( $result, $i ) === 'timestamp' );
							$field->real		  = (bool) ( mysql_field_type ( $result, $i ) === 'real' );
							$field->year		  = (bool) ( mysql_field_type ( $result, $i ) === 'year' );
							$field->date		  = (bool) ( mysql_field_type ( $result, $i ) === 'date' );
							$field->time		  = (bool) ( mysql_field_type ( $result, $i ) === 'time' );
							$field->datetime	  = (bool) ( mysql_field_type ( $result, $i ) === 'datetime' );
							$field->blob		  = (bool) ( mysql_field_type ( $result, $i ) === 'blob' );

							$field->numeric	   = (bool)(( mysql_field_type ( $result, $i ) === 'int' ) ||
														   ( mysql_field_type ( $result, $i ) === 'real' ) ||
														   ( mysql_field_type ( $result, $i ) === 'timestamp' ));

							// fake type (mysql has no boolean column type)
							$field->boolean	   = (bool)(( mysql_field_len  ( $result, $i ) === 1 ) &&
														   ( mysql_field_type ( $result, $i ) === 'int'));

							// mysql field flags
							$field->notNull	   = (bool) ( strpos( mysql_field_flags( $result, $i ), 'not_null' ) !== false );
							$field->primaryKey	= (bool) ( strpos( mysql_field_flags( $result, $i ), 'primary_key' ) !== false );
							$field->unique		= (bool) ( strpos( mysql_field_flags( $result, $i ), 'unique_key' ) !== false );
							// $field->multiple		  = (bool) ( strpos( mysql_field_flags( $result, $i ), 'multiple_key' ) !== false );
							$field->blob		  = (bool) ( strpos( mysql_field_flags( $result, $i ), 'blob' ) !== false );
							$field->binary		= (bool) ( strpos( mysql_field_flags( $result, $i ), 'binary' ) !== false );
							$field->autoIncrement = (bool) ( strpos( mysql_field_flags( $result, $i ), 'auto_increment' ) !== false );

							// add field to field collection
							$fields[$field->name] = $field;
						}
					}

					// set fields
					$ds->setFields( array_values($fields) );

					/*
					 * create record objects
					 *
					 * this code loops through all rows and fields
					 * then creates the following array...
					 * DataSet[row number][field name] = value
					 */
					$rowcount = mysql_num_rows( $result );
					$rows = array();

					for( $row=0; $row < $rowcount; $row++ )
					{
						// add row to DataSet
						$rows[] = mysql_fetch_assoc( $result );
					}

					// set rows
					$ds->setRows( $rows );

					// cleanup
					mysql_free_result( $result );
				}
				else
				{
					throw new SQLException(mysql_error($this->link));
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * opens a connection to a mysql database
		 * @return bool						TRUE if successfull
		 */
		public function open()
		{
			if( !$this->link )
			{
				if( isset( $this->args['server'] ) &&
					isset( $this->args['uid'] ) &&
					isset( $this->args['pwd'] ) &&
					isset( $this->args['database'] ))
				{
					$this->link = mysql_connect( $this->args['server'], $this->args['uid'], $this->args['pwd'], true );

					if( $this->link )
					{
						if( mysql_select_db( $this->args['database'], $this->link ))
						{
							return true;
						}
						else
						{
							throw new SQLException(mysql_error( $this->link ));
						}
					}
					else
					{
						throw new DatabaseException("could not connect to database " . mysql_error());
					}
				}
				else
				{
					throw new DataAdapterException("missing required connection string parameter");
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection already open");
			}
		}


		/**
		 * closes an open connection
		 *
		 * @return bool					true if successfull
		 */
		public function close()
		{
			if( $this->link )
			{
				if( mysql_close( $this->link ))
				{
					$this->link = null;
					return true;
				}
				else
				{
					throw new DatabaseException("could not close mysql connection");
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection already closed");
			}
		}


		/**
		 * attempt to insert a record into the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		final public function insertDataRecord( DataSet &$ds )
		{
			if( $this->link )
			{
				/**
				 * connection to mysql database
				 * attempt to insert record into table using DataSet
				 */
				$set_fields = '';
				$set_values = '';

				// build sql string
				foreach( $ds->fields as $field )
				{
					// get primary key name
					if( $field->autoIncrement )
					{
						$idkey_name = $field->name;
					}
					else
					{
						$set_fields .= '`' . $field->name . '`, ';

						if( $ds[$field->name] === null )
						{
							$set_values .= 'NULL, ';
						}
						elseif( $field->numeric )
						{
							$set_values .= (real)$ds[$field->name] . ', ';
						}
						else
						{
							$set_values .= '"' . $this->getEscapeString($ds[$field->name]) . '", ';
						}
					}
				}

				// rem last comma
				$set_fields = substr( $set_fields, 0, strlen( $set_fields ) - 2 );
				$set_values = substr( $set_values, 0, strlen( $set_values ) - 2 );

				$sql = '
					INSERT INTO `' . $ds->getProperty('table') . '`(' . $set_fields . ')
					VALUES(' . $set_values . ')';

				// insert record into source
				$this->executeInternal( $sql );

				// get primary key value
				if( isset( $idkey_name ))
				{
					$ds[$idkey_name] = $this->getLastInsertId();
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * attempt to update a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		final public function updateDataRecord( DataSet &$ds )
		{
			if( $this->link )
			{
				/**
				 * connection to mysql database
				 * attempt to update record in table using DataSet
				 */
				$set_vars = '';
				$where	= '';

				// get reference to fieldset
				$primarykeys = array();

				// build sql string
				foreach( $ds->fields as $field )
				{
					if( $field->primaryKey )
					{
						$primarykey = array();
						$primarykey['name']	= $field->name;
						$primarykey['numeric'] = (bool) $field->numeric;
						$primarykey['value'] = $ds->rows[$ds->cursor][$field->name];
						$primarykeys[] = $primarykey;
					}

					if( $ds[$field->name] === null )
					{
						$set_vars .= '`' . $field->name . '` = null, ';
					}
					elseif( $field->numeric )
					{
						$set_vars .= '`' . $field->name . '` = ' . (real)$ds[$field->name] . ', ';
					}
					else
					{
						$set_vars .= '`' . $field->name . '` = "' . $this->getEscapeString($ds[$field->name]) . '", ';
					}
				}

				// rem last comma
				$set_vars = substr( $set_vars, 0, strlen( $set_vars ) - 2 );

				foreach( $primarykeys as $primarykey )
				{
					if( $where )
					{
						$where .= "
					AND ";
					}

					if( $primarykey['numeric'] )
					{
						$where .= "`{$primarykey['name']}` = " . (real) $primarykey['value'];
					}
					else
					{
						$where .= "`{$primarykey['name']}` = \"{$primarykey['value']}\"";
					}
				}

				$sql = "
					UPDATE `{$ds->getProperty('table')}`
					SET {$set_vars}
					WHERE {$where}";

				// update source
				$this->executeInternal( $sql );
			}
			else
			{
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * attempt to delete a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		final public function deleteDataRecord( DataSet &$ds )
		{
			if( $this->link )
			{
				/**
				 * connection to mysql database
				 * attempt to delete record in table using DataSet
				 */
				$where = '';
				$primarykeys = array();

				// get primary key
				foreach( $ds->fields as $field )
				{
					if( $field->primaryKey )
					{
						$primarykey = array();
						$primarykey['value'] = $ds->rows[$ds->cursor][$field->name];
						$primarykey['name']	= $field->name;
						$primarykey['numeric'] = (bool) $field->numeric;
						$primarykeys[] = $primarykey;
					}
				}

				foreach( $primarykeys as $primarykey )
				{
					if( $where )
					{
						$where .= "
					AND ";
					}

					if( $primarykey['numeric'] )
					{
						$where .= "`{$primarykey['name']}` = " . (real) $primarykey['value'];
					}
					else
					{
						$where .= "`{$primarykey['name']}` = \"{$primarykey['value']}\"";
					}
				}

				$sql = "
					DELETE FROM `{$ds->getProperty('table')}`
					WHERE $where";

				// delete record from source
				$this->executeInternal( $sql );
			}
			else
			{
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * Executes a sql query or procedure on the current connection
		 *
		 * @param  string		$query		sql query
		 * @return void
		 */
		public function execute( $query )
		{
			$this->executeInternal( $query );
		}


		/**
		 * begin transaction
		 *
		 * @return void
		 */
		public function begin()
		{
			$this->executeInternal( 'SET autocommit=0' );
			$this->executeInternal( 'START TRANSACTION' );
		}


		/**
		 * rollback transaction
		 *
		 * @return void
		 */
		public function rollback()
		{
			$this->executeInternal( 'ROLLBACK' );
		}


		/**
		 * commit transaction
		 *
		 * @return void
		 */
		public function commit()
		{
			$this->executeInternal( 'COMMIT' );
		}


		/**
		 * set foreign key checks
		 *
		 * @param  bool	 $set		set/unset foreign key checks
		 * @return void
		 */
		final public function setForeignKeyChecks( $set )
		{
			if((bool)$set)
			{
				$this->executeInternal( 'SET FOREIGN_KEY_CHECKS=1;' );
			}
			else
			{
				$this->executeInternal( 'SET FOREIGN_KEY_CHECKS=0;' );
			}
		}


		/**
		 * returns a DataSet of tables
		 *
		 * @return DataSet
		 */
		public function getTables()
		{
			return $this->openDataSet( "show tables from `{$this->args['database']}`" );
		}


		/**
		 * return id of last record inserted
		 *
		 * @return int
		 */
		public function getLastInsertId()
		{
			if( $this->link )
			{
				return mysql_insert_id( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysql resource is not a valid link identifier");
			}
		}


		/**
		 * return affected rows
		 *
		 * @return int
		 */
		public function getAffectedRows()
		{
			if( $this->link )
			{
				return mysql_affected_rows( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysql resource is not a valid link identifier");
			}
		}


		/**
		 * Executes a sql query or procedure on the current connection
		 *
		 * @param  string		$query		sql query
		 * @return resource					mysql resultset
		 */
		protected function executeInternal( $query )
		{
			$sql = '';
			if( $query instanceof QueryBuilder )
			{
				$sql = $this->getQuery( $query );
			}
			else
			{
				$sql = $query;
			}

			if( $this->link )
			{
				// start timer
				$timer = new \System\Utils\Timer(true);
				$this->lastQuery = $sql;
				$this->lastQueryTime = 0;

				$result = mysql_query( $sql, $this->link );

				if( !$result )
				{
					throw new SQLException(mysql_error( $this->link ));
				}

				$this->lastQueryTime = $timer->elapsed();
				$this->queryCount++;
				$this->queryTime += $this->lastQueryTime;

				return $result;
			}
			else
			{
				throw new \System\InvalidOperationException("mysql resource in not a valid link identifier");
			}
		}


		/**
		 * Returns SQL based on the QueryBuilder
		 *
		 * @param  QueryBuilder		$queryBuilder	QueryBuilder object
		 * @return string							SQL query
		 */
		final protected function getQuery( QueryBuilder $queryBuilder ) {

			// select
			if( $queryBuilder->getStatement() === 'select' ) {
				$sql = 'select';

				// columns
				$columns = '';
				foreach( $queryBuilder->getColumns() as $column ) {

					if( strlen( $columns ) > 0 ) {
						$columns .= '
	, ';
					}
					else {
						$columns = ' ';
					}

					if( $column['table'] === '*' ) {
						$columns .= '*';
					}
					else {
						$columns .= '`' . $column['table'] . '`';

						if( $column['column'] === '*' ) {
							$columns .= '.*';
						}
						else {
							$columns .= '.`' . $column['column'] . '`';
							$columns .= ' as `' . $column['alias'] . '`';
						}
					}
				}

				$sql .= isset( $columns )?$columns:'';

				// from
				$tables = '';
				foreach( $queryBuilder->getTables() as $table ) {
					if( strlen( $tables ) > 0 ) {
						$tables .= '
	, `' . $table['table'] . '`' . ' as `' . $table['alias'] . '`';
					}
					else {
						$tables = '
	from `' . $table['table'] . '`' . ' as `' . $table['alias'] . '`';
					}
				}

				$sql .= isset( $tables )?$tables:'';
			}

			// insert
			elseif( $queryBuilder->getStatement() === 'insert' ) {
				$sql = 'insert';

				$tables = $queryBuilder->getTables();

				$sql .= '
	into `' . $tables[0]['table'] . '` (';

				// columns
				$columns = '';
				foreach( $queryBuilder->getColumns() as $column ) {
					if( strlen( $columns ) > 0 ) {
						$columns .= ',`' . $column['column'] . '`';
					}
					else {
						$columns = '`' . $column['column'] . '`';
					}
				}

				$sql .= isset( $columns )?$columns:'';
				$sql .= ')';

				$sql .= '
	values(';

				// values
				$values = '';
				foreach( $queryBuilder->getValues() as $value ) {
					if( strlen( $values ) > 0 ) {
						$values .= ',';
					}
					else {
						$values = '';
					}
					if( is_null( $value )) {
						$values .= 'null';
					}
					elseif( is_bool( $value )) {
						$values .= $value?'true':'false';
					}
					elseif( is_int( $value )) {
						$values .= (int)$value;
					}
					elseif( is_float( $value )) {
						$values .= (real)$value;
					}
					else {
						$values .= '"' . $this->getEscapeString( $value ) . '"';
					}
				}

				$sql .= $values . ')';
			}

			// update
			elseif( $queryBuilder->getStatement() === 'update' ) {
				$sql = 'update';

				$tables = $queryBuilder->getTables();
				$sql .= ' `' . $tables[0]['table'] . '`';

				// set
				$columns = $queryBuilder->getColumns();
				$values = $queryBuilder->getValues();
				$setClause = '';
				for( $i = 0; $i < count( $columns ); $i++ ) {
					if( strlen( $setClause ) > 0 ) {
						$setClause .= '
	, ';
					}
					else {
						$setClause = '
set ';
					}

					if( is_null( $values[$i] )) {
						$setClause .= '`' . $columns[$i]['table'] . '`.`' . $columns[$i]['column'] . '` = null';
					}
					elseif( is_bool( $values[$i] )) {
						$setClause .= '`' . $columns[$i]['table'] . '`.`' . $columns[$i]['column'] . '` = ' . ($values[$i]?'true':'false');
					}
					elseif( is_int( $values[$i] )) {
						$setClause .= '`' . $columns[$i]['table'] . '`.`' . $columns[$i]['column'] . '` = ' . (int)$values[$i];
					}
					elseif( is_float( $values[$i] )) {
						$setClause .= '`' . $columns[$i]['table'] . '`.`' . $columns[$i]['column'] . '` = ' . (real)$values[$i];
					}
					else {
						$setClause .= '`' . $columns[$i]['table'] . '`.`' . $columns[$i]['column'] . '` = "' . $this->getEscapeString( $values[$i] ) . '"';
					}
				}

				$sql .= isset( $setClause )?$setClause:'';
			}

			// delete
			elseif( $queryBuilder->getStatement() === 'delete' ) {
				$sql = 'delete';

				// from
				$tables = '';
				foreach( $queryBuilder->getTables() as $table ) {
					if( strlen( $tables ) > 0 ) {
						$tables .= '
	, `' . $table['table'] . '`';
					}
					else {
						$tables = '
	from `' . $table['table'] . '`';
					}
				}

				$sql .= isset( $tables )?$tables:'';
			}

			// joins
			foreach( $queryBuilder->getJoins() as $join ) {
				$sql .= '
' . $join['type'] . '
	join `' . $join['lefttable'] . '` as `' . $join['alias'] . '`
		on `' . $join['alias'] . '`.`' . $join['leftcolumn'] . '` = `' . $join['righttable'] . '`.`' . $join['rightcolumn'] . '`';


			}

			// where
			$whereClause = '';
			foreach( $queryBuilder->getWhereClauses() as $where ) {
				if( strlen( $whereClause ) > 0 ) {
					$whereClause .= '
and';
				}
				else {
					$whereClause = '
where';
				}
				if( is_null( $where['value'] )) {
					$whereClause .= '
	`' . $where['table'] . '`.`' . $where['column'] . '` is null';
				}
				elseif( is_bool( $where['value'] )) {
					$whereClause .= '
	`' . $where['table'] . '`.`' . $where['column'] . '` = ' . ($where['value']?'true':'false');
				}
				elseif( is_int( $where['value'] )) {
					$whereClause .= '
	`' . $where['table'] . '`.`' . $where['column'] . '` ' . $where['operand'] . ' ' . (int)$where['value'] . '';
				}
				elseif( is_float( $where['value'] )) {
					$whereClause .= '
	`' . $where['table'] . '`.`' . $where['column'] . '` ' . $where['operand'] . ' ' . (real)$where['value'] . '';
				}
				else {
					$whereClause .= '
	`' . $where['table'] . '`.`' . $where['column'] . '` ' . $where['operand'] . ' "' . $this->getEscapeString( $where['value'] ) . '"';
				}
			}

			if( $queryBuilder->empty ) {
				if( strlen( $whereClause ) === 0 ) {
					$whereClause = '
where
	0';
				}
			}

			$sql .= isset( $whereClause )?$whereClause:'';

			// orderby
			$orderByClause = '';
			foreach( $queryBuilder->getOrderByClauses() as $orderby ) {
				if( strlen( $orderByClause ) > 0 ) {
					$orderByClause .= '
	, `' . $orderby['table'] . '`.`' . $orderby['column'] . '` ' . $orderby['direction'];
				}
				else {
					$orderByClause = '
order
	by `' . $orderby['table'] . '`.`' . $orderby['column'] . '` ' . $orderby['direction'];
				}
			}

			$sql .= isset( $orderByClause )?$orderByClause:'';

			// groupby
			$groupByClause = '';
			foreach( $queryBuilder->getGroupByClauses() as $groupby ) {
				if( strlen( $groupByClause ) > 0 ) {
					$groupByClause .= '
	, `' . $groupby['table'] . '`.`' . $groupby['column'] . '`';
				}
				else {
					$groupByClause = '
group
	by `' . $groupby['table'] . '`.`' . $groupby['column'] . '`';
				}
			}

			$sql .= isset( $groupByClause )?$groupByClause:'';

			// having
			$havingClause = '';
			foreach( $queryBuilder->getHavingClauses() as $having ) {
				if( strlen( $havingClause ) > 0 ) {
					$havingClause .= '
and';
				}
				else {
					$havingClause = '
having';
				}
				$havingClause .= '
	`' . $having['column'] . '` ' . $having['operand'] . ' "' . $this->getEscapeString( $having['value'] ) . '"';
			}

			$sql .= isset( $havingClause )?$havingClause:'';

			return $sql;
		}


		/**
		 * Returns escaped string
		 *
		 * @param  string		$unescaped_string   String to escape
		 * @return string							SQL query
		 */
		protected function getEscapeString( $unescaped_string ) {
			return mysql_real_escape_string( $unescaped_string, $this->link );
		}
	}
?>