<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents a Record in a DataSet
	 *
	 * @property array $columns Row data as an array
	 * @property array $rows Column data as an array
	 * @property DataSet $dataSet Reference to the DataSet
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class DataRecord implements \ArrayAccess
	{
		/**
		 * row data
		 * @var array
		 */
		protected $row				= array();

		/**
		 * DataSet
		 * @var DataSet
		 */
		protected $dataSet;


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 *
		 * @return mixed
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'columns' )
			{
				return array_keys($this->row);
			}
			elseif( $field === 'row' )
			{
				return $this->row;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @param  string	$field		name of the field
		 * @param  mixed	$value		value of field
		 *
		 * @return bool					true on success
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
		}


		/**
		 * Constructor
		 *
		 * @return void
		 */
		protected function DataRecord()
		{
		}


		/**
		 * create new DataRecord
		 *
		 * @param  DataSet			$ds				reference to the DataSet
		 * @param  array			$row			array of column data
		 * @return DataRecord
		 */
		static public function addNew( DataSet &$ds, array $row )
		{
			$record = new DataRecord();
			$record->dataSet =& $ds;
			$record->row =& $row;

			return $record;
		}


		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		function offsetExists($index)
		{
			if( array_key_exists( $index, $this->row ))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		function offsetGet($index)
		{
			if( array_key_exists( $index, $this->row ))
			{
				return $this->row[$index];
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		function offsetSet($index, $value)
		{
			if( array_key_exists( $index, $this->row ))
			{
				$this->row[$index] = $value;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		function offsetUnset($index)
		{
			if( array_key_exists( $index, $this->row ))
			{
				unset( $this->row[$index] );
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * Returns a DataRecord as a CSV string
		 *
		 * @param  char		$delimiter		column dilemeter
		 * @param  char		$enclosure		string enclosure
		 * @param  string	$nullexpr		null expression
		 * 
		 * @return string					CSV string
		 */
		public function getCSVString( $enclosure="\"", $delimiter="\t", $nullexpr = 'NULL' )
		{
			$CSVString = '';

			for( $col=0, $count=$this->dataSet->fields->count; $col < $count; $col++ )
			{
				$field = $this->dataSet->fields[$col];

				if( !empty( $CSVString ))
				{
					$CSVString .= $delimiter;
				}

				if( $this[$field->name] === null )
				{
					$CSVString .= $nullexpr;
				}
				else
				{
					$CSVString .= $enclosure . str_replace( '"', '""', $this[$field->name] ) . $enclosure;
				}
			}

			return $CSVString;
		}
	}
?>