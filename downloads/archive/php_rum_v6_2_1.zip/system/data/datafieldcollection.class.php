<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of DataField objects
	 * 
	 * @author			Darnell Shinbine
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class DataFieldCollection extends CollectionBase
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof DataField )
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of class DataField in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add DataField to Collection
		 *
		 * @param  DataField $item
		 * @return bool
		 */
		public function add( $item )
		{
			if( $item instanceof DataField )
			{
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of class DataField");
			}
		}


		/**
		 * return DataField at a specified index
		 *
		 * @param  int		$index			index of ActiveRecord
		 *
		 * @return DataField				DataField
		 */
		public function itemAt( $index )
		{
			return parent::itemAt($index);
		}


		/**
		 * returns true if array item is found
		 *
		 * @param  string		$field_name		name of field
		 * @return bool
		 */
		public function contains( $field_name )
		{
			for( $i = 0, $count = count( $this->items ); $i < $count; $i++ )
			{
				if( $this->items[$i]->name === $field_name )
				{
					return true;
				}
			}
			return false;
		}


		/**
		 * returns index if value is found in collection
		 *
		 * @param  string		$field_name		name of field
		 * @return int
		 */
		public function indexOf( $field_name )
		{
			for( $i = 0, $count = count( $this->items ); $i < $count; $i++ )
			{
				if( $this->items[$i]->name === $field_name )
				{
					return $i;
				}
			}
			return -1;
		}
	}
?>