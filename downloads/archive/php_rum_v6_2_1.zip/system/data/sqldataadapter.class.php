<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Provides access to an SQL based data source
	 *
	 * @property int $affectedRows affected rows
	 * @property int $lastInsertId last insert id
	 * @property string $lastError last error
	 * @property int $lastQueryTime last query time
	 * @property string $lastQuery last query
	 * @property int $queryCount query count
	 * @property int $queryTime total query time
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class SQLDataAdapter extends DataAdapter
	{
		/**
		 * last query executed
		 * @var string
		 */
		protected $lastQuery			= '';

		/**
		 * last query execution time in ms
		 * @var int
		 */
		protected $lastQueryTime		= 0;

		/**
		 * total query time in seconds
		 * @var int
		 */
		protected $queryTime			= 0;

		/**
		 * query count
		 * @var int
		 */
		protected $queryCount			= 0;


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'affectedRows' ) {
				return $this->getAffectedRows();
			}
			elseif( $field === 'lastInsertId' ) {
				return $this->getLastInsertId();
			}
			elseif( $field === 'lastError' ) {
				return $this->getLastError();
			}
			elseif( $field === 'lastQueryTime' ) {
				return $this->getLastQueryTime();
			}
			elseif( $field === 'lastQuery' ) {
				return $this->getLastQuery();
			}
			elseif( $field === 'queryCount' ) {
				return $this->getQueryCount();
			}
			elseif( $field === 'queryTime' ) {
				return $this->getQueryTime();
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * Executes a sql query or procedure on the current connection
		 *
		 * @param  string		$query		sql query or QueryBuilder object
		 * 
		 * @return void
		 */
		abstract public function execute( $query );


		/**
		 * begin transaction
		 *
		 * @return void
		 */
		abstract public function begin();


		/**
		 * rollback transaction
		 *
		 * @return void
		 */
		abstract public function rollback();


		/**
		 * commit transaction
		 *
		 * @return void
		 */
		abstract public function commit();


		/**
		 * set foreign key checks
		 *
		 * @param  bool	 $set		set/unset foreign key checks
		 *
		 * @return void
		 */
		abstract public function setForeignKeyChecks( $set );


		/**
		 * returns a DataSet containing tables
		 *
		 * @return DataSet
		 */
		abstract public function getTables();


		/**
		 * return id of last record inserted
		 *
		 * @return int
		 */
		abstract public function getLastInsertId();


		/**
		 * return affected rows
		 *
		 * @return int
		 */
		abstract public function getAffectedRows();


		/**
		 * return last executed query
		 *
		 * @return string
		 */
		final public function getLastQuery() {
			return $this->lastQuery;
		}


		/**
		 * return last executed query time in milliseconds
		 *
		 * @return real
		 */
		final public function getLastQueryTime() {
			return $this->lastQueryTime;
		}


		/**
		 * return query count
		 *
		 * @return int
		 */
		final public function getQueryCount() {
			return $this->queryCount;
		}


		/**
		 * return query time
		 *
		 * @return int
		 */
		final public function getQueryTime() {
			return $this->queryTime;
		}


		/**
		 * Returns query based on the QueryBuilder
		 *
		 * @param  QueryBuilder		$queryBuilder	QueryBuilder object
		 * @return string							SQL query
		 */
		abstract protected function getQuery( QueryBuilder $queryBuilder );
	}
?>