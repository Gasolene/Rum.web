<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\ActiveRecords;


	/**
	 * Represents a table withing a database or an instance of a single record in the table.
	 *
	 * @property   bool $isNull Specifies whether ActiveRecord is null
	 * @property   bool $isEmpty Specifies whether ActiveRecord is empty
	 * @property   DataSet $dataSet Reference to the DataSet
	 * @property   DataAdapter $dataAdapter Reference to the DataAdapter
	 * @property   string $table Table name
	 * @property   string $prefix Table prefix
	 * @property   string $pkey Primary key
	 * @property   RelationshipCollection $relationships Collection of Relationship objects
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class ActiveRecordBase implements \ArrayAccess
	{
		/**
		 * table name
		 * @var string
		**/
		protected $table			= '';

		/**
		 * table prefix
		 * @var string
		**/
		protected $prefix			= '';

		/**
		 * primary key
		 * @var string
		**/
		protected $pkey				= '';

		/**
		 * ActiveRecord relationships
		 * @var RelationshipCollection
		**/
		protected $relationships;

		/**
		 * Specifies whether to auto map ActiveRecord to other ActiveRecords
		 * @var bool
		**/
		protected $autoMapping		= true;

		/**
		 * DataSet
		 * @var DataSet
		**/
		private $_ds				= null;


		/**
		 * Constructor
		 *
		 * @return void
		 */
		final protected function ActiveRecordBase()
		{
			$this->relationships = new RelationshipCollection();
			$this->_setProperties();

			$this->onCreate();
		}


		/**
		 * invokes a dynamic method
		 *
		 * @param  string   $function   name of the method
		 * @param  array	$args	   array of arguments
		 * @return mixed
		 * @ignore
		 */
		public function __call( $function, array $args = array() )
		{
			$pos = 0;
			foreach( $this->relationships as $mapping )
			{
				if( strrchr( $mapping['Type'], '\\') !== false )
				{
					$index = stripos( $function, substr( strrchr( $mapping['Type'], '\\'), 1 ));
				}
				else
				{
					$index = stripos( $function, $mapping['Type'] );
				}

				if( $index !== false )
				{
					if( isset( $type ))
					{
						if( strlen( $mapping['Type'] ) > strlen( $type ))
						{
							$type = $mapping['Type'];
							$pos  = $index;
						}
					}
					else
					{
						$type = $mapping['Type'];
						$pos  = $index;
					}
				}
			}

			if( isset( $type ))
			{
				$subject = '';
				if( strrchr( $type, '\\') !== false )
				{
					$subject = substr( strrchr( $type, '\\'), 1 );
				}
				else
				{
					$subject = $type;
				}

				$prefix = (string)substr( $function, 0, $pos );
				$suffix = (string)substr( $function, $pos + strlen( $subject ), strlen( $function ) - $pos + strlen( $subject ));

				/**
				 * [prefix]	add, remove, removeAll, delete, deleteAll, find, findAll, getParent, getAll, get
				 * [type]
				 * [suffix]	ById, RecordById, Record, Records, DataSet
				 * [args]	ActiveRecordBase
				 */

				// add[Type]Record( [Type] $args[0] ) = addRecord( [Type] $args[0] )
				if( $prefix === 'add' && ( $suffix === 'Record' || $suffix === '' ))
				{
					if( count($args) === 1 )
					{
						if( $args[0] instanceof $type )
						{
							return $this->addRecord( $args[0] );
						}
						else
						{
							throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
						}
					}
					else
					{
						throw new \System\MissingArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
					}
				}

				// remove[Type]Record( [Type] $args[0] ) = removeRecord( [Type] $args[0] )
				elseif( $prefix === 'remove' && ( $suffix === 'Record' || $suffix === '' ))
				{
					if( count($args) === 1 )
					{
						if( $args[0] instanceof $type )
						{
							return $this->removeRecord( $args[0] );
						}
						else
						{
							throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
						}
					}
					else
					{
						throw new \System\MissingArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
					}
				}

				// removeAll[Type]Records() = removeAllRecordsByType( string $type )
				elseif( $prefix === 'removeAll' && ( $suffix === 'Records' || $suffix === 's' || $suffix === '' ))
				{
					if( count($args) === 0 )
					{
						return $this->removeAllRecordsByType( $type );
					}
					else
					{
						throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects no parameters");
					}
				}

				// delete[Type]Record( [Type] $args[0] ) = addRecord( [Type] $args[0] )
				if( $prefix === 'delete' && ( $suffix === 'Record' || $suffix === '' ))
				{
					if( count($args) === 1 )
					{
						if( $args[0] instanceof $type )
						{
							return $this->deleteRecord( $args[0] );
						}
						else
						{
							throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
						}
					}
					else
					{
						throw new \System\MissingArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter of type $type");
					}
				}

				// deleteAll[Type]Records() = deleteAllRecordsByType( string $type )
				elseif( $prefix === 'deleteAll' && ( $suffix === 'Records' || $suffix === 's' || $suffix === '' ))
				{
					if( count($args) === 0 )
					{
						return $this->deleteAllRecordsByType( $type );
					}
					else
					{
						throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects no parameters");
					}
				}

				// get[Type]Record( int $args[0] ) = findRecordByType( string $type, int $args[0] )
				elseif( $prefix === 'get' && ( $suffix === 'Record' || $suffix === '' ))
				{
					if( count($args) === 1 )
					{
						return $this->findRecordByType( $type, $args[0] );
					}
					else
					{
						throw new \System\MissingArgumentException("Overloaded method ".get_class($this)."::$function expects one parameter");
					}
				}

				// getParent[Type]Record() = findParentRecordByType( string $type )
				elseif( $prefix === 'getParent' && ( $suffix === 'Record' || $suffix === '' ))
				{
					if( count($args) === 0 )
					{
						return $this->findParentRecordByType( $type );
					}
					else
					{
						throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects no parameters");
					}
				}

				// getAll[Type]Records() = findAllRecordsByType( string $type )
				elseif( $prefix === 'getAll' && ( $suffix === 'Records' || $suffix === 's' || $suffix === '' ))
				{
					if( count($args) === 0 )
					{
						return $this->findAllRecordsByType( $type );
					}
					else
					{
						throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects no parameters");
					}
				}

				// get[Type]DataSet() = getDataSetByType( string $type )
				elseif( $prefix === 'get' && $suffix === 'DataSet' )
				{
					if( count($args) === 0 )
					{
						return $this->getDataSetByType( $type );
					}
					else
					{
						throw new \System\InvalidArgumentException("Overloaded method ".get_class($this)."::$function expects no parameters");
					}
				}
				else
				{
					throw new \System\BadMethodCallException("call to undefined method $function in ".get_class( $this ));
				}
			}
			else
			{
				throw new \System\BadMethodCallException("call to undefined method $function in ".get_class( $this ));
			}
		}


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'isNull' )
			{
				return (bool) $this->_ds === null;
			}
			elseif( $field === 'isEmpty' )
			{
				if( !$this->isNull )
				{
					return (bool) ( $this->_ds->count === 0 );
				}
				else
				{
					return true;
				}
			}
			elseif( $field === 'dataSet' )
			{
				return $this->_ds;
			}
			elseif( $field === 'dataAdapter' )
			{
				return $this->_ds->dataAdapter;
			}
			elseif( $field === 'table' )
			{
				return $this->table;
			}
			elseif( $field === 'prefix' )
			{
				return $this->prefix;
			}
			elseif( $field === 'pkey' )
			{
				return $this->pkey;
			}
			elseif( $field === 'relationships' )
			{
				return clone $this->relationships;
			}
			elseif( array_key_exists( $field, $this->_ds->row ))
			{
				return $this[$field];
			}
			elseif( array_key_exists( $this->prefix.$field, $this->_ds->row ))
			{
				return $this[$this->prefix.$field];
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @param  string	$field		name of the field
		 * @param  mixed	$value		value of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( array_key_exists( (string)$field, $this->_ds->row ))
			{
				$this[(string)$field] = $value;
			}
			elseif( array_key_exists( $this->prefix.(string)$field, $this->_ds->row ))
			{
				$this[$this->prefix.(string)$field] = $value;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetExists($index)
		{
			if( array_key_exists( $index, $this->_ds->row ))
			{
				return true;
			}
			elseif( array_key_exists( $this->prefix.$index, $this->_ds->row ))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetGet($index)
		{
			if( array_key_exists( $index, $this->_ds->row ))
			{
				return $this->_ds->row[$index];
			}
			elseif( array_key_exists( $this->prefix.$index, $this->_ds->row ))
			{
				return $this->_ds->row[$this->prefix.$index];
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetSet($index, $value)
		{
			if( array_key_exists( $index, $this->_ds->row ))
			{
				$this->_ds[$index] = $value;
			}
			elseif( array_key_exists( $this->prefix.$index, $this->_ds->row ))
			{
				$this->_ds[$this->prefix.$index] = $value;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetUnset($index)
		{
			if( array_key_exists( $index, $this->_ds->row ))
			{
				unset( $this->_ds->row[$index] );
			}
			elseif( array_key_exists( $this->prefix.$index, $this->_ds->row ))
			{
				unset( $this->_ds->row[$this->prefix.$index] );
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * update DataAdapter
		 *
		 * @return void
		 */
		public function save()
		{
			$this->beforeSave();

			if( !$this->isEmpty )
			{
				$this->beforeUpdate();
				$this->_ds->update();
				$this->afterUpdate();
			}
			else
			{
				$this->beforeInsert();
				$this->_ds->insert();
				$this->afterInsert();
			}

			$this->afterSave();
		}


		/**
		 * delete ActiveRecordBase
		 *
		 * @return void
		 */
		public function delete()
		{
			if( !$this->isEmpty )
			{
				$this->beforeDelete();
				$this->_ds->delete();
				$this->_ds = null;
				$this->afterDelete();
			}
			else
			{
				throw new \System\InvalidOperationException("cannot delete empty record");
			}
		}


		/**
		 * delete ActiveRecordBase and all associated ActiveRecordBases (cascading delete)
		 *
		 * @return void
		 */
		public function deleteAll()
		{
			if( !$this->isEmpty )
			{
				foreach( $this->relationships as $mapping )
				{
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						$records = $this->findAllRecordsByType( $mapping['Type'] );

						foreach( $records as $record )
						{
							$record->deleteAll();
						}

						continue;
					}

					elseif( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
					{
						$this->_ds->dataAdapter->execute( '
							delete from
								`' . $mapping['Table'] . '`
							where
								`' . $mapping['ColumnKey'] . '` = ' . $this[$mapping['ColumnKey']] );

						continue;
					}
				}

				$this->delete();
			}
			else
			{
				throw new \System\InvalidOperationException ("cannot delete empty record");
			}
		}


		/**
		 * protected static factory methods
		 */


		/**
		 * static method to create new ActiveRecordBase of this type
		 *
		 * @param  array		$params		optional associative array of initial properties
		 * @return ActiveRecordBase
		 */
		static protected function add( array $args = array() )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::addByType( $backtrace[1]['class'], $args );
		}


		/**
		 * static method to find ActiveRecordBase of this type
		 *
		 * @param  array		$args		associative array of keys and values to find
		 * @return ActiveRecordBase
		 */
		static protected function find( array $args )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::findByType( $backtrace[1]['class'], $args );
		}


		/**
		 * static method to find ActiveRecordBase by primary key
		 *
		 * @param  mixed		$pid		key value to lookup
		 * @return ActiveRecordBase
		 */
		static protected function findById( $pid )
		{
			$backtrace = debug_backtrace();
			$activeRecord = new $backtrace[1]['class']();

			return ActiveRecordBase::findByType( $backtrace[1]['class'], array( $activeRecord->pkey => $pid ));
		}


		/**
		 * static method to find ActiveRecordBases of this type
		 *
		 * @param  array		$args		associative array of keys and values to find
		 * @return ActiveRecordCollection
		 */
		static protected function findAll( array $args = array() )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::findAllByType( $backtrace[1]['class'], $args );
		}


		/**
		 * static method to find the first ActiveRecordBase of this type
		 *
		 * @param  string		$args		associative array of keys and values to find
		 * @return ActiveRecordBase
		 */
		static protected function first( array $args = array())
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::firstByType( $backtrace[1]['class'], $args );
		}


		/**
		 * static method to find the last ActiveRecordBase of this type
		 *
		 * @param  string		$args		associative array of keys and values to find
		 * @return ActiveRecordBase
		 */
		static protected function last( array $args = array() )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::lastByType( $backtrace[1]['class'] );
		}


		/**
		 * static method to return a DataSet of this type
		 *
		 * @param  array		$params		associative array of keys and values to find
		 * @return DataSet
		 */
		static protected function dataSet( array $params = array() )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::dataSetByType( $backtrace[1]['class'], $params );
		}


		/**
		 * static method to return an extended DataSet of this type
		 *
		 * @param  array		$params		associative array of keys and values to find
		 * @return DataSet
		 */
		static protected function dataSetExtended( array $params = array() )
		{
			$backtrace = debug_backtrace();
			return ActiveRecordBase::dataSetExtendedByType( $backtrace[1]['class'], $params );
		}


		/**
		 * protected events
		 */


		/**
		 * event called when object is created
		 *
		 * @return void
		 */
		protected function onCreate() {}


		/**
		 * event called before a new ActiveRecordBase is created
		 *
		 * @return void
		 */
		protected function beforeAdd() {}


		/**
		 * event called after a new ActiveRecordBase is created
		 *
		 * @return void
		 */
		protected function afterAdd() {}


		/**
		 * event called before every retrieve
		 *
		 * @return void
		 */
		protected function beforeRetrieve() {}


		/**
		 * event called after every retrieve
		 *
		 * @return void
		 */
		protected function afterRetrieve() {}


		/**
		 * event called before every save
		 *
		 * @return void
		 */
		protected function beforeSave() {}


		/**
		 * event called after every save
		 *
		 * @return void
		 */
		protected function afterSave() {}


		/**
		 * event called before every insert
		 *
		 * @return void
		 */
		protected function beforeInsert() {}


		/**
		 * event called after every insert
		 *
		 * @return void
		 */
		protected function afterInsert() {}


		/**
		 * event called before every update
		 *
		 * @return void
		 */
		protected function beforeUpdate() {}


		/**
		 * event called after every update
		 *
		 * @return void
		 */
		protected function afterUpdate() {}


		/**
		 * event called before every delete
		 *
		 * @return void
		 */
		protected function beforeDelete() {}


		/**
		 * event called after every delete
		 *
		 * @return void
		 */
		protected function afterDelete() {}


		/**
		 * private methods (used by __call)
		 */


		/**
		 * add association to another ActiveRecordBase object
		 *
		 * @param  ActiveRecordBase		&$activeRecord		reference to ActiveRecordBase object
		 * @return void
		 */
		final private function addRecord( ActiveRecordBase &$activeRecord )
		{
			if( !$this->isEmpty )
			{
				foreach( $this->relationships as $mapping )
				{
					if( strtolower( $mapping['Type'] ) === strtolower( get_class( $activeRecord )))
					{
						if( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
						{
							if( !$activeRecord->isEmpty )
							{
								$query = new \System\Data\QueryBuilder();
								$query->select();
								$query->from( $mapping['Table'] );
								$query->where( $mapping['Table'], $mapping['ColumnKey'], '=', $this[$this->pkey] );
								$query->where( $mapping['Table'], $mapping['ColumnRef'], '=', $activeRecord[$activeRecord->pkey] );

								$ds = $this->_ds->dataAdapter->openDataSet( $query );

								if( $ds->count ) {
									throw new \System\InvalidOperationException("association already exists");
								}

								$ds = $this->_ds->dataAdapter->openDataSet( $mapping['Table'] );
								$ds[$mapping['ColumnKey']] = $this[$mapping['ColumnKey']];
								if( !( $this instanceof $mapping['Type'] ))
								{
									$ds[$mapping['ColumnRef']] = $activeRecord[$mapping['ColumnRef']];
								}
								else
								{
									$ds[$mapping['ColumnRef']] = $activeRecord[$mapping['ColumnKey']];
								}

								$ds->insert();
								return;
							}
							else
							{
								throw new \System\InvalidOperationException(get_class($activeRecord)." must be saved before adding association");
							}
						}
						if( $mapping['Relationship'] == RelationshipType::HasMany() )
						{
							if( $activeRecord[$mapping['ColumnRef']] )
							{
								if( $activeRecord[$mapping['ColumnRef']] === $this[$mapping['ColumnKey']] )
								{
									throw new \System\InvalidOperationException(get_class($activeRecord)." is already a child of ".get_class($this));
								}
								else
								{
									throw new \System\InvalidOperationException(get_class($activeRecord)." already has a parent");
								}
							}

							// set the foreign key of the foreign object...
							$activeRecord[$mapping['ColumnRef']] = $this[$mapping['ColumnKey']];
							$activeRecord->save();
							return;
						}
					}
				}
				throw new \System\InvalidOperationException(get_class($activeRecord)." has no relationship to ".get_class($this));
			}
			else
			{
				throw new \System\InvalidOperationException(get_class($this)." must be saved before adding another record");
			}
		}


		/**
		 * remove association with another ActiveRecordBase ActiveRecordBase
		 *
		 * @param  ActiveRecordBase		&$activeRecord		reference to ActiveRecordBase object
		 * @return void
		 */
		final private function removeRecord( ActiveRecordBase &$activeRecord )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( get_class( $activeRecord )))
				{
					if( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
					{
						$query = new \System\Data\QueryBuilder();
						$query->select();
						$query->from( $mapping['Table'] );
						$query->where( $mapping['Table'], $mapping['ColumnKey'], '=', $this[$this->pkey] );
						$query->where( $mapping['Table'], $mapping['ColumnRef'], '=', $activeRecord[$activeRecord->pkey] );

						$ds = $this->_ds->dataAdapter->openDataSet( $query );

						if( $ds->count > 0 )
						{
							$ds->delete();
							return;
						}
						else
						{
							throw new \System\InvalidOperationException(get_class($activeRecord)." is not associated with ".get_class($this));
						}
					}
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						if( $activeRecord[$mapping['ColumnRef']] != $this[$mapping['ColumnKey']] ) {
							if( !$activeRecord[$mapping['ColumnRef']] ) {
								throw new \System\InvalidOperationException(get_class($activeRecord)." has no parent ".get_class($this));
							}
							else {
								throw new InvalidOperationException(get_class($activeRecord)." is not the child of".get_class($this));
							}
						}

						$activeRecord[$mapping['ColumnRef']] = null;
						$activeRecord->save();
						return;
					}
				}
			}
			throw new InvalidOperationException(get_class($this)." has no relationship to ".get_class($activeRecord));
		}


		/**
		 * remove all associations to another ActiveRecordBase object by type
		 *
		 * @param  string		$type		object type
		 * @return void
		 */
		final private function removeAllRecordsByType( $type )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
					{
						$query = new \System\Data\QueryBuilder();
						$query->delete();
						$query->from  ( $mapping['Table'] );
						$query->where ( $mapping['Table'], $mapping['ColumnKey'], '=', $this[$this->pkey] );

						$this->_ds->dataAdapter->execute( $query );
						return;
					}
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						$query = new \System\Data\QueryBuilder();
						$query->update( $mapping['Table'] );
						$query->set   ( $mapping['Table'], $mapping['ColumnRef'], null );
						$query->where ( $mapping['Table'], $mapping['ColumnRef'], '=', $this[$mapping['ColumnKey']] );

						$this->_ds->dataAdapter->execute( $query );
						return;
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * delete a child ActiveRecordBase object
		 *
		 * @param  ActiveRecordBase		&$activeRecord		reference to ActiveRecordBase object
		 * @return void
		 */
		final private function deleteRecord( ActiveRecordBase &$activeRecord )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( get_class( $activeRecord )))
				{
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						if( $activeRecord[$mapping['ColumnRef']] != $this[$mapping['ColumnKey']] )
						{
							if( !$activeRecord[$mapping['ColumnRef']] )
							{
								throw new \System\InvalidOperationException(get_class($activeRecord)." has no parent ".get_class($this));
							}
							else
							{
								throw new \System\InvalidOperationException(get_class($activeRecord)." is not the child of ".get_class($this));
							}
						}
						$activeRecord->delete();
						return;
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".get_class($activeRecord));
		}


		/**
		 * delete all child ActiveRecordBase objects by type
		 *
		 * @param  string		$type		object type
		 * @return void
		 */
		final private function deleteAllRecordsByType( $type )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						$query = new \System\Data\QueryBuilder();
						$query->delete();
						$query->from  ( $mapping['Table'] );
						$query->where ( $mapping['Table'], $mapping['ColumnRef'], '=', $this[$mapping['ColumnKey']] );

						$this->_ds->dataAdapter->execute( $query );
						return;
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * return a child ActiveRecordBase object by type
		 *
		 * @param  string		$type		object type
		 * @param  int			$id			value of pkey
		 * @return DataSet					reference to object
		 */
		final private function findRecordByType( $type, $id )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						if( class_exists( $mapping['Type'] ))
						{
							$activeRecord = ActiveRecordBase::addByType( $type );

							$joinTable = ($this->table==$mapping['Table'])?$mapping['Table'].'2':$mapping['Table'];

							$query = new \System\Data\QueryBuilder();
							$query->select( $joinTable, $activeRecord->pkey );
							$query->from( $this->table );
							$query->innerJoin( $mapping['Table'], $mapping['ColumnRef'], $this->table, $mapping['ColumnKey'], $joinTable );
							$query->where( $joinTable, $mapping['ColumnRef'], '=', $this[$mapping['ColumnKey']] );
							$query->where( $joinTable, $activeRecord->pkey, '=', $id );
							$ds = $this->_ds->dataAdapter->openDataSet( $query );

							return ActiveRecordBase::findByType( $mapping['Type'], array( $activeRecord->pkey => $ds[$activeRecord->pkey] ));
						}
						else {
							throw new \System\InvalidOperationException("object `$type` is not defined");
						}
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * return a parent ActiveRecordBase object by type
		 *
		 * @param  string		$type		object type
		 * @return ActiveRecordBase
		 */
		final private function findParentRecordByType( $type )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::BelongsTo() )
					{
						if( class_exists( $mapping['Type'] ))
						{
							return ActiveRecordBase::findByType( $mapping['Type'], array( $mapping['ColumnKey'] => $this[$mapping['ColumnRef']] ));
						}
						else
						{
							throw new \System\InvalidOperationException("object `$type` is not defined");
						}
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * return a collection of child ActiveRecordBase objects by type
		 *
		 * @param  string		$type		object type
		 * @return ActiveRecordCollection
		 */
		final private function findAllRecordsByType( $type )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
					{
						if( class_exists( $mapping['Type'] ))
						{
							$obj = ActiveRecordBase::addByType( $type );

							$query = new \System\Data\QueryBuilder();
							$query->select( $mapping['Table'], $mapping['ColumnRef'] );
							$query->from( $this->table );
							$query->innerJoin( $mapping['Table'], $mapping['ColumnKey'], $this->table, $mapping['ColumnKey'] );
							//$query->innerJoin( $obj->table, $mapping['ColumnKey'], $mapping['Table'], $mapping['ColumnKey'] );
							$query->where( $this->table, $mapping['ColumnKey'], '=', $this[$mapping['ColumnKey']] );
							$ds = $this->_ds->dataAdapter->openDataSet( $query );

							$records = new ActiveRecordCollection();
							foreach( $ds->rows as $row )
							{
								$record = ActiveRecordBase::findByType( $type, array( $obj->pkey => $row[$obj->pkey] ));

								if( !is_null( $record ))
								{
									$records->add( $record );
								}
								else
								{
									throw new \System\InvalidOperationException("key {$obj->pkey}.{$row[$obj->pkey]} exists in table {$mapping['Table']} with no record in table {$obj->table}");
								}
							}
							return $records;
						}
						else
						{
							throw new \System\InvalidOperationException("object `$type` is not defined");
						}
					}
					if( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						if( class_exists( $mapping['Type'] ))
						{
							$obj = ActiveRecordBase::addByType( $type );

							$joinTable = ($this->table==$mapping['Table'])?$mapping['Table'].'2':$mapping['Table'];

							$query = new \System\Data\QueryBuilder();
							$query->select( $joinTable, $obj->pkey );
							$query->from( $this->table );
							$query->innerJoin( $mapping['Table'], $mapping['ColumnRef'], $this->table, $mapping['ColumnKey'], $joinTable );
							$query->where( $joinTable, $mapping['ColumnRef'], '=', $this[$mapping['ColumnKey']] );
							$ds = $this->_ds->dataAdapter->openDataSet( $query );

							$records = new ActiveRecordCollection();
							foreach( $ds->rows as $row )
							{
								$record = ActiveRecordBase::findByType( $type, array( $obj->pkey => $row[$obj->pkey] ));

								if( !is_null( $record ))
								{
									$records->add( $record );
								}
								else
								{
									throw new \System\InvalidOperationException("key {$obj->pkey}.{$row[$obj->pkey]} exists in table {$mapping['Table']} with no record in table {$obj->table}");
								}
							}
							return $records;
						}
						else
						{
							throw new \System\InvalidOperationException("object `$type` is not defined");
						}
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * return DataSet object with all child records by type
		 *
		 * @param  string		$type		object type
		 * @return DataSet					reference to object
		 */
		final private function getDataSetByType( $type )
		{
			foreach( $this->relationships as $mapping )
			{
				if( strtolower( $mapping['Type'] ) === strtolower( $type ))
				{
					if( $mapping['Relationship'] == RelationshipType::HasManyAndBelongsTo() )
					{
						if( class_exists( $mapping['Type'] ))
						{
							$activeRecord = ActiveRecordBase::addByType( $type );

							$query = new \System\Data\QueryBuilder();
							// $query->select( $activeRecord->table );
							$query->select( '*' );
							$query->from( $mapping['Table'] );
							$query->innerJoin( $activeRecord->table, $activeRecord->pkey, $mapping['Table'], $mapping['ColumnRef'] );
							if( !( $this instanceof $mapping['Type'] ))
							{
								$query->innerJoin( $this->table, $mapping['ColumnKey'], $mapping['Table'], $mapping['ColumnKey'] );
							}
							$query->where( $mapping['Table'], $mapping['ColumnKey'], '=', $this[$mapping['ColumnKey']] );

							return $ds = $this->_ds->dataAdapter->openDataSet( $query );
						}
						else
						{
							throw new \System\InvalidOperationException("object `$type` is not defined");
						}
					}
					elseif( $mapping['Relationship'] == RelationshipType::HasMany() )
					{
						$joinTable = ($this->table==$mapping['Table'])?$this->table.'2':$this->table;

						$query = new \System\Data\QueryBuilder();
						$query->select( '*' );
						$query->from( $mapping['Table'] );
						if( $mapping["NotNull"] )
						{
							$query->innerJoin( $this->table, $mapping['ColumnKey'], $mapping['Table'], $mapping['ColumnRef'], $joinTable );
						}
						else
						{
							$query->leftJoin( $this->table, $mapping['ColumnKey'], $mapping['Table'], $mapping['ColumnRef'], $joinTable );
						}

						foreach( $this->relationships as $submapping )
						{
							if( $submapping['Relationship'] == RelationshipType::BelongsTo() )
							{
								if( class_exists( $submapping['Type'] ))
								{
									$ftype = ActiveRecordBase::addByType( $submapping['Type'] );

									if( $ftype->table <> $this->table )
									{
										if( $submapping["NotNull"] )
										{
											$query->innerJoin( $ftype->table, $submapping['ColumnRef'], $joinTable, $submapping['ColumnKey'] );
										}
										else
										{
											$query->leftJoin( $ftype->table, $submapping['ColumnRef'], $joinTable, $submapping['ColumnKey'] );
										}
									}
								}
							}
						}

						$query->where( $joinTable, $mapping['ColumnRef'], '=', $this[$mapping['ColumnKey']] );

						return $this->_ds->dataAdapter->openDataSet( $query );
					}
				}
			}
			throw new \System\InvalidOperationException(get_class($this)." has no relationship to ".$type);
		}


		/**
		 * static method to create new ActiveRecordBase by type
		 *
		 * @param  string		$type		object type
		 * @return ActiveRecordBase
		 */
		static private function addByType( $type, array $args = array() )
		{
			// create ActiveRecordBase
			$activeRecord = new $type();
			$activeRecord->beforeAdd();

			// create empty DataSet
			$query = new \System\Data\QueryBuilder();
			$query->select( '*' );
			$query->from( $activeRecord->table );
			$query->empty = true;

			$da = \System\AppServlet::getInstance()->dataAdapter;

			if(is_null($da))
			{
				throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
			}

			$activeRecord->_ds = $da->openDataSet( $query );

			// set args
			foreach( $args as $key => $value )
			{
				if( array_key_exists( (string)$key, $activeRecord->_ds->row ))
				{
					$activeRecord[(string)$key] = $value;
				}
				elseif( array_key_exists( $activeRecord->prefix.(string)$key, $activeRecord->_ds->row ))
				{
					$activeRecord[$activeRecord->prefix.(string)$key] = $value;
				}
				else
				{
					throw new \System\BadMemberCallException("property $key does not exist in ".get_class($activeRecord));
				}
			}

			$activeRecord->afterAdd();
			return $activeRecord;
		}


		/**
		 * static method to find ActiveRecordBase by type
		 *
		 * @param  string		$type		object type
		 * @param  string		$args		associative array of keys and values to find
		 * @return ActiveRecordBase
		 */
		static private function findByType( $type, array $args )
		{
			// create ActiveRecordBase
			$activeRecord = new $type();
			$activeRecord->beforeRetrieve();

			// create empty DataSet
			$query = new \System\Data\QueryBuilder();
			$query->select( '*' );
			$query->from( $activeRecord->table );
			$query->empty = true;

			$da = \System\AppServlet::getInstance()->dataAdapter;

			if(is_null($da))
			{
				throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
			}

			$ds_empty = $da->openDataSet( $query );

			// create filled DataSet
			$query = new \System\Data\QueryBuilder();
			$query->select( '*' );
			$query->from( $activeRecord->table );

			foreach( $args as $key => $value )
			{
				if( array_key_exists( (string)$key, $ds_empty->row ))
				{
					$query->where( $activeRecord->table, (string)$key, '=', $value );
				}
				elseif( array_key_exists( $activeRecord->prefix.(string)$key, $ds_empty->row ))
				{
					$query->where( $activeRecord->table, $activeRecord->prefix . (string)$key, '=', $value );
				}
				else
				{
					throw new \System\BadMemberCallException("property $key does not exist in ".get_class($activeRecord));
				}
			}

			$da = \System\AppServlet::getInstance()->dataAdapter;

			if(is_null($da))
			{
				throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
			}

			$ds = $da->openDataSet( $query );
			if( $ds->count > 0 )
			{
				$activeRecord->_ds = $ds;
				$activeRecord->afterRetrieve();

				return $activeRecord;
			}
			else
			{
				// Return null if not found
				return null;
			}
		}


		/**
		 * static method to find ActiveRecordBases by type
		 *
		 * @param  string		$type		object type
		 * @param  string		$args		associative array of keys and values to find
		 * @return ActiveRecordCollection
		 */
		static private function findAllByType( $type, array $args )
		{
			$activeRecord = ActiveRecordBase::addByType( $type );
			$records = new ActiveRecordCollection();

			$ds = ActiveRecordBase::dataSetByType( $type, $args );

			foreach( $ds->rows as $row )
			{
				$args = array();

				foreach( $ds->fields as $dataField )
				{
					if( $dataField->primaryKey )
					{
						if( $dataField->table == $activeRecord->table )
						{
							$args[$dataField->name] = $row[$dataField->name];
						}
					}
				}

				$record = ActiveRecordBase::findByType( $type, $args );

				if( !is_null( $record ))
				{
					$records->add( $record );
				}
				else
				{
					throw new \System\InvalidOperationException("key {$dataField->name}.{$row[$dataField->name]} exists in table {$dataField->table} with no record in table {$activeRecord->table}");
				}
			}

			return $records;
		}


		/**
		 * static method to find the first ActiveRecordBase by type
		 *
		 * @param  string		$type		object type
		 * @param  string		$args		associative array of keys and values to find
		 * @return ActiveRecordBase
		 */
		static private function firstByType( $type, array $args )
		{
			$activeRecord = ActiveRecordBase::addByType( $type );

			$ds = ActiveRecordBase::dataSetByType( $type, $args );
			$ds->first();

			$args = array();
			foreach( $ds->fields as $dataField )
			{
				if( $dataField->primaryKey )
				{
					if( $dataField->table == $activeRecord->table )
					{
						$args[$dataField->name] = $ds[$dataField->name];
					}
				}
			}

			return ActiveRecordBase::findByType( $type, $args );
		}


		/**
		 * static method to find the last ActiveRecordBase by type
		 *
		 * @param  string		$type		object type
		 * @param  string		$args		associative array of keys and values to find
		 *
		 * @return ActiveRecordBase
		 */
		static private function lastByType( $type, array $args )
		{
			$activeRecord = ActiveRecordBase::addByType( $type );

			$ds = ActiveRecordBase::dataSetByType( $type, $args );
			$ds->last();

			$args = array();
			foreach( $ds->fields as $dataField )
			{
				if( $dataField->primaryKey )
				{
					if( $dataField->table == $activeRecord->table )
					{
						$args[$dataField->name] = $ds[$dataField->name];
					}
				}
			}

			return ActiveRecordBase::findByType( $type, $args );
		}


		/**
		 * static method to return a DataSet by type
		 *
		 * @param  string		$type		object type
		 * @param  array		$params		filter
		 * @return DataSet
		 */
		static private function dataSetByType( $type, array $args )
		{
			$activeRecord = ActiveRecordBase::addByType( $type );
			$table = $activeRecord->table;
			$pkey  = $activeRecord->pkey;

			// build query
			$query = new \System\Data\QueryBuilder();
			$query->select( '*' );
			$query->from( $table );

			foreach( $args as $key => $value )
			{
				if( array_key_exists( (string)$key, $activeRecord->_ds->row ))
				{
					$query->where( $activeRecord->table, (string)$key, '=', $value );
				}
				elseif( array_key_exists( $activeRecord->prefix.(string)$key, $ds_empty->row ))
				{
					$query->where( $activeRecord->table, $activeRecord->prefix . (string)$key, '=', $value );
				}
				else
				{
					throw new \System\BadMemberCallException("property $key does not exist in ".get_class($activeRecord));
				}
			}

			$query->orderBy( $table, $pkey );

			return $activeRecord->_ds->dataAdapter->openDataSet( $query );
		}


		/**
		 * static method to return an extended DataSet by type
		 * Extended datasets include table data from all mapped tables
		 *
		 * @param  string		$type		object type
		 * @param  array		$params		filter
		 * @return DataSet
		 */
		static private function dataSetExtendedByType( $type, array $args )
		{
			$activeRecord = ActiveRecordBase::addByType( $type );
			$table = $activeRecord->table;
			$pkey  = $activeRecord->pkey;

			// build query
			$query = new \System\Data\QueryBuilder();
			$query->select( '*' );
			$query->from( $table );

			$i = 0;
			$tables = array($table);
			foreach( $activeRecord->relationships as $mapping ) {

				if( $mapping['Relationship'] == RelationshipType::BelongsTo() ) {

					// make sure class exists
					if( class_exists( $mapping['Type'] )) {
						$ftype = ActiveRecordBase::addByType( $mapping['Type'] );
						if( $ftype->table <> $table ) {

							$jointable = '';
							if(in_array($ftype->table,$tables)) {
								$jointable = "jointable{$i}";
							}
							else {
								$jointable = $ftype->table;
								$tables[] = $ftype->table;
							}
							$i++;

							$query->leftJoin( $ftype->table, $mapping['ColumnRef'], $table, $mapping['ColumnKey'], $jointable );
						}
					}
				}
			}

			foreach( $args as $key => $value )
			{
				if( array_key_exists( (string)$key, $activeRecord->_ds->row ))
				{
					$query->where( $activeRecord->table, (string)$key, '=', $value );
				}
				elseif( array_key_exists( $activeRecord->prefix.(string)$key, $ds_empty->row ))
				{
					$query->where( $activeRecord->table, $activeRecord->prefix . (string)$key, '=', $value );
				}
				else
				{
					throw new \System\BadMemberCallException("property $key does not exist in ".get_class($activeRecord));
				}
			}

			$query->orderBy( $table, $pkey );

			return $activeRecord->_ds->dataAdapter->openDataSet( $query );
		}


		/**
		 * set object properties or verify that properties have been manuall defined
		 * this method requires an SQLDataAdapter
		 *
		 * @return void
		 */
		private function _setProperties()
		{
			$da = \System\AppServlet::getInstance()->dataAdapter;

			if(is_null($da))
			{
				throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
			}

			// auto determine object properties
			if( $this->autoMapping ) {

				// cache file
				$cache_id = 'mappings:' . get_class($this);

				// read properties from cache file
				if( \System\IO\Cache::exists( $cache_id, \System\HTTPAppServlet::getInstance()->config->cacheExpires )) {
					$properties = unserialize( \System\IO\Cache::get( $cache_id ));

					$this->relationships = $properties['mappings'];
					$this->table	= $properties['table'];
					$this->pkey	 = $properties['pkey'];
					$this->prefix   = $properties['prefix'];
				}
				// auto determine properties
				else {

					/**
					 * auto determine table name using SQLDataAdapter source
					 * can be overridden
					 */
					if( !$this->table ) {
						$table = get_class( $this );

						if( strpos( $table, '\\' ) !== false )
						{
							$table = substr( strrchr( $table, '\\' ), 1 );
						}

						foreach( $da->getTables()->rows as $row ) {
							$row = array_values($row);
							if( strtolower( $row[0] ) === strtolower( $table )) {
								$this->table = $row[0];
								break;
							}
						}
						if( !$this->table ) {
							throw new \System\InvalidOperationException("table `{$table}` does not exist in SQLDataAdapter");
						}
					}

					$query = new \System\Data\QueryBuilder();
					$query->select( '*' );
					$query->from( $this->table );
					$query->empty = true;

					// create temp DataSet based on table
					$ds = $da->openDataSet( $query );

					/**
					 * auto determine the primary key using DataSet source
					 * can be overridden
					 */
					if( !$this->pkey ) {
						foreach( $ds->fields as $field ) {
							if( $field->primaryKey ) {
								$this->pkey = $field->name;
								break;
							}
						}
						if( !$this->pkey )
						{
							throw new \System\InvalidOperationException("table {$this->table} does not have a primary key");
						}
					}

					/**
					 * auto determine table prefix using tablename
					 * can be overridden
					 */
					$this->prefix = $this->prefix?$this->prefix:$this->table . '_';

					/**
					 * auto determine table mappings using DataSet source
					 * can be overridden
					 */
					if( $this->relationships->count === 0 )
					{
						$this->_autoMap( $ds );
					}

					// write properties to cache file
					$properties = array();
					$properties['mappings'] = $this->relationships;
					$properties['table']	= $this->table;
					$properties['prefix']   = $this->prefix;
					$properties['pkey']	 = $this->pkey;

					if( \System\AppServlet::getInstance()->config->cacheEnabled )
					{
						\System\IO\Cache::put( $cache_id, serialize( $properties ));
					}
				}
			}
			// check properties defined manually
			else {
				if( !$this->pkey ) {
					throw new \System\InvalidOperationException( get_class( $this ) . '::pkey is not defined' );
				}
				if( !$this->table ) {
					throw new \System\InvalidOperationException( get_class( $this ) . '::table is not defined' );
				}
			}
		}


		/**
		 * auto map object relationships
		 * requires instance of DataSet
		 *
		 * @param  DataSet		$ds			DataSet
		 * @return void
		 */
		private function _autoMap( \System\Data\DataSet &$ds )
		{
			/**
			 * complex mapping
			 * parse all the tables and map relationships "on the fly"
			 */
			$pkeys = array();

			$tables = array();
			foreach( $ds->dataAdapter->getTables()->rows as $row ) {
				$row = array_values($row);
				$tables[] = $row[0];
			}

			// loop through tables in database
			foreach( $tables as $ftable )
			{
				// ignore self
				if( $ftable != $this->table )
				{
					$query = new \System\Data\QueryBuilder();
					$query->select( '*' );
					$query->from( $ftable );
					$query->empty = true;

					// open an empty DataSet of the foreign table
					$foreign = $ds->dataAdapter->openDataSet( $query );
					if($foreign)
					{
						// get an array of pkeys of all foreign tables
						$fComposite = false;
						foreach( $foreign->fields as $field )
						{
							if( $field->primaryKey )
							{
								if( isset( $pkeys[$ftable] ))
								{
									$fComposite=true;
									unset( $pkeys[$ftable] );
								}
								elseif( !$fComposite )
								{
									$pkeys[$ftable] = $field->name;
								}
							}
						}
					}
				}
			}

			// loop through all tables in the database
			foreach( $tables as $ftable )
			{
				// get namespace of this object
				$namespace = substr(get_class($this), 0, strrpos(get_class($this), '\\')) . '\\';

				// set true another table has pkey of this table
				$pKeyFound = false;

				// ignore self
				if( $ftable != $this->table )
				{
					$query = new \System\Data\QueryBuilder();
					$query->select( '*' );
					$query->from( $ftable );
					$query->empty = true;

					// open an empty DataSet of the foreign table
					$foreign = $ds->dataAdapter->openDataSet( $query );
					if( $foreign )
					{
						/**
						 * if this tables primary is found in another
						 * table, map the relationship 1:n
						 */
						foreach( $foreign->fields as $field ) {
							if( $field->name === $this->pkey ) {
								$pKeyFound = true; // we have found this tables pkey in the foreign table
								if( isset( $pkeys[$ftable] )) {

									if( class_exists( $namespace . ucwords( $ftable ))) {

										$type = $namespace . ucwords( $ftable );

										$mapping = new Relationship(
											  RelationshipType::HasMany()
											, $type
											, $ftable
											, $this->pkey
											, $this->pkey
											, $field->notNull );

										$this->relationships->add($mapping);
									}
								}
							}
						}

						/**
						 * if another tables primary key is found in this
						 * table, map the relationship n:1
						 */
						foreach( $ds->fields as $field ) {
							if( isset( $pkeys[$ftable] )) {
								if( $field->name === $pkeys[$ftable] ) {

									if( class_exists( $namespace . ucwords( $ftable ))) {

										$type = $namespace . ucwords( $ftable );

										$mapping = new Relationship(
											  RelationshipType::BelongsTo()
											, $type
											, $this->table
											, $pkeys[$ftable]
											, $pkeys[$ftable]
											, $field->notNull );

										$this->relationships->add($mapping);
									}
								}
							}
						}

						/**
						 * if this tables primary key and another tables primary
						 * key is found in this table, map the relationship n:n
						 */
						foreach( $foreign->fields as $field ) {

							// found pkey of this table in foreign table
							if( $pKeyFound ) {

								// loop through all foreign tables
								foreach( $tables as $table ) {

									// ignore self
									if( $ftable != $table ) {

										// if foreign table has primary key?
										if( isset( $pkeys[$table] )) {

											// if foreign tables key = tables pkey
											if( $pkeys[$table] === $field->name ) {

												// if( $foreign->fields->count === 2 ) {

													if( class_exists( $namespace . ucwords( $table ))) {

														$type = $namespace . ucwords( $table );

														// found pkey of another table in foreign table
														$mapping = new Relationship(
															  RelationshipType::HasManyAndBelongsTo()
															, $type
															, $ftable
															, $pkeys[$table]
															, $this->pkey
															, $field->notNull );

														$this->relationships->add($mapping);
													}
												// } removed on Jan 22 2011
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
?>