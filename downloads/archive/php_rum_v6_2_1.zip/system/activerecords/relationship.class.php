<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\ActiveRecords;


	/**
	 * Represents a relationship between two ActiveRecordBase objects
	 *
	 * @property   RelationshipType $relationshipType Specifies the relationship type
	 * @property   string $type Specifies the object type
	 * @property   string $table Specifies the table name
	 * @property   string $columnRef Specifies the name of the reference field
	 * @property   string $columnKey Specifies the name of the key
	 * @property   bool $notNull Specifies whether the key is not null
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class Relationship implements \ArrayAccess
	{
		/**
		 * relationship type
		 * @var RelationshipType
		**/
		protected $relationshipType;

		/**
		 * object type
		 * @var string
		**/
		protected $type;

		/**
		 * table name
		 * @var string
		**/
		protected $table;

		/**
		 * name of reference field
		 * @var string
		**/
		protected $columnRef;

		/**
		 * name of key
		 * @var string
		**/
		protected $columnKey;

		/**
		 * specifies if key is not null
		 * @var bool
		**/
		protected $notNull;


		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function Relationship(RelationshipType $relationshipType, $type, $table, $columnRef, $columnKey, $notNull)
		{
			$this->relationshipType = $relationshipType;
			$this->type = (string)$type;
			$this->table = (string)$table;
			$this->columnRef = (string)$columnRef;
			$this->columnKey = (string)$columnKey;
			$this->notNull = (bool)$notNull;
		}


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field == 'relationshipType' )
			{
				return $this->relationshipType;
			}
			elseif( $field == 'type' )
			{
				return $this->type;
			}
			elseif( $field == 'table' )
			{
				return $this->table;
			}
			elseif( $field == 'columnRef' )
			{
				return $this->columnRef;
			}
			elseif( $field == 'columnKey' )
			{
				return $this->columnKey;
			}
			elseif( $field == 'notNull' )
			{
				return $this->notNull;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @param  string	$field		name of the field
		 * @param  mixed	$value		value of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field == 'relationshipType' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			elseif( $field == 'type' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			elseif( $field == 'table' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			elseif( $field == 'columnRef' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			elseif( $field == 'columnKey' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			elseif( $field == 'notNull' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$field} in ".get_class($this));
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetExists($index)
		{
			if( $index === 'Relationship' )
			{
				return true;
			}
			elseif( $index === 'Type' )
			{
				return true;
			}
			elseif( $index === 'Table' )
			{
				return true;
			}
			elseif( $index === 'ColumnRef' )
			{
				return true;
			}
			elseif( $index === 'ColumnKey' )
			{
				return true;
			}
			elseif( $index === 'NotNull' )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetGet($index)
		{
			if( $index === 'Relationship' )
			{
				return $this->relationshipType;
			}
			elseif( $index === 'Type' )
			{
				return $this->type;
			}
			elseif( $index === 'Table' )
			{
				return $this->table;
			}
			elseif( $index === 'ColumnRef' )
			{
				return $this->columnRef;
			}
			elseif( $index === 'ColumnKey' )
			{
				return $this->columnKey;
			}
			elseif( $index === 'NotNull' )
			{
				return $this->notNull;
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetSet($index, $value)
		{
			if( $index === 'Relationship' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'Type' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'Table' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'ColumnRef' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'ColumnKey' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'NotNull' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		function offsetUnset($index)
		{
			if( $index === 'Relationship' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'Type' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'Table' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'ColumnRef' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'ColumnKey' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			elseif( $index === 'NotNull' )
			{
				throw new \System\InvalidOperationException("cannot modify readonly property {$index} in ".get_class($this));
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}
	}
?>