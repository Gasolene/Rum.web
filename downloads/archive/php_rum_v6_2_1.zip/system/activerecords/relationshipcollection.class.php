<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\ActiveRecords;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a collection of Relationship objects
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class RelationshipCollection extends CollectionBase
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof Relationship )
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of class Relationship in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add
		 *
		 * Add a Relationship object to the Collection
		 *
		 * @param  Relationship $item
		 * @return void
		 */
		public function add( $item )
		{
			if( $item instanceof Relationship )
			{
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException ("Argument 1 passed to ".get_class($this)."::add() must be an object of class Relationship");
			}
		}


		/**
		 * return Relationship at a specified index
		 *
		 * @param  int		$index			index of Relationship
		 * @return Relationship				Relationship
		 */
		public function itemAt( $index )
		{
			return parent::itemAt($index);
		}
	}
?>