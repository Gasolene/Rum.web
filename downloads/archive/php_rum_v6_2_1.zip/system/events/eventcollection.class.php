<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Events;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of EventHandlerBase objects
	 * 
	 * @author			Darnell Shinbine
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class EventCollection extends CollectionBase
	{
		/**
		 * event handler collection
		 * @var EventHandlerCollection
		 */
		protected $eventHandlers		= null;


		/**
		 * Constructor
		 *
		 * @param  mixed	$collection		can be CollectionBase or array used to initialize Collection
		 * @return void
		 */
		public function EventCollection( $collection = null )
		{
			parent::CollectionBase( $collection );

			$this->eventHandlers = new EventHandlerCollection();
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'eventHandlers' )
			{
				return $this->eventHandlers;
			}
			elseif( $field === 'events' )
			{
				return $this->items;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * implement ArrayAccess methods
		 * @ignore
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof EventBase )
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of class EventBase in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add event handler to collection
		 *
		 * @param  EventBase $item
		 *
		 * @return void
		 * @ignore
		 */
		public function add( $item )
		{
			if( $item instanceof EventBase )
			{
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of class EventBase");
			}
		}


		/**
		 * returns true if item array contains item
		 *
		 * @param  mixed	$item		item
		 * @return bool					true if item found
		 */
		public function contains( $item )
		{
			foreach( $this->items as $event )
			{
				if( $event->name === $item )
				{
					return true;
				}
			}
		}


		/**
		 * returns first index of item found in Collection
		 *
		 * @param  mixed	$item		item
		 *
		 * @return int					index of item
		 */
		public function indexOf( $item )
		{
			for( $i = 0, $count = count( $this->items ); $i < $count; $i++ )
			{
				if( $this->items[$i]->name === $item )
				{
					return $i;
				}
			}
			return -1;
		}


		/**
		 * register event handler
		 *
		 * @param  EventHandlerBase $eventHandler
		 *
		 * @return void
		 */
		final public function registerEventHandler( EventHandlerBase $eventHandler )
		{
			return $this->eventHandlers->registerEventHandler( $eventHandler );
		}


		/**
		 * raise all events
		 *
		 * @param  EventBase	$event		event
		 * @param  object		$sender		Sender object
		 * @param  array		$args		optional args
		 * @return void
		 */
		final public function raise(EventBase $event, &$sender, array $args = array())
		{
			$this->eventHandlers->raise($event, $sender, $args);
		}
	}
?>