<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Events;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of Event args
	 * 
	 * @author			Darnell Shinbine
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	class EventArgs extends CollectionBase {}
?>