<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Events;


	/**
	 * Provides basic event handling
	 *
	 * @property string $event event
	 * @property string $callback callback
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class EventHandlerBase
	{
		/**
		 * event
		 * @var string
		 */
		private $event;


		/**
		 * callback
		 * @var string
		 */
		private $callback;


		/**
		 * Constructor
		 *
		 * @param  string $event event
		 * @param  string $callback call back
		 * @return void
		 */
		protected function EventHandlerBase($event, $callback)
		{
			$this->event = (string)$event;
			$this->callback = (string)$callback;
		}


		/**
		 * __get
		 *
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'callback' ) {
				return $this->callback;
			}
			elseif( $field === 'event' ) {
				return $this->event;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * raise event
		 *
		 * @param  object	$sender		Sender object
		 * @param  array	$args		optional args
		 * @return void
		 */
		final public function raise(&$sender, array $args = array())
		{
			if($this->callback)
			{
				if(__BACKWARDS_COMPATIBILITY_MODE__)
				{
					if(__SHOW_DEPRECATED_NOTICES__) {
						\trigger_error('`'.$this->callback.'(HTTPRequest &$request)'.'` is deprecated, use `'.$this->callback.'('.get_class($sender).', array $args = array())` instead', E_USER_NOTICE);
					}
					eval($this->callback.'(new \System\IO\HTTPRequest());');
				}
				else
				{
					eval($this->callback.'($sender, new \System\Events\EventArgs($args));');
				}
			}
		}
	}
?>