<!--//--><![CDATA[//><!--

	/**
	 * Initialize namespace
	 */
	var PHPRum = {};

	/**
	 * Function to get a xmlhttp object.
	 */
	PHPRum.createXMLHttpRequest = function() {

		if (window.XMLHttpRequest) { // Mozilla, Safari,...
			http_request = new XMLHttpRequest();

			if (http_request.overrideMimeType) {
				// set type accordingly to anticipated content type
				// http_request.overrideMimeType('text/xml');
				http_request.overrideMimeType('text/html');
			}
		} else if (window.ActiveXObject) { // IE
			try {
				http_request = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					http_request = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}

		if (!http_request) {
			alert('Cannot create XMLHTTP instance');
			return false;
		}

		return http_request;
	}


	/**
	 * Function to send a xmlhttp request.
	 */
	PHPRum.sendHttpRequest = function( url, params, method, callback ) {

		if (method == null){
			method = 'GET';
		}
		if (params == null){
			params = '';
		}

		if (method.toUpperCase() == 'GET' && params){
			if( url.indexOf( '?' ) > -1 ) {
				url = url + '&' + params;
			}
			else {
				url = url + '?' + params;
			}
			params = '';
		}

		http_request = PHPRum.createXMLHttpRequest();

		if (callback != null){
			eval( 'http_request.onreadystatechange=' + callback );
		}

		http_request.open(method, url, true);
		http_request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		http_request.setRequestHeader("Content-length", params.length);
		http_request.setRequestHeader("Connection", "close");
		http_request.send( params );

		return http_request;
	}


	/**
	 * Function to parse a xmlhttp response.
	 */
	PHPRum.parseXML = function( text ) {
		var doc

		// code for IE
		if (window.ActiveXObject) {
			doc = new ActiveXObject("Microsoft.XMLDOM");
			//doc.async = "false";
			doc.loadXML(text);
		}
		// code for Mozilla, Firefox, Opera, etc.
		else if (document.implementation && document.implementation.createDocument) {
			var parser = new DOMParser();
			doc = parser.parseFromString(text,"text/xml");
		}
		else {
			alert('Cannot create DOMParser instance');
			return false;
		}

		return doc;
	}

//--><!]]>