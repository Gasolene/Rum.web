<!--//--><![CDATA[//><!--


	/**
	 * Function to submit html forms
	 */
	PHPRum.submitForm = function( url, params, method, form, callback ) {

		var inputTags = form.getElementsByTagName( 'input' );
		var selectTags = form.getElementsByTagName( 'select' );
		var textareaTags = form.getElementsByTagName( 'textarea' );

		for( i=0; i < inputTags.length; i++ ) {

			if(inputTags[i].type == 'radio' || inputTags[i].type == 'checkbox'){
				if(inputTags[i].checked){
					param = inputTags[i].name + "=" + encodeURI( inputTags[i].value);
				} else {
					continue;
				}
			} else {
				param = inputTags[i].name + "=" + encodeURI( inputTags[i].value );
			}

			if (params) {
				params += "&" + param;
			}
			else {
				params = param;
			}
		}

		for( i=0; i < selectTags.length; i++ ) {
			param = selectTags[i].name + "=" + encodeURI( selectTags[i].value );

			if (params) {
				params += "&" + param;
			}
			else {
				params = param;
			}
		}

		for( i=0; i < textareaTags.length; i++ ) {
			param = textareaTags[i].name + "=" + encodeURI( textareaTags[i].value );

			if (params) {
				params += "&" + param;
			}
			else {
				params = param;
			}
		}

		return PHPRum.sendHttpRequest(url, params, 'POST', callback);
	}


	// example
	/*
	function getHttpResponse()
	{
		// if xmlhttp shows "loaded"
		if (http_request)
		{
			// if xmlhttp shows "loaded"
			if (http_request.readyState==4)
			{
				// if status "OK"
				if (http_request.status==200)
				{
					result = http_request.responseText;
					// ...place some code here...
				}
				else
				{
					// Problem retrieving XML data
				}
			}
		}
	}
	*/

//--><!]]>