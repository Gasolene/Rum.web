<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
    namespace Rum\Make;


	/**
	 * Provides functionality to generate controller/view files
	 */
	class Controller extends MakeBase
	{
		/**
		 * DefaultBaseController
		 * @var string
		 */
		const DefaultBaseController		= '\\ApplicationController';


		/**
		 * make
		 *
		 * @param string $target target
		 * @return void
		 */
		public function make($target)
		{
			$path = substr($target, 0, strrpos($target, '/'));

			$className = ucwords(substr(strrchr('/'.$target, '/'), 1));
			$baseNamespace = RootNamespace;
			$namespace = RootNamespace . ($path?'\\'.ucwords($path):'');
			$baseClassName = '\\'.RootNamespace.self::DefaultBaseController;
			$pageURI = $target;

			$controllerPath = \System\AppServlet::getInstance()->config->controllers . '/' . strtolower($target) . __CONTROLLER_EXTENSION__;
			$viewPath = \System\AppServlet::getInstance()->config->views . '/' . strtolower($target) . __TEMPLATE_EXTENSION__;
			$testCasePath = __FUNCTIONAL_TESTS_PATH__ . '/' . strtolower($target) . strtolower(__CONTROLLER_TESTCASE_SUFFIX__) . __CLASS_EXTENSION__;
			$fixturePath = __FIXTURES_PATH__ . '/' . strtolower($className) . '.sql';

			$controllerTemplate = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/controller.tpl");
			$controllerTemplate = str_replace("<Namespace>", $namespace, $controllerTemplate);
			$controllerTemplate = str_replace("<BaseNamespace>", $baseNamespace, $controllerTemplate);
			$controllerTemplate = str_replace("<ClassName>", $className, $controllerTemplate);
			$controllerTemplate = str_replace("<BaseClassName>", $baseClassName, $controllerTemplate);
			$controllerTemplate = str_replace("<PageURI>", $pageURI, $controllerTemplate);
			$controllerTemplate = str_replace("<TemplateExtension>", __TEMPLATE_EXTENSION__, $controllerTemplate);

			$viewTemplate = $template = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/view.tpl");
			$viewTemplate = str_replace("<Namespace>", $namespace, $viewTemplate);
			$viewTemplate = str_replace("<BaseNamespace>", $baseNamespace, $viewTemplate);
			$viewTemplate = str_replace("<ClassName>", $className, $viewTemplate);
			$viewTemplate = str_replace("<BaseClassName>", $baseClassName, $viewTemplate);
			$viewTemplate = str_replace("<PageURI>", $pageURI, $viewTemplate);
			$viewTemplate = str_replace("<TemplateExtension>", __TEMPLATE_EXTENSION__, $viewTemplate);

			$testCaseTemplate = $template = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/controllertestcase.tpl");
			$testCaseTemplate = str_replace("<Namespace>", $namespace, $testCaseTemplate);
			$testCaseTemplate = str_replace("<BaseNamespace>", $baseNamespace, $testCaseTemplate);
			$testCaseTemplate = str_replace("<ClassName>", $className, $testCaseTemplate);
			$testCaseTemplate = str_replace("<BaseClassName>", $baseClassName, $testCaseTemplate);
			$testCaseTemplate = str_replace("<PageURI>", $pageURI, $testCaseTemplate);
			$testCaseTemplate = str_replace("<TemplateExtension>", __TEMPLATE_EXTENSION__, $testCaseTemplate);
			$testCaseTemplate = str_replace("<Fixture>", strtolower($className).'.sql', $testCaseTemplate);

			$fixtureTemplate = $template = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/controllerfixture.tpl");
			$fixtureTemplate = str_replace("<PageURI>", $pageURI, $fixtureTemplate);

			$this->export($controllerPath, $controllerTemplate);
			$this->export($viewPath, $viewTemplate);
			$this->export($testCasePath, $testCaseTemplate);
			$this->export($fixturePath, $fixtureTemplate);
		}
	}
?>