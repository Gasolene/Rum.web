<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Make;


	/**
	 * include configuration script
	 */
	include __ROOT__ . '/app/config/make/config.php';


	/**
	 * Provides the interface for Make scripts
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class MakeBase
	{
		/**
		 * make
		 *
		 * @param string $target target
		 * @return void
		 */
		abstract public function make($target);


		/**
		 * export
		 *
		 * @param string $path path
		 * @param string $contents contents
		 * @return vod
		 */
		protected function export($path, $contents)
		{
			$dir = ucwords(substr($path, 0, strrpos($path, '/')));

			if(!\is_dir($dir))
			{
				print("creating directory ".$dir."\n");
				\mkdir($dir);
			}

			if(!file_exists($path))
			{
				print("writing file ".$path."\n");

				$fp = @fopen($path, "w+");
				if(is_resource($fp))
				{
					fwrite($fp, $contents);
					fclose($fp);
				}
				else
				{
					print("could not write file {$path}, make sure directory exists and write permissions are granted\n");
				}
			}
			else
			{
				print("cannot write file {$path}, file already exists\n");
			}
		}
	}


	/**
	 * deplomyent script
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class Make extends \System\AppServlet
	{
		/**
		 * execute the application
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 *
		 * @return  void
		 */
		protected function execute($argc, $argv)
		{
			if(!$_SERVER[__ENV_PARAMETER__]) $_SERVER[__ENV_PARAMETER__] = __DEV_ENV__;

			if($_SERVER[__ENV_PARAMETER__]==__DEV_ENV__)
			{
				if(isset($argv[1]) && isset($argv[2]) && \strpos($argv[1], "-")!==0 && \strpos($argv[2], "-")!==0)
				{
					$options = $this->getOptions($argc, $argv);
					$script = $argv[1];
					$target = $argv[2];

					$makeScript = __ROOT__ . '/rum/make/scripts/' . strtolower($script) . '.php';

					if( file_exists( $makeScript))
					{
						require_once $makeScript;

						$makeClass = "Rum\\Make\\{$script}";

						if( class_exists( $makeClass ))
						{
							$make = new $makeClass();

							$make->make($target, $options);
						}
						else
						{
							throw new \System\InvalidOperationException( "deployment script `$makeScript` is not defined" );
						}
					}
					else
					{
						throw new \System\IO\FileNotFoundException( "deployment script `$makeScript` does not exist" );
					}
				}
				else
				{
					throw new \System\InvalidArgumentException( "you must specify the script and target" );
				}
			}
		}


		/**
		 * retrieve command line options
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 *
		 * @return  array
		 */
		protected function getOptions($argc, $argv)
		{
			$options = array();
			for($i = 0; $i < $argc; $i++)
			{
				if($argv[$i] == "--help")
				{
					echo "Executes a make script

PHP MAKE.RUM [script] [target]

   [script] [target]
			  Specifies the script and the target output
			  file to generate

  --help      Displays this help screen

";
					\passthru("pause");
					exit;
				}
			}

			return $options;
		}


		/**
		 * event triggered by an uncaught Exception thrown in the application, can be overridden to provide error handling.
		 *
		 * @param  \Exception	$e
		 *
		 * @return void
		 */
		protected function handleException(\Exception $e) {die($e->getMessage());}


		/**
		 * event triggered by an error in the application, can be overridden to provide error handling.
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 *
		 * @return void
		 */
		protected function handleError($errno, $errstr, $errfile, $errline) {die("{$errstr} in {$errfile} on line {$errline}");}
	}
?>