<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Deploy;


	/**
	 * Provides base functionality for connecting via SSH
	 *
	 * @property string $fixtures comma seperated string containing fixture filenames
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class SSHClientBase
	{
		/**
		 * server
		 * @var string
		 */
		public $server		= 'localhost';

		/**
		 * port
		 * @var int
		 */
		public $port			= 22;

		/**
		 * username
		 * @var string
		 */
		public $username		= 'root';

		/**
		 * password
		 * @var string
		 */
		public $password		= '';


		/**
		 * Constructor
		 *
		 * @return  void
		 */
		public function SSHClientBase() {}


		/**
		 * execute on remote server
		 *
		 * @param   string		$cmd		command to run on remote server
		 * @return  void
		 */
		final protected function run( $cmd )
		{
			$pw = $this->password?" -pw {$this->password}":"";
			\passthru("plink -v -ssh {$this->server} -l {$this->username}{$pw} {$cmd}");
		}


		/**
		 * put file on remote server
		 *
		 * @param   string		$repository_path		local path
		 * @param   string		$home_path				remote path
		 * @return  void
		 */
		final protected function put( $local_path, $remote_path )
		{
			$pw = $this->password?" -pw {$this->password}":"";
			\passthru("pscp -v -r -P {$this->port}{$pw} \"{$local_path}\" {$this->username}@{$this->server}:{$remote_path}");
		}
	}
?>