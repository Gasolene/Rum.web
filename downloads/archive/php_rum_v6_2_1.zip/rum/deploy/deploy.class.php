<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Deploy;


	/**
	 * deplomyent script
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	final class Deploy extends \System\AppServlet
	{
		/**
		 * execute the application
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 *
		 * @return  void
		 */
		protected function execute($argc, $argv)
		{
			if(!$_SERVER[__ENV_PARAMETER__]) $_SERVER[__ENV_PARAMETER__] = __DEV_ENV__;

			if($_SERVER[__ENV_PARAMETER__]==__DEV_ENV__)
			{
				$options = $this->getOptions($argc, $argv);
				$target = isset($argv[1])?(\strpos($argv[1], "-")===0?"prod":$argv[1]):"prod";
				$task = isset($argv[2])?((\strpos($argv[1], "-")===0||\strpos($argv[2], "-")===0)?"deploy":$argv[2]):"deploy";

				$deploymentScript = __DEPLOY_PATH__ . '/' . strtolower($target) . __DEPLOYMENT_EXTENSION__;

				if( file_exists( $deploymentScript))
				{
					require_once $deploymentScript;

					$deploymentClass = "Rum\\Deploy\\{$target}";

					if( class_exists( $deploymentClass ))
					{
						$deploy = new $deploymentClass;

						if(isset($options["username"]))
						{
							$deploy->username = $options["username"];
						}

						if(isset($options["password"]))
						{
							$deploy->password = $options["password"];
						}

						if(\method_exists($deploy, $task))
						{
							$deploy->{$task}();
						}
						else
						{
							throw new \System\InvalidOperationException( "task `$task` is not defined" );
						}
					}
					else
					{
						throw new \System\InvalidOperationException( "deployment script `$deploymentClass` is not defined" );
					}
				}
				else
				{
					throw new \System\IO\FileNotFoundException( "deployment script `$deploymentScript` does not exist" );
				}
			}
		}


		/**
		 * retrieve command line options
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 *
		 * @return  array
		 */
		protected function getOptions($argc, $argv)
		{
			$options = array();
			for($i = 0; $i < $argc; $i++)
			{
				if($argv[$i] == "-u")
				{
					if(isset($argv[$i+1]))
					{
						$options["username"] = $argv[$i+1];
					}
				}
				elseif($argv[$i] == "-pw")
				{
					if(isset($argv[$i+1]))
					{
						$options["password"] = $argv[$i+1];
					}
				}
				elseif($argv[$i] == "--help")
				{
					echo "Executes a deployment script

PHP DEPLOY.RUM [target] [task] [-u] [-pw]

   [target] [task]
              Specifies the target script and the task to execute. The 
              default values are [prod] [deploy]

  -u          Specifies an optional username
  -pw         Specifies an optional password
  --help      Displays this help screen

";
					\passthru("pause");
					exit;
				}
			}

			return $options;
		}


		/**
		 * event triggered by an uncaught Exception thrown in the application, can be overridden to provide error handling.
		 *
		 * @param  \Exception	$e
		 *
		 * @return void
		 */
		protected function handleException(\Exception $e) {die($e->getMessage());}


		/**
		 * event triggered by an error in the application, can be overridden to provide error handling.
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 *
		 * @return void
		 */
		protected function handleError($errno, $errstr, $errfile, $errline) {die("{$errstr} in {$errfile} on line {$errline}");}
	}
?>