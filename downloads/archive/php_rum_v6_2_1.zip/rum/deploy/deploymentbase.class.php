<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Deploy;


	/**
	 * Provides base functionality for the deployment environment
	 *
	 * @property string $fixtures comma seperated string containing fixture filenames
	 * 
	 * @package			PHPRum
	 * @author			Darnell Shinbine <gasolene@gmail.com>
	 */
	abstract class DeploymentBase extends SSHClientBase
	{
		/**
		 * home path
		 * @var string
		 */
		public $home_path;

		/**
		 * repository path
		 * @var string
		 */
		public $repository_path;

		/**
		 * release path
		 * @var string
		 */
		public $release_path;


		/**
		 * Constructor
		 *
		 * @return  void
		 */
		public function DeploymentBase()
		{
			$this->release_path = $this->release_path?$this->release_path:"{$this->home_path}/releases/" . date('YmdGms', time());
		}
	}
?>