Rum.manual
==========