Rum.manual
==========