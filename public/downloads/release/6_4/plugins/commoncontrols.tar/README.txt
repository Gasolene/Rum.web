CommonControls plugin

version 1.3 - 11-18-11
	- upgrade for Rum1.0-beta

version 1.2 - 09.06.11
	- removed EmailValidation and URLValidation

version 1.1 - 07.14.11
	- fixed bug where cardexpirationdateselector not send ajax postback
	- fixed bug where CSVView and PDVView inherits the wrong object
	- fixed bug in CardInput where not validating blank card numbers

To Install...

	1. unpack the contents into the /app/plugins folder
	2. copy the assets into the /html/assets folder
