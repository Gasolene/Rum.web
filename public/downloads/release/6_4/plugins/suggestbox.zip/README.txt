SuggestBox plugin

version 1.1 - 07.14.11
	- major change, no longer sends XML message to client, now uses eval()
	- optimized performance

To Install...

	1. unpack the contents into the /app/plugins folder
	2. copy the assets into the /html/assets folder

Known Issues...

	1. the Lookup control won't work if item value has multiple spaces or tabs
