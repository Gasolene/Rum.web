Calendar plugin

To Install...

	1. unpack the contents into the /app/plugins folder
	2. copy the assets into the /html/assets folder
