<?php
	/**
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
    namespace JQuery;

	/**
	 * JQuery theme
	 * @var string
	 */
	const theme = 'ui-lightness';
?>