GD plugin

Version 1.1
Modified July 29, 2010
Author: Darnell

To Install...

	1. unpack the contents into the /app/plugins folder
