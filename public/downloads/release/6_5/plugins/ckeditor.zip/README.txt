CKEditor plugin 3.6.2

To Install...

	1. unpack the contents into the /app/plugins folder
	2. copy the assets into the /html/assets folder

	03/26/13
		- fixed bug when assets folder not present
