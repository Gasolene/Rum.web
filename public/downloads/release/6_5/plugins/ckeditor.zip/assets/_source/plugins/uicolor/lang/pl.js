﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'uicolor', 'pl',
{
	uicolor :
	{
		title : 'Wybór koloru interfejsu',
		preview : 'Podgląd na żywo',
		config : 'Wklej poniższy łańcuch znaków do pliku config.js:',
		predefined : 'Predefiniowane zestawy kolorów'
	}
});
