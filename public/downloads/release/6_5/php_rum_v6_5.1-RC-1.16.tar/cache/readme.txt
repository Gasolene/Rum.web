This folder contains all the cache files for the application and is managed by the core framework.
You can safely remove all the files in this folder.