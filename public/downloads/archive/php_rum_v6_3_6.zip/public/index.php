<?php
	/**
	 * Startup script
	 * This script creates an instance of the servlet and begins execution
	 *
	 * This is the only PHP page directly accessed by the web
	 * Do not modify this script!
	 *
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */

	namespace MyApp;

	/**
	 * include env conf and framework loader (should be relative paths)
	 */
	include '../app/config/environment.php';
	include '../system/includes/loader.php';

	// create instance of the application and run!!!
	\System\AppServlet::getInstance( new Main() )->run();
?>