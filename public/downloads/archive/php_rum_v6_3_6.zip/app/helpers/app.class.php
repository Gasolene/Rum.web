<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace MyApp;


	/**
	 * Provides access to application services
	 *
	 * It contains such things as the session data, configuration data,
	 * server messages and application state.  It also provides methods for
	 * forwarding, message handling, URL rewriting and logging.
	 *
	 * @version			1.0
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 */
	final class App
	{
		/**
		 * This method returns a handle to the AppConfig object
		 *
		 * @return  AppConfiguration
		 */
		static public function config()
		{
			return \System\AppServlet::getInstance()->config;
		}


		/**
		 * This method returns a handle to the DataAdapter object
		 *
		 * @return  SQLDataAdapter
		 */
		static public function dataAdapter()
		{
			return \System\AppServlet::getInstance()->dataAdapter;
		}


		/**
		 * This method returns a handle to the current controller
		 *
		 * @return  PageController
		 */
		static public function requestHandler()
		{
			return \System\AppServlet::getInstance()->requestHandler;
		}


		/**
		 * This method returns a handle to the Session object
		 *
		 * @return  Session
		 */
		static public function session()
		{
			return \System\AppServlet::getInstance()->session;
		}


		/**
		 * This method sets the next URI once the current controller is finished executing, the servlet will
		 * re-request the page with the requested action.  This method allows you to replace post data
		 * with keep friendly urls that can be bookmarked.
		 *
		 * @param   string				$nextPage					Name of requested page
		 * @param   array				$args						args for next action
		 * @param   ForwardMethodType	$method						forward method as constant of ForwardMethodType::URI() or ForwardMethodType::Request()
		 * @return  void
		 */
		static public function forward( $nextPage = '', array $args = array(), \System\ForwardMethodType $method = null )
		{
			\System\HTTPAppServlet::getInstance()->setForwardPage( $nextPage, $args, $method );
		}


		/**
		 * add message to message stack
		 *
		 * @param   string			$msg		Message content
		 * @param   AppMessageType	$type	   Message type as constant of AppMessageType::Success(), AppMessageType::Fail() or AppMessageType::Notice()
		 * @return  void
		 */
		static public function flash( $msg, \System\AppMessageType $type = null )
		{
			$type = $type?$type:\System\AppMessageType::Notice();

			$msgObj = array();
			if( strtolower( substr( $msg, 0, 2 )) == 'n:' ) {
				$type = \System\AppMessageType::Notice();
				$msg  = substr( $msg, 2 );
			}
			elseif( strtolower( substr( $msg, 0, 2 )) == 'f:' ) {
				$type = \System\AppMessageType::Fail();
				$msg  = substr( $msg, 2 );
			}
			elseif( strtolower( substr( $msg, 0, 2 )) == 's:' ) {
				$type = \System\AppMessageType::Success();
				$msg  = substr( $msg, 2 );
			}

			\System\AppServlet::getInstance()->messages->add( new \System\AppMessage( (string) $msg, $type ));
		}


		/**
		 * Automatically writes a string to a log file stamped with the current time
		 *
		 * @param  string	$event		event to log
		 * @param  string	$logfile	path to log file
		 * @return void
		 */
		static public function log( $event, $logfile = 'log.txt' )
		{
			\System\AppServlet::getInstance()->log( $event, $logfile );
		}


		/**
		 * returns a URI based on the requested page and parameters
		 *
		 * @param   string		$page			name of page
		 * @param   array		$args			array of parameters
		 * @return  string						raw URI
		 */
		static public function uri( $page = '', array $args = array() )
		{
			return \System\HTTPAppServlet::getInstance()->getPageURI( $page, $args );
		}


		/**
		 * returns a URL based on the requested page and parameters
		 *
		 * @param   string		$page			name of the page
		 * @param   array		$args			array of parameters
		 * @return  string						raw URL
		 */
		static public function url( $page = '', array $args = array() )
		{
			return __PROTOCOL__ . '://' . __HOST__ . \System\HTTPAppServlet::getInstance()->getPageURI( $page, $args );
		}


		/**
		 * send HTTP status message to client
		 *
		 * @param   int			$statuscode		HTTP status code
		 * @return void
		 */
		static public function sendHTTPError( $statuscode = 500 )
		{
			return \System\HTTPAppServlet::getInstance()->sendHTTPError( $statuscode );
		}
	}
?>