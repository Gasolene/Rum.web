<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System;
	use \Exception;


	/**
	 * Represents a base Exception
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 */
	class ExceptionBase extends Exception {}
?>