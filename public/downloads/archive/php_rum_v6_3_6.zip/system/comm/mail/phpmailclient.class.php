<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Comm\Mail;


	/**
	 * Handles email sending via PHP mail() function
	 * 
	 * @package			PHPRum
	 * @subpackage		Mail
	 * @author			Darnell Shinbine
	 */
	class PHPMailClient implements IMailClient
	{
		/**
		 * sends a single email to all addresses in message
		 *
		 * @param MailMessage $message message to send
		 * @return void
		 */
		public function send(MailMessage $message)
		{
			if( !mail( $message->to, $message->subject, $message->getContent(), $message->getHeaders() ))
			{
				throw new \System\InvalidOperationException("mail was not accepted for delivery, check php mail configuration");
			}
		}
	}
?>