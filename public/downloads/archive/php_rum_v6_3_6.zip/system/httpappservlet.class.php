<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System;


	/**
	 * Provides the base HTTP funcionality of the application.  This class recieves request data from
	 * the client, identifies the action to perform, and initiates a Controller
	 * to handle the requested action.  Once the Controller has been executed, this class will regain control
	 * and render the View selected by the Controller unless there are additional actions to perform.
	 *
	 * @property   ControllerBase $requestHandler Reference to the current ControllerBase
	 * @property   string $prevPage Previous page
	 * @property   string $thisPage Current page
	 * @property   string $forwardPage Page to forward to
	 * @property   string $forwardURI URI to forward to
	 * @property   array $forwardParams array of forward parameters
	 * @property   Session $session Reference to the Session
	 * @property   AppMessageCollection $messages Contains the AppMessageCollection object
	 *
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 */
	abstract class HTTPAppServlet extends AppServlet
	{
		/**
		 * Contains the current ControllerBase
		 * @var ControllerBase
		 */
		private $_requestHandler			= null;

		/**
		 * Specifies the id of the current page
		 * @var string
		 */
		private $_thisPage					= '';

		/**
		 * Specifies the id of the previous page
		 * @var string
		 */
		private $_prevPage					= '';

		/**
		 * Specifies the id of the next page
		 * @var string
		 */
		private $_forwardPage				= '';

		/**
		 * Specifies the id of the forward URI Resource
		 * @var string
		 */
		private $_forwardURI				= '';

		/**
		 * Specifies the forward URI parameters
		 * @var array
		 */
		private $_forwardParams				= array();

		/**
		 * Contains an array of runtime errors
		 * @var array
		 */
		private $_warnings					= array();

		/**
		 * Contains the _session object
		 * @var _session
		 */
		private $_session					= null;

		/**
		 * Contains the AppMessageCollection object
		 * @var AppMessageCollection
		 */
		private $_messages					= null;


		/**
		 * Constructor
		 *
		 * Creates an instance of the controller and sets default action map.
		 *
		 * @return  void
		 */
		public function __construct()
		{
			parent::__construct();

			$this->_session  = new \System\IO\Session();
			$this->_messages = new \System\AppMessageCollection();
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		final public function __get( $field )
		{
			if( $field === 'requestHandler' ) {
				return $this->_requestHandler;
			}
			elseif( $field === 'prevPage' ) {
				return $this->_prevPage;
			}
			elseif( $field === 'thisPage' ) {
				return $this->_thisPage;
			}
			elseif( $field === 'forwardPage' ) {
				return $this->_forwardPage;
			}
			elseif( $field === 'forwardURI' ) {
				return $this->_forwardURI;
			}
			elseif( $field === 'forwardParams' ) {
				return $this->_forwardParams;
			}
			elseif( $field === 'session' ) {
				return $this->_session;
			}
			elseif( $field === 'messages' ) {
				return $this->_messages;
			}
			else {
				return parent::__get( $field );
			}
		}


		/**
		 * return the _requestHandler
		 *
		 * @param   string			$controller		name of the controller
		 * @return  ControllerBase					Controller
		 */
		final public function getRequestHandler( $controller )
		{
			// reset state
			$this->_thisPage = $controller;
			$this->_forwardURI = null;
			$this->_forwardPage = null;
			$this->_forwardParams = array();

			// replace dashes with underscores
			$controller = str_replace( '-', '_', $controller );

			// get include path
			$includePath = $this->config->controllers . '/' . strtolower( $controller ) . __CONTROLLER_EXTENSION__;
			$className = $this->namespace . "\\" . ucwords( str_replace( '/', '\\', $controller ));

			if( !defined( INCLUDEPREFIX . $includePath ))
			{
				define( INCLUDEPREFIX . $includePath, true );

				if( !include $includePath )
				{
					\System\HTTPAppServlet::getInstance()->sendHTTPError(404);
				}
			}

			if( class_exists( $className ))
			{
				// Assign reference
				$this->_requestHandler = new $className( $controller );
				return $this->_requestHandler;
			}
			else
			{
				throw new InvalidOperationException( "class `{$className}` not found" );
			}
		}


		/**
		 * returns a URI based on the requested page and parameters
		 *
		 * @param   string		$page			name of page
		 * @param   array		$args			array of parameters
		 * @return  string						raw URI
		 */
		final public function getPageURI( $page = '', array $args = array() )
		{
			$cookieless_session = true;

			if( isset( $args['PHPSESSID'] ))
			{
				unset( $args['PHPSESSID'] );
			}
			else
			{
				$cookieless_session = $this->config->cookielessSession;
			}

			$uri = $this->config->uri;

			// get controller
			$page = strtolower( urldecode( $page?str_replace( '.', '/', str_replace( '_', '-', $page ) ):\System\AppServlet::getInstance()->thisPage ));

			if( $this->config->rewriteURIS )
			{
				$id = __PAGE_EXTENSION__;

				if( !empty( $args['id'] ))
				{
					$id = '/' . $args['id'];
					unset( $args['id'] );
				}

				// build uri
				$uri .= ($cookieless_session?'/('.$this->_session->sessionId.')':'') . '/' . $page . $id;
			}
			else {
				// append _session to parameter list
				if( $cookieless_session ) {
					$args['PHPSESSID'] = $this->_session->sessionId;
				}

				// append page to parameter list
				if( $page ) {
					$args[$this->config->requestParameter] = $page;
				}

				// build uri
				$uri .= substr( $_SERVER['SCRIPT_NAME'], strrpos( $_SERVER['SCRIPT_NAME'], '/' ));
			}

			// add parameters to query string
			$params = '';
			foreach( $args as $key => $value )
			{
				if( $params )
				{
					$params .= "&$key=$value";
				}
				else {
					$params .= "?$key=$value";
				}
			}

			// create query string
			return $uri . $params;
		}


		/**
		 * send HTTP status message to client
		 *
		 * @param   int			$statuscode		HTTP status code
		 * @return void
		 */
		final public function sendHTTPError( $statuscode = 500 )
		{
			$response = new \System\IO\HTTPResponse(); // start output buffer

			// check if error code is mapped to controller
			if( isset( $this->config->errors[$statuscode] ))
			{
				$page = $this->config->errors[$statuscode];

				$requestHandler = $this->getRequestHandler( $page );
				$requestHandler->requestProcessor( new \System\IO\HTTPRequest() );

				// Render View
				$requestHandler->getView()->render();
			}
			else
			{
				$response->statusCode = $statuscode;
			}

			\System\IO\HTTPResponse::end(); // flush and end output buffer
		}


		/**
		 * This method sets the next URI once the current controller is finished executing, the servlet will
		 * re-request the page with the requested action.  This method allows you to replace post data
		 * with keep friendly urls that can be bookmarked.
		 *
		 * @param   string				$nextPage					Name of requested page
		 * @param   array				$args						args for next action
		 * @param   ForwardMethodType	$method						forward method as constant of ForwardMethodType::URI() or ForwardMethodType::Request()
		 * @return  void
		 */
		final public function setForwardPage( $nextPage = '', array $args = array(), ForwardMethodType $method = null )
		{
			$method = $method?$method:ForwardMethodType::URI();
			$nextPage = (string)$nextPage?(string)$nextPage:$this->_thisPage;
			$nextPage = str_replace( '.', '/', $nextPage );

			$this->_prevPage = $this->_thisPage;
			$this->_forwardParams = $args;

			if( $method == ForwardMethodType::URI() )
			{
				$this->_forwardURI = $nextPage;
			}
			else
			{
				$this->_forwardPage = $nextPage;
			}
		}


		/**
		 * This method clear all forward URI's
		 *
		 * @return  void
		 */
		final public function clearForwardPage()
		{
			$this->_forwardURI = '';
			$this->_forwardPage = '';
			$this->_forwardParams = array();
		}


		/**
		 * Returns a static instance of the http app server.
		 *
		 * @param  AppServlet		$initialize		new instance of an AppServlet object
		 * @return HTTPAppServlet						static reference to an HTTPAppServlet
		 */
		final static public function & getInstance( AppServlet $initialize = null )
		{
			$HTTPAppServlet = AppServlet::getInstance($initialize);

			if($HTTPAppServlet instanceof HTTPAppServlet)
			{
				return $HTTPAppServlet;
			}
			else
			{
				throw new \Exception( 'The HTTPAppServlet has not been initialized' );
			}
		}


		/**
		 * execute the application
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 * @return  void
		 */
		final protected function execute($argc, $argv)
		{
			// Start _session
			$this->_startSession();

			// Handle Request Params
			if($_SERVER[__ENV_PARAMETER__]==__DEV_ENV__||$_SERVER[__ENV_PARAMETER__]==__TEST_ENV__) $this->_handleRequestParams(new \System\IO\HTTPRequest());

			// Load Application State
			$this->loadApplicationState();

			// Process Request
			$this->requestProcessor( new \System\IO\HTTPRequest() );

			// Save Spplication State
			$this->saveApplicationState();

			// End _session
			$this->_endSession();
		}


		/**
		 * This method retrieves an instance of the previous action and the servlet _messages.  These can then
		 * be used by the servlet to populate the view.
		 *
		 * @return  void
		 */
		final protected function loadApplicationState()
		{
			if( isset( $this->_session[$this->applicationId.'_configuration_messages'] ))
			{
				$this->_messages = unserialize( $this->_session[$this->applicationId.'_configuration_messages'] );
			}
			if( isset( $this->_session[$this->applicationId.'_configuration_forward'] ))
			{
				$this->_prevPage = $this->_session[$this->applicationId.'_configuration_forward'];
			}

			if( $this->debug )
			{
				if( isset( $this->_session[$this->applicationId.'_debug_warnings'] ))
				{
					$this->_warnings = array_merge( $this->_warnings, unserialize( $this->_session[$this->applicationId.'_debug_warnings'] ));
				}
			}
		}


		/**
		 * This method stores an instance of the previous action and the servlet _messages.  These can then
		 * be used by the servlet after a page request to populate the view.
		 *
		 * @return  void
		 */
		final protected function saveApplicationState()
		{
			$this->_session[$this->applicationId.'_configuration_messages'] = serialize( $this->_messages );
			$this->_session[$this->applicationId.'_configuration_forward'] = $this->_prevPage;

			if( $this->debug )
			{
				$this->_session[$this->applicationId.'_debug_warnings'] = serialize( $this->_warnings );
			}
		}


		/**
		 * Processe HTTP Request and create actions to handle business logic.  Then render the view.
		 * Can be overwridden to provide additional or alternaitive private functionality.
		 *
		 * @param   HTTPRequest		$request	HTTPRequest object
		 * @return  void
		 */
		protected function requestProcessor( \System\IO\HTTPRequest &$request )
		{
			// get controller from request
			if( isset( $request->post[$this->config->requestParameter] ))
			{
				// Get Controller based on HTTP POST page parameter
				$this->_forwardPage = $request->post[$this->config->requestParameter];
			}
			elseif( isset( $request->get[$this->config->requestParameter] ))
			{
				// Get Controller based on HTTP GET page parameter
				$this->_forwardPage = $request->get[$this->config->requestParameter];
			}
			else
			{
				// Get Controller based on XML configuration
				$this->_forwardPage = $this->config->defaultController;
			}

			$request[$this->config->requestParameter] = strtolower( $this->_forwardPage );

			while( $this->_forwardPage )
			{
				// Dispatch controller
				$_requestHandler = $this->getRequestHandler( $this->_forwardPage );

				// Handle Security
				if( \System\Security\Authentication::isProtected( $_requestHandler->controllerId ))
				{
					// Basic Authentication
					if( \System\Security\Authentication::method() === 'basic' )
					{
						if( !\System\Security\BasicAuthentication::authenticated() )
						{
							// Send HTTP authenticate headers
							\System\Security\BasicAuthentication::sendAuthHeaders();
							return;
						}
					}
					// Forms Authentication
					elseif( \System\Security\Authentication::method() === 'forms' )
					{
						if( !\System\Security\FormsAuthentication::authenticated() )
						{
							// Redirect to login page
							\System\Security\FormsAuthentication::redirectToLoginPage();
							return;
						}
					}
				}

				$headersCacheId = '';
				$outputCacheId = '';

				// Handle Output Cache
				if( $_requestHandler->outputCache > 0 )
				{
					$hashId = 'hash:' . $_requestHandler->controllerId;

					// Output Caching Enabled
					if( \System\IO\HTTPRequest::getRequestMethod() === 'GET' )
					{
						$hash = '';

						if(\System\IO\Cache::exists($hashId, $_requestHandler->outputCache))
						{
							$hash = \System\IO\Cache::get($hashId);
						}
						else
						{
							$hash = (string)time() . '/' . $_requestHandler->controllerId . '/';

							if( $this->config->cacheEnabled )
							{
								\System\IO\Cache::put($hashId, $hash);
							}
						}

						// Generate Cache ID's
						$headersCacheId = 'output_headers:'.$hash.$_requestHandler->getCacheId($request);
						$outputCacheId = 'output:'.$hash.$_requestHandler->getCacheId($request);

						// Output Cache Exists
						if( \System\IO\Cache::exists( $outputCacheId, $_requestHandler->outputCache ))
						{
							$response = new \System\IO\HTTPResponse();

							// Send Headers
							if( \System\IO\Cache::exists( $headersCacheId, $_requestHandler->outputCache ))
							{
								$headers = unserialize( \System\IO\Cache::get($headersCacheId));
								foreach( $headers as $header )
								{
									\System\IO\HTTPResponse::addHeader($header);
								}
							}

							// Send Output
							\System\IO\HTTPResponse::write( \System\IO\Cache::get( $outputCacheId ));

							$this->_insertDebug($response, $_requestHandler->outputCache );

							return;
						}
					}
					else
					{
						\System\IO\Cache::clear($hashId);
					}
				}

				// Process request
				$_requestHandler->requestProcessor( $request );

				if( !$this->_forwardPage )
				{
					// Get View
					$view = $_requestHandler->getView();

					if( $this->_forwardURI )
					{
						// Forward URI (redirect)
						$this->_forwardURI( $this->_forwardURI, (array)$this->_forwardParams );
						return;
					}

					// Render View
					$response = new \System\IO\HTTPResponse(); // start output buffer
					$view->render();

					// Capture output for cache
					if( $_requestHandler->outputCache > 0 &&
						\System\IO\HTTPRequest::getRequestMethod() === 'GET' &&
						$this->_messages->count === 0 &&
						$this->config->cacheEnabled )
					{
						\System\IO\Cache::put( $headersCacheId, serialize( \System\IO\HTTPResponse::headers ));
						\System\IO\Cache::put( $outputCacheId, \System\IO\HTTPResponse::contents );
					}

					$this->_insertDebug($response);

					// Cleanup
					$this->_messages->removeAll();
					$this->_warnings = array();
					$this->_prevPage = '';
				}
				else
				{
					// handle forward params
					foreach( $this->_forwardParams as $key => $value )
					{
						$request[$key] = $value;
					}
					$this->_forwardParams = array();
				}

				// Remove reference
				unset($this->_requestHandler);
			}
		}


		/**
		 * event triggered by an uncaught Exception thrown in the application, can be overridden to provide error handling.
		 *
		 * @param  Exception	$e
		 *
		 * @return void
		 */
		protected function handleException(\Exception $e)
		{
			if( $this->debug )
			{
				$backtrace = $e->getTrace();

				foreach( $backtrace as $trace )
				{
					if( strstr( $trace['file'], __SYSTEM_PATH__ ) === false )
					{
						$file = $trace['file'];
						$line = $trace['line'];
						break;
					}
				}

				$source = '';
				$line = isset($line)?$line:$e->getLine();
				$file = isset($file)?$file:$e->getFile();
				$contents = file($file);
				$filename = str_replace( __ROOT__, '', $file );

				for( $i = $line > 3 ? $line - 3 : 0, $ii = 0; $ii <= 5; $ii++, $i++ )
				{
					$current_line = (string)$i.':';
					while( strlen( $current_line ) < 6 ) $current_line .= ' ';

					if( isset( $contents[$i-1] ))
					{
						$contents[$i-1] = htmlentities($contents[$i-1]);

						if( $i === $line )
						{
							$source .= "<span style=\"font-weight:bold;color:#AA0000\">Line $current_line{$contents[$i-1]}</span>";
						}
						else
						{
							$source .= "<span>Line $current_line{$contents[$i-1]}</span>";
						}
					}
				}

				// bad form, not structured - but the only way to clear the output buffer
				ob_clean();

				$response = new \System\IO\HTTPResponse();

				\System\IO\HTTPResponse::addHeader( "Content-Type: text/html" );
				\System\IO\HTTPResponse::write( "<!DOCTYPE html>
<html lang=\"en\">
<head>
<title>Unhandled Exception: {$e->getMessage()}</title>
<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\">
<link href=\"" . $this->config->assets . "/debug/exception.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
<script src=\"" . $this->config->assets . "/debug/debug.js\" type=\"text/javascript\"></script>
</head>
<body>

<div id=\"tl\">
<div id=\"tr\">
<div id=\"bl\">
<div id=\"br\">

<h1>Unhandled Exception in " . strrchr( $e->getFile(), '/' ) . "</h1>

<div id=\"details\" class=\"fail\">
<h2>Runtime Error: {$e->getMessage()}</h2>
<p><strong>Description:</strong> An unhandled exception occurred during execution</p>
<p><strong>Details:</strong> " . get_class($e) . ": {$e->getMessage()}</p>
<p><strong>Source File:</strong> {$filename} <strong>on line:</strong> {$line}
</div>

<pre>
<strong>Source Information:</strong>

{$source}
</pre>

<pre>
<strong>Stack Trace:</strong>\r\n\r\n");

				$this->_dumpCallStack($e->getTrace());
				\System\IO\HTTPResponse::write( "
</pre>

<p class=\"dump\" id=\"debug_show\"><a href=\"#debug_dump\" onclick=\"document.getElementById('debug_info').style.display='block';document.getElementById('debug_show').style.display='none';\">Show Debug Information</a></p>
<div style=\"display:none;\" id=\"debug_info\">");

				$this->_dumpDebug();

				\System\IO\HTTPResponse::write( "
</div>

<div id=\"version\">
<p><strong>Framework Version:</strong> ".FRAMEWORK_VERSION_STRING."</p>
</div>

</div>
</div>
</div>
</div>

</body>
</html>" );
			}
			else
			{
				$this->log( "Uncaught Exception: {$e->getMessage()} in {$e->getFile()} on line {$e->getLine()}", 'error.log' );
				\System\HTTPAppServlet::getInstance()->sendHTTPError( 500 );
			}
		}


		/**
		 * event triggered by an error in the application, can be overridden to provide error handling.
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 * @return void
		 */
		protected function handleError($errno, $errstr, $errfile, $errline)
		{
			$errcode = array (
			   E_ERROR				=> "Error",
			   E_WARNING			=> "Warning",
			   E_PARSE				=> "Parsing Error",
			   E_NOTICE				=> "Notice",
			   E_RECOVERABLE_ERROR	=> "Recoverable Fatal Error",
			   E_CORE_ERROR			=> "Core Error",
			   E_CORE_WARNING		=> "Core Warning",
			   E_COMPILE_ERROR		=> "Compile Error",
			   E_COMPILE_WARNING	=> "Compile Warning",
			   E_USER_ERROR			=> "User Error",
			   E_USER_WARNING		=> "User Warning",
			   E_USER_NOTICE		=> "User Notice",
			   E_STRICT				=> "Runtime Notice"
			   );

			if( $errno & ( E_ERROR | E_RECOVERABLE_ERROR | E_USER_ERROR | E_COMPILE_ERROR | E_CORE_ERROR ))
			{
				// throw ErrorException on fatal errors
				throw new \ErrorException($errstr, $errno, 0, $errfile, $errline);
			}
			else
			{
				if(count($this->_warnings)<=__ERROR_LIMIT__+1)
				{
					$backtrace = debug_backtrace();
					array_shift( $backtrace );
					array_shift( $backtrace );

					// add error to _warnings
					array_push( $this->_warnings, array('errno'		=> $errno,
														'errstr'	=> $errstr,
														'errfile'	=> $errfile,
														'errline'	=> $errline,
														'backtrace'	=> $backtrace ));
				}
			}
		}


		/**
		 * Start _session, sets _session id (using request parameter)
		 *
		 * @return  void
		 */
		private function _startSession()
		{
			if( isset( $_POST['PHPSESSID'] ))
			{
				$this->_session->start( $_POST['PHPSESSID'] );
			}
			elseif( isset( $_GET['PHPSESSID'] ))
			{
				$this->_session->start( $_GET['PHPSESSID'] );
			}
			else
			{
				$this->_session->start();
			}

			unset( $_POST['PHPSESSID'] );
			unset( $_GET['PHPSESSID'] );
		}


		/**
		 * endSession
		 *
		 * @return  void
		 */
		private function _endSession()
		{
			$this->_session->close();
		}


		/**
		 * run helper commands
		 *
		 * @param   HTTPRequest		$request		HTTPRequest object
		 * @return  void
		 */
		private function _handleRequestParams( \System\IO\HTTPRequest &$request )
		{
			if(isset($request["flush_cache"]))
			{
				IO\Cache::flush();
			}
			elseif(isset($request["run_all"]))
			{
				$this->runAllTestCases($this->_getTestCaseReporter());
				exit;
			}
			elseif(isset($request["run_unit_test"]))
			{
				$this->runUnitTestCase($request["run_unit_test"], $this->_getTestCaseReporter());
				exit;
			}
			elseif(isset($request["run_functional_test"]))
			{
				$this->runFunctionalTestCase($request["run_functional_test"], $this->_getTestCaseReporter());
				exit;
			}
		}


		/**
		 * Forward the HTTP request to another HTTP request (redirect)
		 *
		 * @param   string		$page			page name
		 * @param   array		$args			args
		 * @return  void
		 */
		private function _forwardURI( $page, array $args = array() )
		{
			\System\IO\HTTPResponse::redirect( $this->getPageURI( $page, $args ), false );
		}


		/**
		 * output debugging information
		 *
		 * @param  HTTPResponse		$response		HTTPResponse object
		 * @param  int				$mode			debug mode
		 * @return void
		 */
		private function _insertDebug( \System\IO\HTTPResponse $response, $ttl=0 )
		{
			if( $this->debug )
			{
				$raw = \System\IO\HTTPResponse::getResponseContent();
				\System\IO\HTTPResponse::clear();

				$this->_dumpDebug($ttl);

				$debug = \System\IO\HTTPResponse::getResponseContent();
				\System\IO\HTTPResponse::clear();

				if( strpos( $raw, '</html>' ) !== FALSE )
				{
					$raw = str_replace( '</body>', '', $raw );
					$raw = str_replace( '</html>', '', $raw );

					\System\IO\HTTPResponse::write( "$raw\n\n$debug\n\n</body>\n</html>" );
				}
				else
				{
					\System\IO\HTTPResponse::write( $raw );
				}
			}
		}


		/**
		 * output debugging information
		 *
		 * @param  int		 	$ttl		time to live (used for output caching)
		 * @return void
		 */
		private function _dumpDebug( $ttl=0 )
		{
			if( $this->debug )
			{
				$elapsed = $this->timer->elapsed();
				$response = new \System\IO\HTTPResponse();

				$errcode = array (
				   E_ERROR		   => "Fatal Error",
				   E_WARNING		 => "Warning",
				   E_PARSE		   => "Parsing Error",
				   E_NOTICE		  => "Notice",
				   E_CORE_ERROR	  => "Core Error",
				   E_CORE_WARNING	=> "Core Warning",
				   E_COMPILE_ERROR   => "Compile Error",
				   E_COMPILE_WARNING => "Compile Warning",
				   E_USER_ERROR	  => "User Error",
				   E_USER_WARNING	=> "User Warning",
				   E_USER_NOTICE	 => "User Notice",
				   E_STRICT		  => "Runtime Notice"
				   );

				// dump app stats
				\System\IO\HTTPResponse::write( "<pre id=\"debug_panel\" class=\"debug_panel\">" );
				\System\IO\HTTPResponse::write( "<a class=\"debug_close\" style=\"float:right;\" href=\"#\" onclick=\"PHPRumDebug.debugOpen()\">Open debug panel</a>" );
				\System\IO\HTTPResponse::write( "</pre>" );
				\System\IO\HTTPResponse::write( "<pre id=\"debug_dump\" class=\"debug_dump\">" );
				\System\IO\HTTPResponse::write( "<a class=\"debug_close\" style=\"float:right;\" href=\"#\" onclick=\"PHPRumDebug.debugClose();\">Close</a>" );
				\System\IO\HTTPResponse::write( "<strong>Debug Dump:</strong>\r\n\r\n" );
				\System\IO\HTTPResponse::write( "application running in debug mode\n" );
				\System\IO\HTTPResponse::write( "app env: ".$_SERVER[__ENV_PARAMETER__]."\n" );
				\System\IO\HTTPResponse::write( "PHP version: ".phpversion()."\n" );
				if($ttl>0) \System\IO\HTTPResponse::write( "caching: output is cached {$ttl}s\n" );
				if(ini_get('apc.enabled')==1) \System\IO\HTTPResponse::write( "apc is enabled: ".ini_get("apc.ttl")."s\n" );
				\System\IO\HTTPResponse::write( "execution time: " . $elapsed . "s\n" );

				// mem usage
				if( function_exists( 'memory_get_usage' )) {
					//\System\IO\HTTPResponse::write( "memory usage: " . \number_format(( memory_get_usage( true ) / 1048576 ), 2, '.', '' ) . " MB\n" ); // MB = 1048576, Kb = 1024
				}

				// dump data adapter info
				if( $this->config->dsn )
				{
					$adapter = '';
					if( strrchr( get_class($this->dataAdapter), '\\') !== false )
					{
						$adapter = substr( strrchr( str_replace( 'dataadapter', '', strtolower( get_class( $this->dataAdapter ))), '\\' ), 1 );
					}
					else
					{
						$adapter = str_replace( 'dataadapter', '', strtolower( get_class( $this->dataAdapter )));
					}

					\System\IO\HTTPResponse::write( "adapter: " . $adapter . '; ' . $this->dataAdapter->getQueryCount() . " queries in " );
					\System\IO\HTTPResponse::write( $this->dataAdapter->getQueryTime() . "s\n" );
				}
				\System\IO\HTTPResponse::write( "framework version: ".FRAMEWORK_VERSION_STRING."\n" );

				// dump _warnings
				if( sizeof( $this->_warnings ) > 0 )
				{
					$count = sizeof( $this->_warnings );
					if($count > __ERROR_LIMIT__)
					{
						\System\IO\HTTPResponse::write( "<strong>warnings: &gt;".__ERROR_LIMIT__." (displaying the first ".__ERROR_LIMIT__.")</strong>\n" );
					}
					else
					{
						\System\IO\HTTPResponse::write( "<strong>warnings: " . $count . "</strong>\n" );
					}

					\System\IO\HTTPResponse::write( "<a href=\"#errs\" onclick=\"document.getElementById( 'errs' ).style.display='block';\">dump warnings:</a>\n" );

					\System\IO\HTTPResponse::write( "<span id=\"errs\" style=\"display:none;\">" );
					$i=0;
					foreach( $this->_warnings as $err )
					{
						\System\IO\HTTPResponse::write( "<a href=\"#err".$i."\" onclick=\"document.getElementById('err".$i."').style.display='block';\"><b>" . $errcode[$err['errno']] . ":</b> " . $err['errstr'] . " in <b>" . $err['errfile'] . "</b> on line <b>" . $err['errline'] . "</b></a>\n" );
						\System\IO\HTTPResponse::write( "<span id=\"err".$i."\" style=\"display:none;\">" );
						\System\IO\HTTPResponse::write( "<map name=\"errno".$i."\" id=\"errno".$i."\">" );
						$this->_dumpCallStack(  $err['backtrace'] );
						\System\IO\HTTPResponse::write( "</map>" );
						\System\IO\HTTPResponse::write( "</span>" );

						if(++$i>=__ERROR_LIMIT__) break;
					}
					\System\IO\HTTPResponse::write( "</span>" );
				}

				// dump request data
				\System\IO\HTTPResponse::write( "<a href=\"#req\" onclick=\"document.getElementById( 'req' ).style.display='block';\">dump request data:</a>\n" );
				\System\IO\HTTPResponse::write( "<span id=\"req\" style=\"display:none;\">" );

				\System\IO\HTTPResponse::write( "  <a href=\"#req_get\" onclick=\"document.getElementById( 'req_get' ).style.display='block';\">dump get data:</a>\n" );

				\System\IO\HTTPResponse::write( "<a id=\"req_get\" style=\"display:none;\">" );
				ob_start();
				print_r($_GET);
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $output ));
				\System\IO\HTTPResponse::write( "  </a>" );

				\System\IO\HTTPResponse::write( "  <a href=\"#req_post\" onclick=\"document.getElementById( 'req_post' ).style.display='block';\">dump post data:</a>\n" );
				\System\IO\HTTPResponse::write( "<a id=\"req_post\" style=\"display:none;\">" );
				ob_start();
				print_r($_POST);
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $output ));
				\System\IO\HTTPResponse::write( "  </a>" );

				\System\IO\HTTPResponse::write( "  <a href=\"#req_cookie\" onclick=\"document.getElementById( 'req_cookie' ).style.display='block';\">dump cookie data:</a>\n" );
				\System\IO\HTTPResponse::write( "<a id=\"req_cookie\" style=\"display:none;\">" );

				ob_start();
				print_r($_COOKIE);
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $output ));

				\System\IO\HTTPResponse::write( "  </a>" );

				\System\IO\HTTPResponse::write( "</span>" );

				// dump request headers
				\System\IO\HTTPResponse::write( "<a href=\"#req_headers\" onclick=\"document.getElementById( 'req_headers' ).style.display='block';\">dump request headers:</a>\n" );
				\System\IO\HTTPResponse::write( "<a id=\"req_headers\" style=\"display:none;\">" );

				$req_headers = array( 'request headers only supported when running as apache module' );
				if( function_exists( 'apache_request_headers' )) {
					$req_headers = apache_request_headers();
				}

				ob_start();
				print_r( $req_headers );
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $output ));
				\System\IO\HTTPResponse::write( "</a>" );

				// dump response headers
				\System\IO\HTTPResponse::write( "<a href=\"#response_headers\" onclick=\"document.getElementById( 'response_headers' ).style.display='block';\">dump response headers:</a>\n" );
				\System\IO\HTTPResponse::write( "<a id=\"response_headers\" style=\"display:none;\">" );

				ob_start();
				print_r( headers_list() );
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $this->_replaceNonPrinting( $output )));

				\System\IO\HTTPResponse::write( "</a>" );

				// dump session
				\System\IO\HTTPResponse::write( "<a href=\"#session\" onclick=\"document.getElementById( 'session' ).style.display='block';\">dump session:</a>\n" );
				\System\IO\HTTPResponse::write( "<a id=\"session\" style=\"display:none;\">" );

				ob_start();
				print_r($_SESSION);
				$output = ob_get_clean();
				\System\IO\HTTPResponse::write( htmlentities( $this->_replaceNonPrinting( $output )));

				\System\IO\HTTPResponse::write( "</a>" );

				\System\IO\HTTPResponse::write( "</pre>" );
				\System\IO\HTTPResponse::write( "<script type=\"text/javascript\">PHPRumDebug.debugCheck()</script>" );
			}
		}


		/**
		 * dump call stack
		 *
		 * @return void
		 */
		private function _dumpCallStack( array $callstack )
		{
			$response = new \System\IO\HTTPResponse();

			$i=0;
			foreach( $callstack as $call )
			{
				if(isset($call['file'])) {
					$current_level = '#'.$i++;
					while( strlen( $current_level ) < 3 ) $current_level .= ' ';

					\System\IO\HTTPResponse::write( "<span style=\"color:#000000;\">{$current_level}</span> " );

					if( isset( $call['class'] ))
					{
						\System\IO\HTTPResponse::write( "<span style=\"font-weight:bold;color:#0000AA;\">{$call['class']}-></span>" );
					}

					\System\IO\HTTPResponse::write( "<span style=\"font-weight:bold;color:#0000AA;\">{$call['function']}(</span>" );

					$ii=0;
					if(isset($call['args']))
					{
						foreach( $call['args'] as $arg ) {
							$trace = htmlentities(addslashes(print_r($arg,true)));
							if( $ii++ > 0 ) {
								\System\IO\HTTPResponse::write( "," );
							}
							if( is_object( $arg )) {
								\System\IO\HTTPResponse::write( "<span style=\"color:#0000FF\">Object</span>(<span onclick=\"getElementById('trace_{$call['line']}_{$i}_{$ii}').style.display='inline';\" style=\"text-decoration:underline;cursor:pointer;color:#000000\">".get_class($arg)."</span>)" );
							}
							elseif( is_array( $arg )) {
								\System\IO\HTTPResponse::write( "<span style=\"text-decoration:underline;cursor:pointer;color:#0000FF\" onclick=\"getElementById('trace_{$call['line']}_{$i}_{$ii}').style.display='inline';\">Array</span>" );
							}
							elseif( is_string( $arg )) {
								\System\IO\HTTPResponse::write( "<span style=\"color:#0000FF\">string</span>(<span style=\"color:#FF0000\">\"{$arg}\"</span>)" );
							}
							elseif( is_scalar( $arg )) {
								\System\IO\HTTPResponse::write( "<span style=\"color:#0000FF\">".gettype($arg)."</span>(<span style=\"color:#FF0000\">".$arg."</span>)" );
							}
							else {
								\System\IO\HTTPResponse::write( "<span style=\"color:#0000FF\">".gettype($arg)."</span>(<span style=\"color:#FF0000\">__PHP_Incomplete_Class</span>)" );
							}
							\System\IO\HTTPResponse::write( "<span id=\"trace_{$call['line']}_{$i}_{$ii}\" style=\"display:none;\">$trace</span>" );
						}
					}
					\System\IO\HTTPResponse::write( "<span style=\"font-weight:bold;color:#0000AA;\">)</span>" );
					\System\IO\HTTPResponse::write(" <strong>in</strong> " . str_replace( __ROOT__, '', $call['file'] ). " <strong>on line</strong> {$call['line']}\r\n");
				}
			}
		}


		/**
		 * replace non printing characters
		 *
		 * @param   string		$output		sting to format
		 * @return string
		 */
		private function _replaceNonPrinting( $output )
		{
			$output = str_replace( "\x00", '', $output );
			$output = str_replace( "\x01", '', $output );
			$output = str_replace( "\x02", '', $output );
			$output = str_replace( "\x03", '', $output );
			$output = str_replace( "\x04", '', $output );
			$output = str_replace( "\x05", '', $output );
			$output = str_replace( "\x06", '', $output );
			$output = str_replace( "\x07", '', $output );
			$output = str_replace( "\x08", '', $output );
			$output = str_replace( "\x09", '', $output );
			// $output = str_replace( "\x0A", '', $output );
			$output = str_replace( "\x0B", '', $output );
			$output = str_replace( "\x0C", '', $output );
			$output = str_replace( "\x0D", '', $output );
			$output = str_replace( "\x0E", '', $output );
			$output = str_replace( "\x0F", '', $output );

			$output = str_replace( "\x10", '', $output );
			$output = str_replace( "\x11", '', $output );
			$output = str_replace( "\x12", '', $output );
			$output = str_replace( "\x13", '', $output );
			$output = str_replace( "\x14", '', $output );
			$output = str_replace( "\x15", '', $output );
			$output = str_replace( "\x16", '', $output );
			$output = str_replace( "\x17", '', $output );
			$output = str_replace( "\x18", '', $output );
			$output = str_replace( "\x19", '', $output );
			$output = str_replace( "\x1A", '', $output );
			$output = str_replace( "\x1B", '', $output );
			$output = str_replace( "\x1C", '', $output );
			$output = str_replace( "\x1D", '', $output );
			$output = str_replace( "\x1E", '', $output );
			$output = str_replace( "\x1F", '', $output );

			return $output;
		}


		/**
		 * return test reporter
		 *
		 * @return  HTMLTestReporter
		 */
		private function _getTestCaseReporter() {
			require_once __SYSTEM_PATH__ . '/testcase/htmltestreporter' . __CLASS_EXTENSION__;
			return new \System\Testcase\HTMLTestReporter();
		}
	}
?>