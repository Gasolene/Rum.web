<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Events;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of Event args
	 * 
	 * @package			PHPRum
	 * @subpackage		Events
	 * @author			Darnell Shinbine
	 */
	class EventArgs extends CollectionBase {}
?>