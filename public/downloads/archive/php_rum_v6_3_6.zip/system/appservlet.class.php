<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 *
	 *
	 */
	namespace System;


	/**
	 * Provides the base funcionality of the application.  This class recieves command line
	 * data and executes the application
	 *
	 * @property   string $applicationId Specifies the application Id
	 * @property   string $namespace Specifies the application namespace
	 * @property   AppConfiguration $config Reference to the AppConfiguration
	 * @property   DataAdapter $dataAdapter Reference to the DataAdapter
	 * @property   bool $debug Specifies whether the application is in debug mode
	 * @property   Timer $timer Reference to the app Timer
	 *
	 * @package			PHPRum
	 *
	 */
	abstract class AppServlet
	{
		/**
		 * Specifies the application id
		 * @var string
		 */
		private $_applicationId				= '';

		/**
		 * _namespace application resides in
		 * @var string
		 */
		private $_namespace					= '';

		/**
		 * Contains the AppConfiguration object
		 * @var AppConfiguration
		 */
		private $_config					= null;

		/**
		 * Contains the application _dataAdapter
		 * @var _dataAdapter
		 */
		private $_dataAdapter				= null;

		/**
		 * specifies whether _debug mode is on
		 * @var bool
		 */
		private $_debug						= false;

		/**
		 * Contains the app execution start time in microseconds
		 * @var Timer
		 */
		private $_timer						= null;

		/**
		 * dsn connection string
		 * @var string
		 */
		private $_dsn						= '';

		/**
		 * set if run() has been called
		 * @var bool
		 */
		private $_running					= false;


		/**
		 * Constructor
		 *
		 * Creates an instance of the controller and sets default action map.
		 *
		 * @return  void
		 */
		public function __construct()
		{
			$className = get_class($this);
			$class_namespace = substr($className, 0, strrpos($className, '\\'));

			$this->_applicationId = $class_namespace?$class_namespace:get_class($this);
			$this->_namespace = $class_namespace?"\\".$class_namespace:'';
			$this->_config = new \System\Configuration\AppConfiguration();
			$this->_timer = new \System\Utils\Timer(true);
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'applicationId' ) {
				return $this->_applicationId;
			}
			elseif( $field === 'namespace' ) {
				return $this->_namespace;
			}
			elseif( $field === 'config' ) {
				return $this->_config;
			}
			elseif( $field === 'messages' ) {
				return $this->_messages;
			}
			elseif( $field === 'dataAdapter' ) {
				return $this->_getDataAdapter();
			}
			elseif( $field === 'debug' ) {
				return $this->_debug;
			}
			elseif( $field === 'session' ) {
				return $this->_session;
			}
			elseif( $field === 'timer' ) {
				return $this->_timer;
			}
			else {
				throw new BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * there can exists only one instance of this class
		 * So this method will throw an exception if someone tries to call it.
		 *
		 * @throws BadMethodCallException An new BadMethodCallException instance
		 * @return void
		 * @ignore
		 */
		final public function __clone()
		{
			throw new BadMethodCallException('There can exist only one instance of ' . get_class( $this ));
		}


		/**
		 * begin processing of the servlet
		 *
		 * @return  void
		 */
		final public function run()
		{
			global $argc, $argv;

			$e = null;
			try
			{
				if( !$this->_running )
				{
					// lock ServletBase
					$this->_running = true;

					// load global application configuration
					$this->loadAppConfig( __CONFIG_PATH__ . __APP_CONF_FILENAME__ );

					// load env application configuration
					if($_SERVER[__ENV_PARAMETER__]) {
						$this->loadAppConfig( __ENV_PATH__ . '/' . strtolower($_SERVER[__ENV_PARAMETER__]) . __APP_CONF_FILENAME__ );
					}

					// set session timeout directive
					ini_set( 'session.cookie_lifetime', $this->_config->sessionTimeout );

					// enable error handling
					set_error_handler( "\System\AppServlet::throwError" );

					// enable shutdown handling
					register_shutdown_function( "\System\AppServlet::shutDown" );

					// setup debug Mode
					if( $this->_debug )
					{
						// load debuging tools
						include __SYSTEM_PATH__ . '/includes/debug.inc.php';
					}

					// handle any command line requests
					if($_SERVER[__ENV_PARAMETER__]==__DEV_ENV__||$_SERVER[__ENV_PARAMETER__]==__TEST_ENV__) $this->_handleCommandLineArgs($argc, $argv);

					// execute application
					$this->execute($argc, $argv);
				}
				else
				{
					throw new InvalidOperationException("cannot call ".get_class($this)."::run(), ".get_class($this)." is already running");
				}
			}
			catch(\Exception $e)
			{
				// Handle Exception if Exception is thrown
				$this->handleException($e);
			}
		}


		/**
		 * Automatically writes a string to a log file stamped with the current time
		 *
		 * @param  string	$event		event to log
		 * @param  string	$logfile	path to log file
		 * @return void
		 */
		public function log( $event, $logfile = 'log.txt' )
		{
			$log = fopen( __LOG_PATH__ . '/' . $logfile, 'ab+' );

			if($log)
			{
				if( fwrite( $log, date( 'Y-m-d H:i:s', time() ) . "\t" . $event . "\n" ))
				{
					fclose( $log );
				}
				else
				{
					throw new InvalidOperationException("could not write to log file {$logfile}");
				}
			}
			else
			{
				throw new InvalidOperationException("could not open file {$logfile} for output");
			}
		}


		/**
		 * Returns a static instance of the app server.  This provides a way of accessing app variables
		 * from outside the class.
		 *
		 * must be initialized by $controller = AppServlet::getinstance( $servletObject );
		 *
		 * @param  AppServlet		$initialize		new instance of an AppServlet object
		 * @return AppServlet						static reference to an AppServlet
		 */
		static public function & getInstance( AppServlet $initialize = null )
		{
			static $instance = array();

			// initialize application
			if( $initialize )
			{
				if( !$instance )
				{
					$instance[0] =& $initialize;
				}
				else
				{
					throw new \Exception( 'There can exist only one instance of ' . get_class($instance[0]) );
				}
			}

			// return instance
			if( isset( $instance[0] ))
			{
				return $instance[0];
			}
			else
			{
				throw new \Exception( 'The AppServlet has not been initialized' );
			}
		}


		/**
		 * Catch an error, this method is the registered error handler
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 *
		 * @return void
		 * @ignore
		 */
		final static public function throwError( $errno, $errstr, $errfile, $errline )
		{
			AppServlet::getInstance()->handleError($errno, $errstr, $errfile, $errline);
		}


		/**
		 * Catch an error, this method is the registered shutdown handler
		 *
		 * @return void
		 * @ignore
		 */
		final static public function shutDown()
		{
			AppServlet::getInstance()->handleShutDown();
		}


		/**
		 * loads config data from an xml file
		 *
		 * @param   string			$xml_config		path to xml _config file
		 * @return  void			true if successfull
		 */
		protected function loadAppConfig( $xmlConfig )
		{
			$cacheId = 'app-config:' . strtolower( $xmlConfig );

			// Retrieve App_config from cache
			if( IO\Cache::exists( $cacheId ))
			{
				$data = IO\Cache::get( $cacheId );
				$appConfigObj = unserialize( $data );

				if( $appConfigObj->cacheExpires > 0 )
				{
					if( IO\Cache::exists( $cacheId, $appConfigObj->cacheExpires ))
					{
						$this->_config = $appConfigObj;
						$this->_debug = ( $this->_config->state == AppState::debug() )?TRUE:FALSE;
						$this->_dsn = AppServlet::getInstance()->_config->dsn;
						return;
					}
				}
				else
				{
					$this->_config = $appConfigObj;
					$this->_debug = ( $this->_config->state == AppState::debug() )?TRUE:FALSE;
					$this->_dsn = AppServlet::getInstance()->_config->dsn;
					return;
				}
			}

			// Parse XML file

			$this->_config->loadAppConfig( $xmlConfig );
			$serialized = serialize( $this->_config );

			if( $this->_config->cacheEnabled )
			{
				IO\Cache::put( $cacheId, $serialized );
			}

			$this->_debug = ( $this->_config->state == AppState::debug() )?TRUE:FALSE;
			$this->_dsn = AppServlet::getInstance()->_config->dsn;
		}


		/**
		 * execute the application
		 *
		 * @param	int			$argc		Number of command line arguments
		 * @param	array		$argv		Array of command line arguments
		 *
		 * @return  void
		 */
		abstract protected function execute($argc, $argv);


		/**
		 * event triggered by an uncaught Exception thrown in the application, can be overridden to provide error handling.
		 *
		 * @param  \Exception	$e
		 *
		 * @return void
		 */
		abstract protected function handleException(\Exception $e);


		/**
		 * event triggered by an error in the application, can be overridden to provide error handling.
		 *
		 * @param  string	$errno		error code
		 * @param  string	$errstr		error description
		 * @param  string	$errfile	file
		 * @param  string	$errline	line no.
		 *
		 * @return void
		 */
		abstract protected function handleError($errno, $errstr, $errfile, $errline);


		/**
		 * event triggered when application shutsdown, can be overridden to provide error handling.
		 *
		 * @return void
		 */
		final protected function handleShutDown()
		{
			$error = error_get_last();

			if ($error['type'] == E_ERROR)
			{
				try
				{
					throw new \ErrorException($error['message'] . ' in ' . $error['file'] . ' on line ' . $error['line'], $error['type'], 0, $error['file'], $error['line']);
				}
				catch(\ErrorException $e)
				{
					$this->handleException($e);
				}
			}
		}


		/**
		 * run unit test case
		 *
		 * @param   string		$testCase		name of test
		 * @param   \SimpleReporter	$reporter	instance of a \SimpleReporter
		 * @return  void
		 */
		final protected function runUnitTestCase( $testCase, \SimpleReporter $reporter ) {
			$this->_loadTestConfig();
			$this->_getUnitTestCase( $testCase )->run( $reporter );
		}


		/**
		 * run functional test case
		 *
		 * @param   string		$testCase		name of module
		 * @param   \SimpleReporter	$reporter	instance of a \SimpleReporter
		 * @return  void
		 */
		final protected function runFunctionalTestCase( $testCase, \SimpleReporter $reporter ) {
			$this->_loadTestConfig();
			$this->_getFunctionalTestCase( $testCase )->run( $reporter );
		}


		/**
		 * run all test cases
		 *
		 * @param   \SimpleReporter	$reporter	instance of a \SimpleReporter
		 * @return  void
		 */
		final protected function runAllTestCases(\SimpleReporter $reporter) {
			$this->_loadTestConfig();

			require_once __LIB_PATH__ . '/simpletest/test_case.php';

			//$timer = new \System\Utils\Timer(true);
			$tests = new \TestSuite( $this->_applicationId . '_TestSuite' );

			foreach( $this->_getAllUnitTestCases() as $testCase ) {
				$tests->addTestCase( $this->_getUnitTestCase( $testCase ));
			}

			foreach( $this->_getAllFunctionalTestCases() as $testCase ) {
				$tests->addTestCase( $this->_getFunctionalTestCase( $testCase ));
			}

			$tests->run($reporter);
		}


		/**
		 * run helper commands
		 *
		 * @param   array		$argc		argmuent count
		 * @param   array		$argv		array of argmuents
		 * @return  void
		 */
		private function _handleCommandLineArgs($argc, $argv)
		{
			if($argc > 1)
			{
				if($argv[1]=="flush_cache")
				{
					IO\Cache::flush();
					print("Cache has been flushed");
				}
				elseif($argv[1]=="run_all")
				{
					$this->runAllTestCases($this->_getTestCaseReporter());
					exit;
				}
				elseif($argv[1]=="run_unit_test")
				{
					if(isset($argv[2]))
					{
						$this->runUnitTestCase($argv[2], $this->_getTestCaseReporter());
						exit;
					}
					else
					{
						print("You must specify the unit testcase parameter");
					}
				}
				elseif($argv[1]=="run_functional_test")
				{
					if(isset($argv[2]))
					{
						$this->runFunctionalTestCase($argv[2], $this->_getTestCaseReporter());
						exit;
					}
					else
					{
						print("You must specify the controller testcase parameter");
					}
				}
			}
		}


		/**
		 * return unit test case
		 *
		 * @param   string		$testCase		name of test
		 * @return  UnitTestCaseBase
		 */
		private function _getUnitTestCase( $testCase )
		{
			restore_error_handler();
			error_reporting( E_ALL );

			$testPath = $this->_config->unittests . '/' . $testCase . strtolower( __TESTCASE_SUFFIX__ ) . __CLASS_EXTENSION__;
			$testCaseClass = $this->_namespace . '\\' . ucwords( $testCase ) . __TESTCASE_SUFFIX__;

			if( include_once $testPath )
			{
				if( class_exists( $testCaseClass ))
				{
					return new $testCaseClass( $testCase );
				}
				else
				{
					throw new InvalidOperationException( "class `$testCaseClass` does not exist" );
				}
			}
			else
			{
				throw new IO\FileNotFoundException( "file `$testPath` does not exist" );
			}
		}


		/**
		 * return functional test case
		 *
		 * @param   string		$module		name of module
		 * @return  ControllerTestCaseBase
		 */
		private function _getFunctionalTestCase( $module )
		{
			restore_error_handler();
			error_reporting( E_ALL );

			$controller = str_replace( '-', '_', $module );
			$controllerIncludePath = $this->_config->controllers . '/' . strtolower( $controller ) . __CONTROLLER_EXTENSION__;

			$testPath = $this->_config->functionaltests . '/' . strtolower( $module ) . strtolower( __CONTROLLER_TESTCASE_SUFFIX__ ) . __CLASS_EXTENSION__;
			$testCaseClass = $this->_namespace . "\\" . ucwords( str_replace('/', '\\', $module )) . __CONTROLLER_TESTCASE_SUFFIX__;

			if( !defined( INCLUDEPREFIX . $controllerIncludePath ))
			{
				define( INCLUDEPREFIX . $controllerIncludePath, true );

				if( !include_once( $controllerIncludePath ))
				{
					IO\FileNotFoundException( "file `$controllerIncludePath` does not exist" );
				}
			}

			if( !defined( INCLUDEPREFIX . $testPath ))
			{
				define( INCLUDEPREFIX . $testPath, true );

				if( !include_once( $testPath ))
				{
					IO\FileNotFoundException( "file `$testPath` does not exist" );
				}
			}

			if( class_exists( $testCaseClass ))
			{
				return new $testCaseClass( $controller );
			}
			else
			{
				throw new InvalidOperationException( "class `$testCaseClass` does not exist, make sure you specify the correct namespace" );
			}
		}


		/**
		 * return all unit test cases
		 *
		 * @return  array					array of test modules
		 */
		private function _getAllUnitTestCases() {

			$modules = array();
			$dir = dir( $this->_config->unittests );

			while( false !== ( $file = $dir->read() )) {
				if( stripos( $file, '.php' ) === strlen($file) - 4 ) {
					$modules[] = preg_replace( '^' . strtolower( __TESTCASE_SUFFIX__ . __CLASS_EXTENSION__ ) . '$^', '\\1', $file );
				}
			}

			$dir->close();
			return $modules;
		}


		/**
		 * return all functional test cases
		 *
		 * @param   string		$path		initial path
		 * @return  array					array of test modules
		 */
		private function _getAllFunctionalTestCases( $path = '' ) {

			if( !$path ) $path = $this->_config->functionaltests;

			$modules = array();
			$dir = dir( $path );

			while( false !== ( $file = $dir->read() )) {
				if( $file != '.' && $file != '..' ) {
					if( is_dir( $path . '/' . $file )) {
						$modules = array_merge( $modules, $this->_getAllFunctionalTestCases( $path . '/' . $file ));
					}
					else {
						if( stripos( $file, '.php' ) === strlen($file) - 4 ) {
							$module = str_replace( $this->_config->functionaltests . '/', '', $path . '/' . $file );
							$module = preg_replace( '^' . '(.*)$^', '\\1', $module );
							$module = preg_replace( '^' . strtolower( __CONTROLLER_TESTCASE_SUFFIX__ . __CLASS_EXTENSION__ ) . '$^', '\\1', $module );
							$modules[] = $module;
						}
					}
				}
			}

			$dir->close();
			return $modules;
		}


		/**
		 * return test reporter
		 *
		 * @return  TestReporter
		 */
		private function _getTestCaseReporter() {
			require_once __SYSTEM_PATH__ . '/testcase/testreporter' . __CLASS_EXTENSION__;
			return new \System\Testcase\TestReporter();
		}


		/**
		 * run all test cases
		 *
		 * @param   \SimpleReporter	$reporter	instance of a \SimpleReporter
		 * @return  void
		 */
		private function _loadTestConfig() {
			$this->_config = new Configuration\AppConfiguration();
			$this->_dataAdapter = null;

			// load global app configuration
			if(file_exists(__CONFIG_PATH__ . __APP_CONF_FILENAME__)) {
				$this->loadAppConfig( __CONFIG_PATH__ . __APP_CONF_FILENAME__ );
			}

			// load test env app configuration
			if(file_exists(__ENV_PATH__ . '/' . __TEST_ENV__ . __APP_CONF_FILENAME__)) {
				$this->loadAppConfig( __ENV_PATH__ . '/' . __TEST_ENV__ . __APP_CONF_FILENAME__ );
			}
		}


		/**
		 * this method will open a connection to the database.  an error is thrown if no connection
		 * can be established.
		 *
		 * @return  DataAdapter
		 */
		private function & _getDataAdapter()
		{
			if( !$this->_dataAdapter )
			{
				// create _dataAdapter
				$this->_dataAdapter = \System\Data\DataAdapter::create( $this->_dsn );
			}

			return $this->_dataAdapter;
		}
	}
?>