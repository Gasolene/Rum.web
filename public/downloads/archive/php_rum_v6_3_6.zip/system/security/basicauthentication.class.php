<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Security;


	/**
	 * Provides application wide authentication using Basic HTTP Headers
	 *
	 * @package			PHPRum
	 * @subpackage		Security
	 * @author			Darnell Shinbine
	 */
	class BasicAuthentication extends Authentication
	{
		/**
		 * returns true if user authenticated
		 *
		 * @return  mixed
		 */
		public static function authenticated()
		{
			if( Authentication::method() === 'basic' )
			{
				if( BasicAuthentication::isAuthUserSet() )
				{
					if( Authentication::authenticate( $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'] ))
					{
						Authentication::$identity = BasicAuthentication::getAuthUser();
						return true;
					}
				}
			}
			return false;
		}


		/**
		 * send auth http headers
		 * 
		 * @return  void
		 */
		public static function sendAuthHeaders()
		{
			\System\IO\HTTPResponse::addHeader('WWW-Authenticate: Basic realm="' . \System\AppServlet::getInstance()->config->authenticationBasicRealm . '"');
			\System\HTTPAppServlet::getInstance()->sendHTTPError( 401 );
		}


		/**
		 * gets auth user
		 * 
		 * @return  string
		 */
		public static function getAuthUser()
		{
			if( isset( $_SERVER['PHP_AUTH_USER'] ))
			{
				return $_SERVER['PHP_AUTH_USER'];
			}
			else
			{
				throw new \System\InvalidOperationException("Auth user not set, call BasicAuthentication::isAuthUserSet()");
			}
		}


		/**
		 * returns true if auth is set
		 * 
		 * @return  bool
		 */
		public static function isAuthUserSet()
		{
			return ( isset( $_SERVER['PHP_AUTH_USER'] ) && isset( $_SERVER['PHP_AUTH_PW'] ));
		}


		/**
		 * perform sign out
		 *
		 * @return  void
		 */
		public static function signout()
		{
			\System\HTTPAppServlet::getInstance()->session->destroy();
		}
	}
?>