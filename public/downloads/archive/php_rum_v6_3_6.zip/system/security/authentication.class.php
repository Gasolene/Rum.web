<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Security;


	/**
	 * Provides application wide authentication
	 *
	 * @package			PHPRum
	 * @subpackage		Security
	 * @author			Darnell Shinbine
	 */
	abstract class Authentication
	{
		/**
		 * authenticated id
		 * @var string
		 */
		static public $identity;


		/**
		 * authenticate user/password based on credentials (does not set cookie)
		 *
		 * @param   string	$username	specifies username
		 * @param   string	$password	specifies password
		 * @return  bool 				returns true if valid username and password
		 */
		public static function authenticate( $username, $password ) {
			// Check IP Address
			if( Authentication::_checkIPAddress() ) {

				// Authenticate using credentials users
				if( isset( \System\AppServlet::getInstance()->config->authenticationCredentialsUsers[strtolower((string)$username)] )) {
					if( Authentication::validatePassword( (string) \System\AppServlet::getInstance()->config->authenticationCredentialsUsers[strtolower((string)$username)], (string)$password )) {
						return true;
					}
				}
				// Authenticate using credentials tables
				foreach( \System\AppServlet::getInstance()->config->authenticationCredentialsTables as $table ) {
					$da = null;
					if( isset( $table['dsn'] )) {
						$da = \System\Data\DataAdapter::create( $table['dsn'] );
					}
					else {
						$da = \System\AppServlet::getInstance()->dataAdapter;
					}

					if(!is_null($da))
					{
						$ds = $da->openDataSet( $table['source'] );
						if( $ds ) {
							if( $ds->seek( $table['username-field'], (string)$username, true )) {
								if( Authentication::validatePassword( $ds[$table['password-field']], (string) $password )) {
									return true;
								}
							}
						}
					}
					else
					{
						throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
					}
				}
			}
			return false;
		}


		/**
		 * authenticate user based on credentials (does not set cookie)
		 *
		 * @param   string	$username	specifies username
		 * @return  bool 				returns true if valid username
		 */
		public static function authenticateUser( $username )
		{
			// Check IP Address
			if( Authentication::_checkIPAddress() )
			{
				// Authenticate using credentials users
				if( isset( \System\AppServlet::getInstance()->config->authenticationCredentialsUsers[strtolower((string)$username)] ))
				{
					return true;
				}
				// Authenticate using credentials tables
				foreach( \System\AppServlet::getInstance()->config->authenticationCredentialsTables as $table )
				{
					$da = null;
					if( isset( $table['dsn'] ))
					{
						$da = \System\Data\DataAdapter::create( $table['dsn'] );
					}
					else
					{
						$da = \System\AppServlet::getInstance()->dataAdapter;
					}

					if(!is_null($da))
					{
						$ds = null;
						if( stripos($table['source'], 'select') === false && $da instanceof \System\Data\SQLDataAdapter )
						{
							$query = new \System\Data\QueryBuilder();
							$query->select($table['source'], $table['username-field']);
							$query->from($table['source']);
							$query->where($table['source'], $table['username-field'], '=', (string) $username);

							$ds = $da->openDataSet( $query );
						}
						else
						{
							$ds = $da->openDataSet( $table['source'] );
						}

						if( $ds->seek( $table['username-field'], (string) $username, true ))
						{
							return true;
						}
					}
					else
					{
						throw new \System\InvalidOperationException("AppServlet::dataAdapter is null");
					}
				}
			}
			return false;
		}


		/**
		 * generates a hash based on the password format
		 *
		 * @param   string	$passwordToEncrypt		password to encrypt
		 * @return  string
		 */
		public static function getHash( $passwordToEncrypt )
		{
			if( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'md5' )
			{
				return md5( (string) $passwordToEncrypt . Authentication::_getSalt( $passwordToEncrypt ));
			}
			elseif( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'sha1' )
			{
				return sha1( (string) $passwordToEncrypt . Authentication::_getSalt( $passwordToEncrypt ));
			}
			elseif( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'crypt' )
			{
				return crypt( (string) $passwordToEncrypt, Authentication::_getSalt( $passwordToEncrypt ));
			}
			else
			{
				return $passwordToEncrypt;
			}
		}


		/**
		 * return identity
		 *
		 * @return  string 				returns identity
		 */
		public static function getIdentity()
		{
			return Authentication::$identity;
		}


		/**
		 * returns authentication method
		 *
		 * @return  string
		 */
		public static function method() {
			return strtolower( \System\AppServlet::getInstance()->config->authenticationMethod );
		}


		/**
		 * returns true if controller is protected (requires authenctication to process)
		 *
		 * @param   string		id of controller
		 * @return  bool
		 */
		public static function isProtected( $controllerId ) {

			// If page === loginpage && authMethod === forms
		   	if( strtolower( $controllerId ) === strtolower( \System\AppServlet::getInstance()->config->authenticationFormsLoginPage ) &&
		   		\System\AppServlet::getInstance()->config->authenticationMethod === 'forms' ) {
		   		return false;
		   	}

			$deny  = explode( ',', strtolower( \System\AppServlet::getInstance()->config->authenticationDeny ));
			$allow = explode( ',', strtolower( \System\AppServlet::getInstance()->config->authenticationAllow ));

			for($i = 0; $i < count($deny); $i++ )
			{
				$deny[$i] = trim($deny[$i]);
			}

			for($i = 0; $i < count($allow); $i++ )
			{
				$allow[$i] = trim($allow[$i]);
			}

			// If deny list does not contain 'all|*' and
			// deny list does not contain page
			if( !in_array( 'all', $deny ) &&
				!in_array( '*', $deny ) &&
				!in_array( strtolower( $controllerId ), $deny )) {
				return false;
			}

			// If allow list contains 'all|*' or
			// allow list contains page
			if( in_array( 'all', $allow ) ||
				in_array( '*', $allow ) ||
				in_array( strtolower( $controllerId ), $allow )) {
				return false;
			}

			// If page is error page
			foreach( \System\AppServlet::getInstance()->config->errors as $err => $page ) {
				if( strtolower( $page ) === strtolower( $controllerId )) {
					return false;
				}
			}

			return true;
		}


		/**
		 * validate password based on password format
		 *
		 * @param   string	$encryptedPassword		encrypted password
		 * @param   string	$passwordToCompare		password to compare
		 * @return  bool
		 */
		protected static function validatePassword( $encryptedPassword, $passwordToCompare )
		{
			if( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'md5' )
			{
				return( (string) $encryptedPassword === md5( (string) $passwordToCompare . Authentication::_getSalt( $passwordToCompare )));
			}
			elseif( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'sha1' )
			{
				return( (string) $encryptedPassword === sha1( (string) $passwordToCompare . Authentication::_getSalt( $passwordToCompare )));
			}
			elseif( \System\AppServlet::getInstance()->config->authenticationPasswordFormat === 'crypt' )
			{
				return( (string) $encryptedPassword === crypt( (string) $passwordToCompare, Authentication::_getSalt( $passwordToCompare )));
			}
			else
			{
				return( (string) $encryptedPassword === (string) $passwordToCompare );
			}
		}


		/**
		 * returns true if remote client IP address is valid
		 *
		 * @return  bool
		 */
		private static function _checkIPAddress()
		{
			$ip_array = explode(',', \System\AppServlet::getInstance()->config->authenticationRestrict);

			if( count( $ip_array ) > 0 && !empty( $ip_array[0] ))
			{
				foreach( $ip_array as $ip_address )
				{
					if( strpos( $_SERVER["REMOTE_ADDR"], trim( $ip_address )) === 0 )
					{
						return true;
					}
				}

				return false;
			}

			return true;
		}


		/**
		 * returns the salt for password encryption
		 *
		 * @param   string	$passwordToSalt		password to salt
		 * @return  string
		 */
		private static function _getSalt( $passwordToSalt )
		{
			if( strlen( \System\AppServlet::getInstance()->config->authenticationPasswordSalt ) > 0 )
			{
				//return $passwordToSalt . \System\AppServlet::getInstance()->config->authenticationPasswordSalt;
				return \System\AppServlet::getInstance()->config->authenticationPasswordSalt;
			}
			else
			{
				return '';
			}
		}
	}
?>