<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Security;


	/**
	 * Provides application wide authentication using Forms
	 *
	 * @package			PHPRum
	 * @subpackage		Security
	 * @author			Darnell Shinbine
	 */
	class FormsAuthentication extends Authentication
	{
		/**
		 * returns true if user authenticated
		 *
		 * @return  bool
		 */
		public static function authenticated()
		{
			if( Authentication::method() === 'forms' )
			{
				if( FormsAuthentication::isAuthCookieSet() )
				{
					if( Authentication::authenticateUser( FormsAuthentication::getAuthCookie() ))
					{
						Authentication::$identity = FormsAuthentication::getAuthCookie();
						return true;
					}
				}
			}
			return false;
		}


		/**
		 * sets auth cookie and redirects to original requested resource
		 *
		 * @param   string	$uid		unique value representing user
		 * @param   string	$permanent	specifies whether cookie is permanent
		 * @return  void
		 */
		public static function redirectFromLoginPage( $uid, $permanent = false )
		{
			FormsAuthentication::setAuthCookie( $uid, $permanent );
			\System\AppServlet::getInstance()->session->write();

			if( isset( \System\IO\HTTPRequest::$request['returnUrl'] ))
			{
				\System\IO\HTTPResponse::redirect( \System\IO\HTTPRequest::$request['returnUrl'] );
			}
			else
			{
				\System\IO\HTTPResponse::redirect( \System\HTTPAppServlet::getInstance()->getPageURI( \System\AppServlet::getInstance()->config->defaultController ));
			}
		}


		/**
		 * redirects to login page
		 *
		 * @return  void
		 */
		public static function redirectToLoginPage()
		{
			\System\IO\HTTPResponse::redirect( \System\HTTPAppServlet::getInstance()->getPageURI( \System\AppServlet::getInstance()->config->authenticationFormsLoginPage, array( 'returnUrl' => $_SERVER["REQUEST_URI"] )));
		}


		/**
		 * sets auth cookie
		 *
		 * @param   string	$uid		unique value representing user
		 * @param   string	$permanent	specifies whether cookie is permanent
		 * @return  void
		 */
		public static function setAuthCookie( $uid, $permanent = false )
		{
			if( $permanent )
			{
				// set cookie for 1 year
				\System\IO\HTTPResponse::setCookie(\System\AppServlet::getInstance()->config->authenticationCookieName, $uid, time() + 31536000, \System\AppServlet::getInstance()->config->uri );
			}
			else
			{
				// set session cookie
				$session = \System\AppServlet::getInstance()->session;
				$session[\System\AppServlet::getInstance()->config->authenticationCookieName] = $uid;
			}
		}


		/**
		 * gets auth cookie
		 *
		 * @return  string
		 */
		public static function getAuthCookie()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName];
			}
			elseif( isset( $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName];
			}
			else
			{
				throw new \System\InvalidOperationException("Auth cookie does not exist, call FormsAuthentication::isAuthCookieSet()");
			}
		}


		/**
		 * returns true if auth cookie is set
		 *
		 * @return  bool
		 */
		public static function isAuthCookieSet()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return true;
			}
			elseif( isset( $_COOKIE[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/**
		 * perform sign out (does not end session)
		 *
		 * @return  void
		 */
		public static function signout()
		{
			if( isset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] ))
			{
				unset( \System\AppServlet::getInstance()->session[\System\AppServlet::getInstance()->config->authenticationCookieName] );
			}

			setcookie(\System\AppServlet::getInstance()->config->authenticationCookieName, '', time()-1000, \System\AppServlet::getInstance()->config->uri );

			\System\AppServlet::getInstance()->setForwardPage();
		}
	}
?>