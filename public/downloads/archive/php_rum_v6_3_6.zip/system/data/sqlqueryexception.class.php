<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;
	use \System\ExceptionBase;


	/**
	 * Represents an SQL Query Exception
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class SQLQueryException extends ExceptionBase {}
?>