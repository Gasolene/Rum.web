<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents an SQL Query
	 *
	 * @property bool $empty specifies whether to return empty result set
	 *
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class QueryBuilder {

		/**
		 * statement
		 * @var string
		**/
		private $_statement			= '';

		/**
		 * array of select columns
		 * @var array
		**/
		private $_columns			= array();

		/**
		 * array of values
		 * @var array
		**/
		private $_values			= array();

		/**
		 * name of table
		 * @var array
		**/
		private $_tables			= array();

		/**
		 * array of join tables
		 * @var array
		**/
		private $_joins				= array();

		/**
		 * array of where clauses
		 * @var array
		**/
		private $_whereClauses		= array();

		/**
		 * array of order by clauses
		 * @var array
		**/
		private $_orderByClauses	= array();

		/**
		 * array of having clauses
		 * @var array
		**/
		private $_havingClauses		= array();

		/**
		 * array of group by clauses
		 * @var array
		**/
		private $_groupByClauses	= array();

		/**
		 * specifies whether to return empty resultset
		 * @var bool
		**/
		private $_empty				= false;



		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'empty' ) {
				return $this->_empty;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @param  string	$field		name of the field
		 * @param  mixed	$value		value of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'empty' ) {
				$this->_empty = (bool) $value;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * impliments `select` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$column			column name
		 * @param  string		$alias			column alias
		 * @return bool
		 */
		public function select( $table = '*', $column = '*', $alias = '' ) {
			if( $this->_setStatement( 'select' )) {

				$this->_addColumn( $table, $column, $alias );
				return true;
			}
			return false;
		}


		/**
		 * impliments `insert into` statement
		 *
		 * @param  string		$table			table name
		 * @param  array		$columns		array of columns
		 * @return bool
		 */
		public function insertInto( $table, array $columns ) {
			if( $this->_setStatement( 'insert' )) {

				$this->_addTable( $table );
				foreach( $columns as $columnname ) {
					$this->_addColumn( $table, $columnname );
				}
				return true;
			}
			return false;
		}


		/**
		 * impliments `update` statement
		 *
		 * @param  string		$table			table name
		 * @return bool
		 */
		public function update( $table ) {
			if( $this->_setStatement( 'update' )) {

				$this->_addTable( $table );
				return true;
			}
			return false;
		}


		/**
		 * impliments `delete` statement
		 *
		 * @return bool
		 */
		public function delete() {
			return $this->_setStatement( 'delete' );
		}


		/**
		 * impliments `from` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$alias			table alias
		 * @return bool
		 */
		public function from( $table, $alias = '' ) {
			if( $this->_checkStatement( 'select', 'delete' )) {

				$this->_addTable( $table, $alias );
				return true;
			}
			return false;
		}


		/**
		 * impliments `values` statement
		 *
		 * @param  array		$values			array of column values
		 * @return bool
		 */
		public function values( array $values ) {
			if( $this->_checkStatement( 'insert' )) {

				foreach( $values as $value ) {
					$this->_addValue( $value );
				}
				return true;
			}
			return false;
		}


		/**
		 * impliments `set` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$column			column name
		 * @param  string		$value			column value
		 * @return bool
		 */
		public function set( $table, $column, $value ) {
			if( $this->_checkStatement( 'update' )) {

				$this->_addColumn( $table, $column );
				$this->_addValue ( $value );

				return true;
			}
			return false;
		}


		/**
		 * impliments `inner join` statement
		 *
		 * @param  string		$lefttable			left table name
		 * @param  string		$leftcolumn			left column name
		 * @param  string		$righttable			right table name
		 * @param  string		$rightcolumn		right column name
		 * @param  string		$alias				left table alias
		 * @return bool
		 */
		public function innerJoin( $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias = '' ) {
			if( $this->_checkStatement( 'select', 'delete' )) {

				$this->_addJoin( 'inner', $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias );
				return true;
			}
			return false;
		}


		/**
		 * impliments `left join` statement
		 *
		 * @param  string		$lefttable			left table name
		 * @param  string		$leftcolumn			left column name
		 * @param  string		$righttable			right table name
		 * @param  string		$rightcolumn		right column name
		 * @param  string		$alias				left table alias
		 * @return bool
		 */
		public function leftJoin( $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias = '' ) {
			if( $this->_checkStatement( 'select', 'delete' )) {

				$this->_addJoin( 'left', $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias );
				return true;
			}
			return false;
		}


		/**
		 * impliments `right join` statement
		 *
		 * @param  string		$lefttable			left table name
		 * @param  string		$leftcolumn			left column name
		 * @param  string		$righttable			right table name
		 * @param  string		$rightcolumn		right column name
		 * @param  string		$alias				left table alias
		 * @return bool
		 */
		public function rightJoin( $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias = '' ) {
			if( $this->_checkStatement( 'select', 'delete' )) {

				$this->_addJoin( 'right', $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias );
				return true;
			}
			return false;
		}


		/**
		 * impliments `where` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$column			column name
		 * @param  string		$operand		operation to perform
		 * @param  string		$value			column value
		 * @return bool
		 */
		public function where( $table, $column, $operand, $value ) {
			if( $this->_checkStatement( 'select', 'update', 'delete' )) {

				$this->_addWhereClause( $table, $column, $operand, $value );
				return true;
			}
			return false;
		}


		/**
		 * impliments `order by` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$column			column name
		 * @param  string		$direction		order by direction
		 * @return bool
		 */
		public function orderBy( $table, $column, $direction = 'asc' ) {
			if( $this->_checkStatement( 'select' )) {

				$this->_addOrderByClause( $table, $column, $direction );
				return true;
			}
			return false;
		}


		/**
		 * impliments `having` statement
		 *
		 * @param  string		$column			column name
		 * @param  string		$operand		operation to perform
		 * @param  string		$value			column value
		 * @return bool
		 */
		public function having( $column, $operand, $value ) {
			if( $this->_checkStatement( 'select', 'update', 'delete' )) {

				$this->_addHavingClause( $column, $operand, $value );
				return true;
			}
			return false;
		}


		/**
		 * impliments `group by` statement
		 *
		 * @param  string		$table			table name
		 * @param  string		$column			column name
		 * @return bool
		 */
		public function groupBy( $table, $column ) {
			if( $this->_checkStatement( 'select' )) {

				$this->_addGroupByClause( $table, $column );
				return true;
			}
			return false;
		}


		/**
		 * returns statement as a string
		 *
		 * @return string
		 */
		public function getStatement() {
			return $this->_statement;
		}


		/**
		 * returns columns as an array
		 *
		 * @return array
		 */
		public function getColumns() {
			return $this->_columns;
		}


		/**
		 * returns values as an array
		 *
		 * @return array
		 */
		public function getValues() {
			return $this->_values;
		}


		/**
		 * returns tables as an array
		 *
		 * @return array
		 */
		public function getTables() {
			return $this->_tables;
		}


		/**
		 * returns `join` statements as an array
		 *
		 * @return array
		 */
		public function getJoins() {
			return $this->_joins;
		}


		/**
		 * returns `where` clauses as an array
		 *
		 * @return array
		 */
		public function getWhereClauses() {
			return $this->_whereClauses;
		}


		/**
		 * returns `order by` clauses as an array
		 *
		 * @return array
		 */
		public function getOrderByClauses() {
			return $this->_orderByClauses;
		}


		/**
		 * returns `having` clauses as an array
		 *
		 * @return array
		 */
		public function getHavingClauses() {
			return $this->_havingClauses;
		}


		/**
		 * returns `group by` clauses as an array
		 *
		 * @return array
		 */
		public function getGroupByClauses() {
			return $this->_groupByClauses;
		}


		/**
		 * check statement
		 *
		 * @return bool
		 */
		private function _checkStatement( $statement1, $statement2 = '', $statement3 = '', $statement4 = '' ) {
			if( $this->_statement ) {

				if( $this->_statement === (string) $statement1 ) {
					return true;
				}
				elseif( $this->_statement === (string) $statement2 ) {
					return true;
				}
				elseif( $this->_statement === (string) $statement3 ) {
					return true;
				}
				elseif( $this->_statement === (string) $statement4 ) {
					return true;
				}
			}

			throw new SQLQueryException("unexpected clause in `{$this->_statement}` statement");
		}


		/**
		 * set statement
		 *
		 * @return bool
		 */
		private function _setStatement( $statement ) {
			if( !$this->_statement || $this->_statement === (string) $statement ) {
				$this->_statement = (string) $statement;
				return true;
			}

			throw new SQLQueryException( 'unexpected statement `' . (string) $statement . '` on `' . $this->_statement . '` statement' );
		}


		/**
		 * add column
		 *
		 * @return void
		 */
		private function _addColumn( $table = '*', $column = '*', $alias = '' ) {
			$this->_columns[] = array(
				  'table'  => (string) $table
				, 'column' => (string) $column
				, 'alias'  => $alias?(string)$alias:(string)$column );
		}


		/**
		 * add value
		 *
		 * @return void
		 */
		private function _addValue( $value ) {
			$this->_values[] = $value;
		}


		/**
		 * add table
		 *
		 * @return void
		 */
		private function _addTable( $table, $alias = '' ) {
			$this->_tables[] = array( 
				  'table' => (string) $table
				, 'alias' => $alias?(string)$alias:(string)$table );
		}


		/**
		 * add join
		 *
		 * @return void
		 */
		private function _addJoin( $type, $lefttable, $leftcolumn, $righttable, $rightcolumn, $alias = '' ) {
			$this->_joins[] = array(
				  'type'		=> (string) $type
				, 'lefttable'   => (string) $lefttable
				, 'leftcolumn'  => (string) $leftcolumn
				, 'righttable'  => (string) $righttable
				, 'rightcolumn' => (string) $rightcolumn
				, 'alias'	   => $alias?(string)$alias:(string)$lefttable );
		}


		/**
		 * add where clause
		 *
		 * @return void
		 */
		private function _addWhereClause( $table, $column, $operand, $value ) {
			$this->_whereClauses[] = array(
				  'table'   => (string) $table
				, 'column'  => (string) $column
				, 'operand' => (string) $operand
				, 'value'   => $value );
		}


		/**
		 * add order by clause
		 *
		 * @return void
		 */
		private function _addOrderByClause( $table, $column, $direction = 'asc' ) {
			$this->_orderByClauses[] = array(
				  'table'	 => (string) $table
				, 'column'	=> (string) $column
				, 'direction' => (string) $direction=='desc'?'desc':'asc' );
		}


		/**
		 * add having clause
		 *
		 * @return void
		 */
		private function _addHavingClause( $column, $operand, $value ) {
			$this->_havingClauses[] = array(
				  'column'  => (string) $column
				, 'operand' => (string) $operand
				, 'value'   => $value );
		}


		/**
		 * add group by clause
		 *
		 * @return void
		 */
		private function _addGroupByClause( $table, $column ) {
			$this->_groupByClauses[] = array(
				  'table'	 => (string) $table
				, 'column'	=> (string) $column );
		}
	}
?>