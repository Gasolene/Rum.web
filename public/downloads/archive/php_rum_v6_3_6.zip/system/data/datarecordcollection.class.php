<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of DataRecord objects
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class DataRecordCollection extends CollectionBase
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof DataRecord )
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of type DataRecord in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}

		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetUnset($index)
		{
			if( array_key_exists( $index, $this->items ))
			{
				unset( $this->items[$index] );
				$this->items = array_values( $this->items );
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add DataRecord to Collection
		 *
		 * @param  DataRecord	$item
		 * @return void
		 */
		public function add( $item )
		{
			if( $item instanceof DataRecord )
			{
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of type DataRecord");
			}
		}


		/**
		 * return DataRecord at a specified index
		 *
		 * @param  int		$index			index of ActiveRecord
		 * @return DataRecord			   DataRecord
		 */
		public function itemAt( $index )
		{
			return parent::itemAt($index);
		}


		/**
		 * remove item from array at a specified index
		 *
		 * @param  int		$index		index to remove at
		 * @return void
		 */
		public function removeAt( $index )
		{
			if( isset( $this->items[(int)$index] ))
			{
				unset( $this->items[(int)$index] );
				$this->items = array_values( $this->items );
			}
			else
			{
				throw new \System\ArgumentOutOfRangeException("Argument out of range in ".get_class($this)."::removeAt()");
			}
		}
	}
?>