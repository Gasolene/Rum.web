<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Provides array comparing by type
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class ColumnCompare
	{
		/**
		 * index to compare
		 */
		private $_index;


		/**
		 * Constructor
		 *
		 * sets column name to compare
		 *
		 * @param  string	$field		column name
		 * @return void
		 */
		public function __construct( $index ) {
			$this->_index = $index;
		}

		/**
		 * method compares strings and returns -1, 0, 1
		 *
		 * @param  string	$a			string a
		 * @param  string	$b			string b
		 * @return int					compare result
		 */
		public function compareStringi($a, $b)
		{
			if( isset( $a[$this->_index] ) && isset( $b[$this->_index] )) {
				return strcmp( strtolower($a[$this->_index]), strtolower($b[$this->_index]) );
			}
			else return 0;
		}

		/**
		 * method compares strings and returns -1, 0, 1
		 *
		 * @param  string	$a			string a
		 * @param  string	$b			string b
		 * @return int					compare result
		 */
		public function compareString($a, $b)
		{
			if( isset( $a[$this->_index] ) && isset( $b[$this->_index] )) {
				return strcmp( $a[$this->_index], $b[$this->_index] );
			}
			else return 0;
		}

		/**
		 * method compares ints and returns -1, 0, 1
		 *
		 * @param  ints		$a			ints a
		 * @param  ints		$b			ints b
		 * @return int					compare result
		 */
		public function compareDateString($a, $b)  
		{
			if( isset( $a[$this->_index] ) && isset( $b[$this->_index] ))
			{
				$n1 = (int) strtotime( $a[$this->_index] );
				$n2 = (int) strtotime( $b[$this->_index] );

				if ($n1 === $n2) return 0;
				else return ($n1 < $n2) ? -1 : 1;
			}
			else
			{
				if (isset( $a[$this->_index] ))
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}

		/**
		 * method compares numbers and returns -1, 0, 1
		 *
		 * @param  ints		$a			ints a
		 * @param  ints		$b			ints b
		 * @return int					compare result
		 */
		public function compareNumeric($a, $b)  
		{
			if( isset( $a[$this->_index] ) && isset( $b[$this->_index] )) {

				$n1 = (real)$a[$this->_index];
				$n2 = (real)$b[$this->_index];

				if ($n1 === $n2) return 0;
				else return ($n1 < $n2) ? -1 : 1;
			}
			else return 0;
		}

		/**
		 * method compares ints and returns -1, 0, 1
		 *
		 * @param  ints		$a			ints a
		 * @param  ints		$b			ints b
		 * @return int					compare result
		 */
		public function compareInt($a, $b)  
		{
			if( isset( $a[$this->_index] ) && isset( $b[$this->_index] )) {
				$n1 = (int)$a[$this->_index];
				$n2 = (int)$b[$this->_index];

				if ($n1 === $n2) return 0;
				else return ($n1 < $n2) ? -1 : 1;
			}
			else return 0;
		}
	}
?>