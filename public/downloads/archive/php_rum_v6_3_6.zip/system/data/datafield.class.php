<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents a Field in a DataSet
	 *
	 * @property string $name name of field
	 * @property string $table name of table
	 * @property string $type type of field
	 * @property int $length length of field
	 * @property bool $string specified whether field is a string
	 * @property bool $integer specified whether field is an integer
	 * @property bool $real specified whether field is a real
	 * @property bool $boolean specifies whether field is a boolean
	 * @property bool $year specified whether field is a year
	 * @property bool $date specified whether field is a date
	 * @property bool $time specified whether field is a time
  	 * @property bool $datetime specifies whether field is a datetime
	 * @property bool $blob specifies whether field is a blob
	 * @property bool $numeric specifies whether field is a numeric field
	 * @property bool $notNull specifies whether field can be null
	 * @property bool $primaryKey specifies whether field is a primary key
	 * @property bool $unique specifies whether field is unique
	 * @property bool $binary specifies whether field is binary
	 * @property bool $autoIncrement specifies whether field flag is auto_increment
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class DataField
	{
		/**
		 * name of field
		 * @var string
		 */
		private $name				= '';

		/**
		 * name of table
		 * @var string
		 */
		private $table				= '';

		/**
		 * type of field
		 * @var string
		 */
		private $type				= '';

		/**
		 * length of field
		 * @var int
		 */
		private $length				= 0;

		/**
		 * specifies whether field is a string
		 * @var bool
		 */
		private $string				= false;

		/**
		 * specifies whether field is an integer
		 * @var bool
		 */
		private $integer			= false;

		/**
		 * specifies whether field is a real number
		 * @var bool
		 */
		private $real				= false;

		/**
		 * specifies whether field is true/false
		 * @var bool
		 */
		private $boolean			= false;

		/**
		 * specifies whether field is year string
		 * @var bool
		 */
		private $year				= false;

		/**
		 * specifies whether field is date string
		 * @var bool
		 */
		private $date				= false;

		/**
		 * specifies whether field is time string
		 * @var bool
		 */
		private $time				= false;

		/**
		 * specifies whether field is date/time string
		 * @var bool
		 */
		private $datetime			= false;

		/**
		 * specifies whether field is multiline
		 * @var bool
		 */
		private $blob				= false;

		/**
		 * specifies whether field is numeric
		 * @var bool
		 */
		private $numeric			= false;

		/**
		 * specifies whether field is not null
		 * @var bool
		 */
		private $notNull			= false;

		/**
		 * specifies whether field is primary key
		 * @var bool
		 */
		private $primaryKey			= false;

		/**
		 * specifies whether field is unique
		 * @var bool
		 */
		private $unique				= false;

		/**
		 * specifies whether field is binary
		 * @var bool
		 */
		private $binary				= false;

		/**
		 * specifies whether field is auto incrementing
		 * @var bool
		 */
		private $autoIncrement		= false;


		/**
		 * returns an object property
		 *
		 * @param  string	$field		name of the field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __get( $field ) {

			if( $field === 'name' ) {
				return $this->name;
			}
			elseif( $field === 'table' ) {
				return $this->table;
			}
			elseif( $field === 'type' ) {
				return $this->type;
			}
			elseif( $field === 'length' ) {
				return $this->length;
			}
			elseif( $field === 'string' ) {
				return $this->string;
			}
			elseif( $field === 'integer' ) {
				return $this->integer;
			}
			elseif( $field === 'real' ) {
				return $this->real;
			}
			elseif( $field === 'boolean' ) {
				return $this->boolean;
			}
			elseif( $field === 'year' ) {
				return $this->year;
			}
			elseif( $field === 'date' ) {
				return $this->date;
			}
			elseif( $field === 'time' ) {
				return $this->time;
			}
			elseif( $field === 'datetime' ) {
				return $this->datetime;
			}
			elseif( $field === 'blob' ) {
				return $this->blob;
			}
			elseif( $field === 'numeric' ) {
				return $this->numeric;
			}
			elseif( $field === 'notNull' ) {
				return $this->notNull;
			}
			elseif( $field === 'primaryKey' ) {
				return $this->primaryKey;
			}
			elseif( $field === 'unique' ) {
				return $this->unique;
			}
			elseif( $field === 'binary' ) {
				return $this->binary;
			}
			elseif( $field === 'autoIncrement' ) {
				return $this->autoIncrement;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * sets an object property
		 *
		 * @param  string	$field		name of the field
		 * @param  mixed	$value		value of field
		 * @return bool					true on success
		 * @ignore
		 */
		public function __set( $field, $value ) {

			if( $field === 'name' ) {
				$this->name = (string) $value;
			}
			elseif( $field === 'table' ) {
				$this->table = (string)$value;
			}
			elseif( $field === 'type' ) {
				$this->type = (string) $value;
			}
			elseif( $field === 'length' ) {
				$this->length = (real) $value;
			}
			elseif( $field === 'string' ) {
				$this->string = (bool) $value;
			}
			elseif( $field === 'integer' ) {
				$this->integer = (bool) $value;
			}
			elseif( $field === 'real' ) {
				$this->real = (bool) $value;
			}
			elseif( $field === 'boolean' ) {
				$this->boolean = (bool) $value;
			}
			elseif( $field === 'year' ) {
				$this->year = (bool) $value;
			}
			elseif( $field === 'date' ) {
				$this->date = (bool) $value;
			}
			elseif( $field === 'time' ) {
				$this->time = (bool) $value;
			}
			elseif( $field === 'datetime' ) {
				$this->datetime = (bool) $value;
			}
			elseif( $field === 'blob' ) {
				$this->blob = (bool) $value;
			}
			elseif( $field === 'numeric' ) {
				$this->numeric = (bool) $value;
			}
			elseif( $field === 'notNull' ) {
				$this->notNull = (bool) $value;
			}
			elseif( $field === 'primaryKey' ) {
				$this->primaryKey = (bool) $value;
			}
			elseif( $field === 'unique' ) {
				$this->unique = (bool) $value;
			}
			elseif( $field === 'binary' ) {
				$this->binary = (bool) $value;
			}
			elseif( $field === 'autoIncrement' ) {
				$this->autoIncrement = (bool) $value;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}
	}
?>