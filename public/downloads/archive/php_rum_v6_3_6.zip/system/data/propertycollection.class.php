<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;
	use \System\Collections\StringDictionary;


	/**
	 * Represents a Collection of properties
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	final class PropertyCollection extends StringDictionary
	{
		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( is_string( $index ))
			{
				if( is_string( $item ))
				{
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected string in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("invalid index expected string in ".get_class($this));
			}
		}
	}
?>