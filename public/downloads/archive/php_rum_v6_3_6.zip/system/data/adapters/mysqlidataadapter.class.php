<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;

	/**
	 * include mysql base adapter
	 */
	include_once __SYSTEM_PATH__ . '/data/adapters/mysqldataadapter' . __CLASS_EXTENSION__;

	/**
	 * Represents an open connection to a MySQL database using the mysqli driver
	 *
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	class MySQLiDataAdapter extends MySQLDataAdapter
	{
		/**
		 * fetches DataSet from database string using source string
		 *
		 * @param  DataSet	&$ds		empty DataSet object
		 * @return void
		 */
		public function fill( DataSet &$ds )
		{
			if( $this->link )
			{
				$source = '';
				if( $ds->source instanceof QueryBuilder ) {
					$source = $this->getQuery( $ds->source );
				}
				elseif( !strstr( strtolower($ds->source), 'select' ) &&
					!strstr( strtolower($ds->source), 'describe' ) &&
					!strstr( strtolower($ds->source), 'show' )) {
					// source is table name
					$source = 'select * from `' . $ds->source . '`';
				}
				else {
					$source = $ds->source;
				}

				// establish link to db resource
				$result = $this->executeInternal( $source );
				if( $result )
				{
					// get table of mysqli types
					$mysqli_type = array();
					$mysqli_type[MYSQLI_TYPE_DECIMAL]		= 'DECIMAL';
					$mysqli_type[MYSQLI_TYPE_NEWDECIMAL]	= 'DECIMAL';
					$mysqli_type[MYSQLI_TYPE_BIT]			= 'BIT';

					$mysqli_type[MYSQLI_TYPE_TINY]			= 'TINYINT';
					$mysqli_type[MYSQLI_TYPE_SHORT]			= 'INT';
					$mysqli_type[MYSQLI_TYPE_LONG]			= 'INT';
					$mysqli_type[MYSQLI_TYPE_FLOAT]			= 'FLOAT';
					$mysqli_type[MYSQLI_TYPE_DOUBLE]		= 'DOUBLE';
					$mysqli_type[MYSQLI_TYPE_NULL]			= 'NULL';
					$mysqli_type[MYSQLI_TYPE_TIMESTAMP]		= 'TIMESTAMP';
					$mysqli_type[MYSQLI_TYPE_LONGLONG]		= 'BIGINT';
					$mysqli_type[MYSQLI_TYPE_INT24]			= 'MEDIUMINT';

					$mysqli_type[MYSQLI_TYPE_DATE]			= 'DATE';
					$mysqli_type[MYSQLI_TYPE_TIME]			= 'TIME';
					$mysqli_type[MYSQLI_TYPE_DATETIME]		= 'DATETIME';
					$mysqli_type[MYSQLI_TYPE_YEAR]			= 'YEAR';
					$mysqli_type[MYSQLI_TYPE_NEWDATE]		= 'DATE';

					$mysqli_type[MYSQLI_TYPE_ENUM]			= 'ENUM';
					$mysqli_type[MYSQLI_TYPE_SET]			= 'SET';
					$mysqli_type[MYSQLI_TYPE_TINY_BLOB]		= 'TINYBLOB';
					$mysqli_type[MYSQLI_TYPE_MEDIUM_BLOB]	= 'MEDIUMBLOB';
					$mysqli_type[MYSQLI_TYPE_LONG_BLOB]		= 'LONGBLOB';
					$mysqli_type[MYSQLI_TYPE_BLOB]			= 'BLOB';
					$mysqli_type[MYSQLI_TYPE_VAR_STRING]	= 'VARCHAR';
					$mysqli_type[MYSQLI_TYPE_STRING]		= 'CHAR';
					$mysqli_type[MYSQLI_TYPE_GEOMETRY]		= 'GEOMETRY';

					/*
					 * create field objects
					 *
					 * this code loops through fields of resultset
					 * checks is field is primary key, if so, set the primary key field name
					 * then adds all field names to an array
					 *
					 * cannot be used when resultset is emtpy (mysqli_num_fields will fail)
					 */
					$colcount = mysqli_num_fields( $result );
					$fields = array();
					for( $i=0; $i < $colcount; $i++ )
					{
						$field = new DataField();
						$fieldMeta = mysqli_fetch_field_direct( $result, $i );

						if(false === \strpos($fieldMeta->name, '.'))
						{
							// mysql field info
							$field->name          =        $fieldMeta->name;
							$field->table         =        $fieldMeta->table;
							$field->length	      =        $fieldMeta->length;
							$field->type          =        $mysqli_type[$fieldMeta->type];

							// mysql column types
							$field->string        = (bool)(( $fieldMeta->type === MYSQLI_TYPE_STRING ||
															 $fieldMeta->type === MYSQLI_TYPE_VAR_STRING ));
							$field->integer	      = (bool)(( $fieldMeta->type === MYSQLI_TYPE_BIT ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_TINY ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_SHORT ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_LONG ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_INT24 ));
							$field->real		  = (bool)(( $fieldMeta->type === MYSQLI_TYPE_DECIMAL ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_NEWDECIMAL ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_FLOAT ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_DOUBLE ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_LONGLONG ));
							$field->year		  = (bool) ( $fieldMeta->type === MYSQLI_TYPE_YEAR );
							$field->date		  = (bool) ( $fieldMeta->type === MYSQLI_TYPE_DATE );
							$field->time		  = (bool) ( $fieldMeta->type === MYSQLI_TYPE_TIME );
							$field->datetime	  = (bool)(( $fieldMeta->type === MYSQLI_TYPE_DATETIME ) ||
														   ( $fieldMeta->type === MYSQLI_TYPE_TIMESTAMP ));

							// fake type (mysql has no boolean column type)
							$field->boolean	   = (bool)(( $fieldMeta->length === 1 ) &&
														   ( $fieldMeta->type === MYSQLI_TYPE_TINY ));

							// mysql field flags
							$field->numeric	   = (bool) ( $fieldMeta->flags & MYSQLI_NUM_FLAG );
							$field->notNull	   = (bool) ( $fieldMeta->flags & MYSQLI_NOT_NULL_FLAG );
							$field->primaryKey	= (bool) ( $fieldMeta->flags & MYSQLI_PRI_KEY_FLAG );
							$field->unique		= (bool) ( $fieldMeta->flags & MYSQLI_UNIQUE_KEY_FLAG );
							// $field->multiple	  = (bool) ( $fieldMeta->flags & MYSQLI_MULTIPLE_KEY_FLAG );
							$field->blob		  = (bool) ( $fieldMeta->flags & MYSQLI_BLOB_FLAG );
							// $field->binary		= (bool) ( $fieldMeta->flags & MYSQLI_BINARY_FLAG ); // bug in lib
							$field->autoIncrement = (bool) ( $fieldMeta->flags & MYSQLI_AUTO_INCREMENT_FLAG );

							// add field to field collection
							$fields[$field->name] = $field;
						}
					}

					$fields = array_values($fields);

					// set table property
					$ds->setProperty('table', $fields[0]->table);

					// set fields
					$ds->setFields( $fields );

					/*
					 * create record objects
					 *
					 * this code loops through all rows and fields
					 * then creates the following array...
					 * DataSet[row number][field name] = value
					 */
					$rowcount = mysqli_num_rows( $result );
					$rows = array();
					for( $row=0; $row < $rowcount; $row++ )
					{
						// add row to DataSet
						$rows[] = mysqli_fetch_assoc( $result );
					}

					// set rows
					$ds->setRows( $rows );

					// cleanup
					mysqli_free_result( $result );
				}
				else {
					throw new SQLException(mysqli_error($this->link));
				}
			}
			else {
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * opens a connection to a mysql database
		 *
		 * @return bool						TRUE if successfull
		 */
		public function open() {
			if( !$this->link ) {
				if( isset( $this->args['server'] ) &&
					isset( $this->args['uid'] ) &&
					isset( $this->args['pwd'] ) &&
					isset( $this->args['database'] )) {

					$this->link = mysqli_init();

					if( mysqli_real_connect( $this->link, $this->args['server'], $this->args['uid'], $this->args['pwd'], $this->args['database'], isset( $this->args['port'] )?$this->args['port']:3306 )) {
						$err = mysqli_connect_errno();
						if( $err ) {
							throw new SQLException(mysqli_connect_error());
						}
						else {
							// set charset
							if( isset( $this->args['charset'] )) {
								\mysqli_set_charset( $this->link, $this->args['charset'] );
							}
							else {
								\mysqli_set_charset( $this->link, 'utf8' );
							}

							return true;
						}
					}
					else {
						throw new DatabaseException("could not connect to database " . mysqli_connect_error());
					}
				}
				else {
					throw new DataAdapterException("missing required connection string parameter");
				}
			}
			else {
				throw new \System\InvalidOperationException("connection already open");
			}
		}


		/**
		 * closes an open connection
		 *
		 * @return bool					true if successfull
		 */
		public function close()
		{
			if( $this->link )
			{
				if( mysqli_close( $this->link ))
				{
					$this->link = null;
					return true;
				}
				else
				{
					throw new DatabaseException("could not close mysqli connection");
				}
			}
			else
			{
				throw new \System\InvalidOperationException("connection already closed");
			}
		}


		/**
		 * Executes a sql query or procedure on the current connection
		 *
		 * @param  string		$query		sql query
		 * @return resource					mysqli resultset
		 */
		protected function executeInternal( $query )
		{
			$sql = '';
			if( $query instanceof QueryBuilder )
			{
				$sql = $this->getQuery( $query );
			}
			else
			{
				$sql = $query;
			}

			if( $this->link )
			{
				// start timer
				$timer = new \System\Utils\Timer(true);
				$this->lastQuery = $sql;
				$this->lastQueryTime = 0;

				$result = mysqli_query( $this->link, $sql, MYSQLI_STORE_RESULT );
				if( !$result )
				{
					throw new SQLException(mysqli_error($this->link));
				}

				$this->lastQueryTime = $timer->elapsed();
				$this->queryCount++;
				$this->queryTime += $this->lastQueryTime;

				return $result;
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource in not a valid link identifier");
			}
		}


		/**
		 * Executes a sql query or procedure on the current connection
		 *
		 * @param  string		$query		sql query
		 * @return void
		 */
		public function execute( $query )
		{
			$this->executeInternal( $query );
		}


		/**
		 * begin transaction
		 *
		 * @return void
		 */
		public function begin()
		{
			if( $this->link )
			{
				mysqli_autocommit( $this->link, false );
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource is not a valid link identifier");
			}
		}


		/**
		 * rollback transaction
		 *
		 * @return void
		 */
		public function rollback()
		{
			if( $this->link )
			{
				mysqli_rollback( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource is not a valid link identifier");
			}
		}


		/**
		 * commit transaction
		 *
		 * @return void
		 */
		public function commit()
		{
			if( $this->link )
			{
				mysqli_commit( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource is not a valid link identifier");
			}
		}


		/**
		 * return id of last record inserted
		 *
		 * @return int
		 */
		public function getLastInsertId()
		{
			if( $this->link )
			{
				return mysqli_insert_id( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource is not a valid link identifier");
			}
		}


		/**
		 * return affected rows
		 *
		 * @return int
		 */
		public function getAffectedRows()
		{
			if( $this->link )
			{
				return mysqli_affected_rows( $this->link );
			}
			else
			{
				throw new \System\InvalidOperationException("mysqli resource is not a valid link identifier");
			}
		}


		/**
		 * Returns escaped string
		 *
		 * @param  string		$unescaped_string   String to escape
		 * @return string							SQL query
		 */
		protected function getEscapeString( $unescaped_string )
		{
			return mysqli_real_escape_string( $this->link, $unescaped_string );
		}
	}
?>