<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Data;


	/**
	 * Represents an open connection to a tab or comma delimited text file
	 * 
	 * @package			PHPRum
	 * @subpackage		Data
	 * @author			Darnell Shinbine
	 */
	class TextDataAdapter extends DataAdapter
	{
		/**
		 * fetches DataSet from datasource string using source string
		 *
		 * @param  DataSet	&$ds			empty DataSet object
		 * @return void
		 */
		public function fill( DataSet &$ds )
		{
			if( $this->link )
			{
				/*
				 * create field objects
				 * 
				 * this code loops through fields of resultset
				 * checks is field is primary key, if so, set the primary key field name
				 * then adds all field names to an array
				 *
				 * cannot be used when resultset is emtpy (mysql_num_fields wil fail)
				 */
				rewind( $this->link );
				$row = fgetcsv( $this->link,
								filesize( $this->args['source'] ), 
								$this->args['delimiter'], 
								$this->args['enclosure']);

				$count = sizeof( $row );
				$fields = array();
				for( $i=0; $i < $count; $i++ )
				{
					$field = new DataField();
					$field->name = $row[$i];
					$field->type = 'string';
					$field->length = 65535;
					$field->table = $ds->source;
					$field->string = true;

					// add field to field array
					$fields[] = $field;
				}

				// set fields
				$ds->setFields($fields);

				/*
				 * create record objects
				 * 
				 * this code loops through all rows and fields
				 * then creates the following array...
				 * DataSet[row number][field name] = value
				 */
				$rows = array();
				while( $line = fgetcsv( $this->link, filesize( $this->args['source'] ), $this->args['delimiter'], $this->args['enclosure'] ))
				{
					$row = array();
					for($i = 0; $i < count($fields); $i++)
					{
						if( $line[$i] == "NULL" )
						{
							$row[$fields[$i]->name] = null;
						}
						else
						{
							$row[$fields[$i]->name] = $line[$i];
						}
					}

					$rows[] = $row;
				}

				// set rows
				$ds->setRows($rows);
			}
			else {
				throw new \System\InvalidOperationException("connection is closed");
			}
		}


		/**
		 * opens a connection to a text file
		 *
		 * @return bool						TRUE if successfull
		 */
		public function open() {
			if( !$this->link ) {
				if( isset( $this->args['source'] )) {

					// default delimeter
					if( isset( $this->args['format'] )) {
						if( strtolower( $this->args['format'] ) === 'tabdelimited' ) {
							$this->args['delimiter'] = "\t";
						}
						else {
							$this->args['delimiter'] =',';
						}
					}
					else {
						$this->args['delimiter'] =',';
					}

					// default enclosure
					if( !isset( $this->args['enclosure'] )) {
						$this->args['enclosure'] = '"';
					}

					if( file_exists( (string) $this->args['source'] )) {
						$this->link = fopen($this->args['source'], 'r');
						if( $this->link ) {
							return true;
						}
						else {
							throw new \System\InvalidOperationException("could not open file");
						}
					}
					else {
						throw new \System\InvalidOperationException("{$this->args['source']} is not a valid file");
					}
				}
				else {
					throw new DataAdapterException("missing required connection string parameter {$this->args['source']}");
				}
			}
			else {
				throw new \System\InvalidOperationException("connection already open");
			}
		}


		/**
		 * closes an open connection
		 *
		 * @return bool					true if successfull
		 */
		public function close() {
			if( $this->link ) {
				if( fclose($this->link)) {
					$this->link = null;
					return true;
				}
				else {
					throw new FileNotWritableException("could not close link to text file");
				}
			}
			else {
				throw new \System\InvalidOperationException("connection already closed");
			}
		}


		/**
		 * attempt to insert a record into the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		public function insertDataRecord( DataSet &$ds )
		{
			/**
			 * connection to text file
			 * Attempt to insert record into text file
			 */
			$data = $ds->getCSVString( $this->args['enclosure'], $this->args['delimiter'] ) .
					"\n" . $ds->record->getCSVString( $this->args['enclosure'], $this->args['delimiter'] );

			$fp = fopen( $this->args['source'], 'w+' );
			if( $fp )
			{
				if( fwrite( $fp, $data ))
				{
					fclose( $fp );
					return;
				}
			}
			throw new \System\InvalidOperationException("could not write to file");
		}


		/**
		 * attempt to update a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		public function updateDataRecord( DataSet &$ds )
		{
			/**
			 * connection to text file
			 * Attempt to update record in a text file
			 */
			$ds->rows[$ds->cursor] = $ds->row;
			$fp = fopen( $this->args['source'], 'w+' );
			if( $fp )
			{
				// write DataSet string
				if( fwrite( $fp, $ds->getCSVString( $this->args['enclosure'], $this->args['delimiter'] )))
				{
					fclose( $fp );
					return;
				}
			}
			throw new \System\InvalidOperationException("could not write to file");
		}


		/**
		 * attempt to delete a record in the datasource
		 *
		 * @param  DataSet	&$ds		reference to a DataSet
		 * @return void
		 */
		public function deleteDataRecord( DataSet &$ds )
		{
			/**
			 * connection to text file
			 * Attempt to delete a record in a text file
			 */

			$fp = fopen( $this->args['source'], 'w+' );
			if( $fp )
			{
				// write DataSet string
				if( fwrite( $fp, str_replace( $ds->record->getCSVString( $this->args['enclosure'], $this->args['delimiter'] ), '', $ds->getCSVString( $this->args['enclosure'], $this->args['delimiter'] ))))
				{
					fclose( $fp );
					return;
				}
			}
			throw new \System\InvalidOperationException("could not write to file");
		}
	}
?>