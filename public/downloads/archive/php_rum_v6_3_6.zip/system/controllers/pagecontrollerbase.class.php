<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Controllers;


	/**
	 * Provides base functionality for the Page Controller
	 *
	 * @property int $outputCache Output cache in seconds
	 * @property Page $page Page control
	 * @property bool $isPostBack Specifies if the request is a postback
	 *
	 * @package			PHPRum
	 * @subpackage		Controllers
	 * @author			Darnell Shinbine
	 */
	class PageControllerBase extends ControllerBase
	{
		/**
		 * instance of a Page component
		 * @var Page
		 */
		protected $page					= null;

		/**
		 * specifies the theme for this page
		 * @var string
		 */
		protected $theme				= '';

		/**
		 * specifies if the request is a postback
		 * @var bool
		 */
		private $isPostBack				= false;

		/**
		 * specifies if the request is an ajax postback
		 * @var bool
		 */
		private $isAjaxPostBack			= false;


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		final public function __get( $field )
		{
			if( $field === 'controllerId' )
			{
				return (string)$this->controllerId;
			}
			elseif( $field === 'outputCache' )
			{
				return (int)$this->outputCache;
			}
			elseif( $field === 'isPostBack' )
			{
				return (bool)$this->isPostBack;
			}
			elseif( $field === 'isAjaxPostBack' )
			{
				return (bool)$this->isAjaxPostBack;
			}
			elseif( $field === 'page' )
			{
				return $this->page;
			}
			else
			{
				if( $this->page )
				{
					$control = $this->page->findControl($field);

					if( !is_null( $control ))
					{
						return $control;
					}
					else
					{
						throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
					}
				}
				else
				{
					throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
				}
			}
		}


		/**
		 * This method will process the request and impliment the page life cycles
		 *
		 * @param   HTTPRequest		&$request	HTTPRequest object
		 * @return  void
		 */
		public function requestProcessor( \System\IO\HTTPRequest &$request )
		{
			$this->theme = $this->theme?$this->theme:\System\AppServlet::getInstance()->config->theme;

			if(\System\AppServlet::getInstance()->config->viewStateMethod == 'cookies')
			{
				$viewState = $request->getCookieData();
			}
			else
			{
				$viewState =& \System\AppServlet::getInstance()->session->getSessionData();
			}

			if( isset( $request->request["async"] ))
			{
				$this->isAjaxPostBack = true;
				unset( $request->request["async"] );
			}

			$docName = str_replace( '/', '.', strtolower( $this->controllerId ));

			$this->isPostBack = strtoupper(\System\IO\HTTPRequest::getRequestMethod())==='POST'?true:false;

			/**
			 * Page Creation
			 * create Page component
			**/
			$this->page = new \System\UI\WebControls\Page( 'page' );

			// set template implicitly
			$this->page->template = \System\AppServlet::getInstance()->config->views . '/' . strtolower( $this->controllerId ) . __TEMPLATE_EXTENSION__;

			// set title implicitly
			$this->page->title = str_replace( ' / ', '/', ucwords( str_replace( '/', ' / ' , strtolower( $this->controllerId ))));

			// include jscripts
			if( \System\AppServlet::getInstance()->config->state == \System\AppState::Debug() )
			{
				$this->page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/debug/debug.js' );
				$this->page->addLink( \System\HTTPAppServlet::getInstance()->config->assets . '/debug/debug.css' );
			}

			// include all css files for theme
			foreach( glob( \System\AppServlet::getInstance()->config->htdocs . substr( \System\AppServlet::getInstance()->config->themes, strlen( \System\AppServlet::getInstance()->config->uri )) . '/' . $this->theme . "/*.css" ) as $stylesheet )
			{
				$this->page->addLink( \System\AppServlet::getInstance()->config->themes . '/' . $this->theme . strrchr( $stylesheet, '/' ));
			}

			/**
			 * onInit Event
			 * create the initial components and set their default values
			**/
			$this->page->init(); // initiates onInit event for each control


			/**
			 * Load Viewstate
			 * restore each components to its previous viewstate
			**/
			if( isset( $viewState[ \System\AppServlet::getInstance()->applicationId
				. '_' . $docName
				. '_viewstate'] )) {

				$viewStateArray = unserialize( $viewState[ \System\AppServlet::getInstance()->applicationId
				. '_' . $docName
				. '_viewstate'] );

				$this->page->loadViewState( $viewStateArray );
			}

			if($this->page->master)
			{
				if( isset( $viewState[ \System\AppServlet::getInstance()->applicationId
					. '_' . $this->page->master->controlId
					. '_masterviewstate'] )) {

					$viewStateArray = unserialize( $viewState[ \System\AppServlet::getInstance()->applicationId
					. '_' . $this->page->master->controlId
					. '_masterviewstate'] );

					$this->page->master->loadMasterViewViewState( $viewStateArray );
				}
			}


			/**
			 * onLoad Event
			 * components and component relationships have been established
			 * but their data has not been updated from the request
			**/
			$this->page->load( $request->request ); // initiates onLoad event for each control


			/**
			 * Process Request
			**/


			/**
			 * Load Request
			 * update all components with data from the request
			**/
			$this->page->requestProcessor( $request->request );


			/**
			 * onPost Event
			 * post data has been submitted
			**/
			if( strtoupper( \System\IO\HTTPRequest::getRequestMethod() ) === 'POST' )
			{
				/**
				 * Post Events
				 * each component will invoke an onPost event if data has been posted
				 * or an onChange event if component value has changed from it's last
				 * viewstate
				**/
				$this->page->handlePostEvents( $request->request );
			}


			/**
			 * onPreRender event
			 * update all components with data from the request
			**/
			$this->page->preRender();


			/**
			 * Save Viewstate
			 * save the state of all components in a persistant layer
			**/
			$viewStateArray = array();
			$this->page->saveViewState( $viewStateArray );
			$viewState[ \System\AppServlet::getInstance()->applicationId
				. '_' . $docName
				. '_viewstate'] = serialize( $viewStateArray );

			if($this->page->master)
			{
				$viewStateArray = array();

				$this->page->master->saveMasterViewViewState( $viewStateArray );
				$viewState[ \System\AppServlet::getInstance()->applicationId
					. '_' . $this->page->master->controlId
					. '_masterviewstate'] = serialize( $viewStateArray );
			}


			$config = \System\AppServlet::getInstance()->config;
			if($config->viewStateMethod == 'cookies')
			{
				foreach($viewState as $param=>$values)
				{
					\setrawcookie($param, \rawurlencode($values), time() + 3600, '', '', false, true);
				}
			}
		}


		/**
		 * return view component for rendering
		 *
		 * @return  object			view component
		 */
		public function getView()
		{
			// check scripter buffer
			if($this->isAjaxPostBack)
			{
				/**
				 * get ajax buffer
				**/

				$this->page->loadAjaxJScriptBuffer("var ul = document.getElementById('messages');");
				$this->page->loadAjaxJScriptBuffer("if(ul){if(ul.hasChildNodes()){while(ul.childNodes.length>=1){ul.removeChild(ul.firstChild);}}}");

				if(\System\HTTPAppServlet::getInstance()->messages->count>0)
				{
					foreach(\System\HTTPAppServlet::getInstance()->messages as $msg)
					{
						$this->page->loadAjaxJScriptBuffer("var li = document.createElement('li');");
						$this->page->loadAjaxJScriptBuffer("li.setAttribute('class', '".\strtolower($msg->type)."');");
						$this->page->loadAjaxJScriptBuffer("li.innerHTML = '".\nl2br(\addslashes($msg->message))."';");
						$this->page->loadAjaxJScriptBuffer("if(ul) ul.appendChild(li);");
					}

					\System\HTTPAppServlet::getInstance()->messages->removeAll();
				}

				if(\System\HTTPAppServlet::getInstance()->forwardURI)
				{
					$url = \System\HTTPAppServlet::getInstance()->getPageURI( \System\HTTPAppServlet::getInstance()->forwardURI, \System\HTTPAppServlet::getInstance()->forwardParams );
					$this->page->loadAjaxJScriptBuffer("location.href='".$url."';");

					// clear forward
					\System\HTTPAppServlet::getInstance()->clearForwardPage();
				}

				// replace output with ajax buffer output
				$page = new \System\UI\WebControls\View('buffer');
				$page->addHeader('content-type:text/plain');
				$page->setData($this->page->getAjaxBuffer());
				return $page;
			}
			else
			{
				return $this->page;
			}
		}

		/* backwards compatibility */

		/**
		 * @ignore
		 */
		public function oldInit($request)
		{
			$this->onInit($request);
		}

		/**
		 * @ignore
		 */
		public function oldLoad($request)
		{
			$this->onLoad($request);
		}

		/**
		 * @ignore
		 */
		public function oldRequest($request)
		{
			$this->onRequest($request);
		}

		/**
		 * @ignore
		 */
		public function oldPost($request)
		{
			$this->onPost($request);
		}

		/**
		 * @ignore
		 */
		public function oldPreRender($request)
		{
			$this->onPreRender($request);
		}

		/**
		 * @ignore
		 */
		protected function onInit(\System\IO\HTTPRequest &$request) {}

		/**
		 * @ignore
		 */
		protected function onLoad(\System\IO\HTTPRequest &$request) {}

		/**
		 * @ignore
		 */
		protected function onRequest(\System\IO\HTTPRequest &$request) {}

		/**
		 * @ignore
		 */
		protected function onPost(\System\IO\HTTPRequest &$request) {}

		/**
		 * @ignore
		 */
		protected function onPreRender(\System\IO\HTTPRequest &$request) {}
	}
?>