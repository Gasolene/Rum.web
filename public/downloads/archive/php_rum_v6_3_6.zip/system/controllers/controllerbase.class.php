<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Controllers;


	/**
	 * Provides base functionality for the Controller
	 *
	 * @property string $controllerId Controller id
	 * @property int $outputCache Output cache in seconds
	 *
	 * @package			PHPRum
	 * @subpackage		Controllers
	 * @author			Darnell Shinbine
	 */
	abstract class ControllerBase
	{
		/**
		 * id of the controller
		 * @var string
		 */
		protected $controllerId			= '';

		/**
		 * specifies how long to cache page for (in seconds), 0 disables caching
		 * @var int
		 */
		protected $outputCache			= 0;

		/**
		 * specifies whether the page requires SSL encryption
		 * @var bool
		 */
		protected $ssl					= false;


		/**
		 * Constructor
		 *
		 * @param   string		$controllerId	Controller Id
		 * @return  void
		 */
		final public function __construct( $controllerId )
		{
			$this->controllerId = (string)$controllerId;
			$this->outputCache = (int)$this->outputCache?(int)$this->outputCache:\System\AppServlet::getInstance()->config->outputCache;

			if( $this->ssl && \System\AppServlet::getInstance()->config->protocol <> 'https' )
			{
				// redirect to secure server (forward session)
				$url = 'https://' . __NAME__ . (__SSL_PORT__<>443?':'.__SSL_PORT__:'') . \System\HTTPAppServlet::getInstance()->getPageURI('', array( \System\HTTPAppServlet::getInstance()->session->sessionName => \System\HTTPAppServlet::getInstance()->session->sessionId ));

				// write and close session
				\System\AppServlet::getInstance()->session->close();

				header( "location:$url" );
				exit;
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'controllerId' )
			{
				return (string)$this->controllerId;
			}
			elseif( $field === 'outputCache' )
			{
				return (int)$this->outputCache;
			}
			else
			{
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * this method will generate and return a cache id
		 *
		 * @param   HTTPRequest		&$request	HTTPRequest object
		 * @return  string							cache id
		 */
		public function getCacheId( \System\IO\HTTPRequest &$request )
		{
			return '?agent=' . \substr($_SERVER['HTTP_USER_AGENT'], 0, 16) . '&' . $request->getQueryString();
		}


		/**
		 * this method will process the request
		 *
		 * @param   HTTPRequest		&$request	HTTPRequest object
		 * @return  void
		 */
		abstract public function requestProcessor( \System\IO\HTTPRequest &$request );


		/**
		 * return view component for rendering
		 *
		 * @return  View			view control
		 */
		abstract public function getView();
	}
?>