<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\IO;


	/**
	 * Provides access to read/write cache files
	 *
	 * @package			PHPRum
	 * @subpackage		IO
	 * @author			Darnell Shinbine
	 */
	final class Cache
	{
		/**
		 * array of cache id's
		 * @var array
		 */
		protected static $idArray = array();


		/**
		 * Checks a value from cache with a specified key.
		 *
		 * @param string	$id			the key identifying the value to be cached
		 * @param integer	$expire		the expiration time of the value in seconds
		 * 								0 means never expire,
		 * @return bool					true if the value is stored in cache
		 */
		static public function exists( $id, $expire = 0 )
		{
			$file = self::_getPath( (string)$id );

			if( file_exists( $file ))
			{
				if( (int) $expire > 0 )
				{
					if( time() - filectime( $file ) > (int)$expire )
					{
						return false;
					}
				}
				return true;
			}
		}


		/**
		 * Retrieves a value from cache with a specified key.
		 *
		 * @param string	$id			the key identifying the value to be cached
		 * @param integer	$expire		the expiration time of the value in seconds
		 * 								0 means never expire,
		 * @return string				the value stored in cache
		 */
		static public function get( $id )
		{
			if( self::exists( $id ))
			{
				$file = self::_getPath( (string)$id );
				$value = file_get_contents( $file );

				if( $value !== false )
				{
					return base64_decode( $value );
				}
				else
				{
					throw new FileLoadException("could not read cache from `$file`");
				}
			}
			else
			{
				throw new \System\ArgumentOutOfRangeException("id `$id` does not exist, check Cache::exists()");
			}
		}


		/**
		 * Stores a value identified by a key into cache.
		 *
		 * If the cache already contains such a key, the existing value and
		 * expiration time will be replaced with the new ones.
		 *
		 * @param string	$id		the key identifying the value to be cached
		 * @param string 	$value	the value to be cached
		 * @return void
		 */
		static public function put( $id, $value )
		{
			$file = self::_getPath( (string)$id );
			$value = base64_encode( (string)$value );

			$fp = @fopen( $file, 'wb+' );
			if( $fp )
			{
				if( fwrite( $fp, $value, strlen( $value )) !== false )
				{
					fclose( $fp );
				}
				else
				{
					throw new FileNotWritableException("could not write to cache file {$file}");
				}
			}
		}


		/**
		 * Deletes a value with the specified key from cache
		 *
		 * @param  string	$id		the key identifying the value to be cached
		 * @return void
		 */
		static public function clear( $id )
		{
			$file = self::_getPath( (string)$id );

			if( self::exists( (string)$id ))
			{
				if( !unlink( $file ))
				{
					throw new FileNotWritableException("could not delete cache file {$file}");
				}
			}
			else
			{
				return false;
			}
		}


		/**
		 * Deletes all values from cache.
		 *
		 * @return void
		 */
		static public function flush()
		{
			$files = glob( __CACHE_PATH__ . '/*' );

			foreach( $files as $file )
			{
				if( is_file( $file ))
				{
					if( !unlink( $file ))
					{
						throw new FileNotWritableException("could not delete cache file {$file}");
					}
				}
			}
		}


		/**
		 * get id array
		 *
		 * @return array
		 */
		static public function getIdArray()
		{
			$idArray = array();
			$files = glob( __CACHE_PATH__ . '/*' );

			foreach( $files as $file )
			{
				if( is_file( $file ))
				{
					$idArray[] = str_replace( '\\', '_', base64_decode( substr( strrchr( $file, '/' ), 1 )));
				}
			}

			return $idArray;
		}


		/**
		 * Returns the path to the cache file
		 *
		 * @param  string	$id		cache id
		 * @return string			path
		 */
		static private function _getPath( $id )
		{
			$cacheId = str_replace( '/', '_', base64_encode( (string)$id ));

			return __CACHE_PATH__ . '/' . $cacheId;
		}
	}
?>