<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\Validators;


	/**
	 * Provides basic validation for web controls
	 *
	 * @property string $errorMessage error message
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	abstract class ValidatorBase
	{
		/**
		 * error message
		 * @var string
		 */
		protected $errorMessage;


		/**
		 * control to validate
		 * @var InputBase
		 */
		protected $controlToValidate;


		/**
		 * ValidatorBase
		 *
		 * @param  string $errorMessage error message
		 * @return void
		 */
		public function __construct($errorMessage = '')
		{
			$this->errorMessage = (string)$errorMessage;
		}


		/**
		 * __get
		 *
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'errorMessage' ) {
				return $this->errorMessage;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * __set
		 *
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'errorMessage' ) {
				$this->errorMessage = (string)$value;
			}
			else {
				throw new \System\BadMemberCallException("call to undefined property $field in ".get_class($this));
			}
		}


		/**
		 * attach the validator to a group of InputBase objects
		 *
		 * @param InputBase $input1 [, input $... ]
		 * @return void
		 */
		static public function attach()
		{
			for($i = 0; $i < func_num_args(); $i++)
			{
				$input = func_get_arg($i);
				if($input instanceof \System\UI\WebControls\InputBase)
				{
					$validator = \get_called_class();
					$input->addValidator(new $validator());
				}
				else
				{
					throw new \System\InvalidArgumentException("Argument ".($i+1)." passed to ValidatorBase::attach() must be an object of type InputBase");
				}
			}
		}


		/**
		 * set error message
		 *
		 * @param  string $errorMessage error message
		 * @return void
		 */
		public function setErrorMessage($errorMessage)
		{
			$this->errorMessage = (string)$errorMessage;
		}


		/**
		 * set control to validate
		 *
		 * @param  InputBase $controlToValidate control to validate
		 * @return void
		 */
		final public function setControlToValidate(\System\UI\WebControls\InputBase &$controlToValidate)
		{
			$this->controlToValidate =& $controlToValidate;

			$this->onLoad();
		}


		/**
		 * validates the control
		 *
		 * @param  InputBase $controlToValidate control to validate
		 * @return bool
		 */
		abstract public function validate();


		/**
		 * on load
		 *
		 * @return void
		 */
		protected function onLoad() {}
	}
?>