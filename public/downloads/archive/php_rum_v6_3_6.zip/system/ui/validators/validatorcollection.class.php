<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\Validators;
	use \System\Collections\CollectionBase;


	/**
	 * Represents a Collection of Validator objects
	 * 
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	final class ValidatorCollection extends CollectionBase
	{
		/**
		 * control
		 * @var InputBase
		 */
		private $_control;


		/**
		 * Constructor
		 *
		 * @param  InputBase	$parent		instance of a InputBase object
		 * 
		 * @return void
		 */
		public function __construct( \System\UI\WebControls\InputBase &$control ) {
			$this->_control =& $control;
		}


		/**
		 * implement ArrayAccess methods
		 * @ignore 
		 */
		public function offsetSet($index, $item)
		{
			if( array_key_exists( $index, $this->items ))
			{
				if( $item instanceof ValidatorBase )
				{
					$item->setControlToValidate($this->_control);
					$this->items[$index] = $item;
				}
				else
				{
					throw new \System\TypeMismatchException("invalid index value expected object of type ValidatorBase in ".get_class($this));
				}
			}
			else
			{
				throw new \System\IndexOutOfRangeException("undefined index $index in ".get_class($this));
			}
		}


		/**
		 * add Validator to Collection
		 *
		 * @param  Validator $item
		 *
		 * @return void
		 */
		public function add( $item )
		{
			if( $item instanceof ValidatorBase )
			{
				$item->setControlToValidate($this->_control);
				array_push( $this->items, $item );
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of type ValidatorBase");
			}
		}
	}
?>