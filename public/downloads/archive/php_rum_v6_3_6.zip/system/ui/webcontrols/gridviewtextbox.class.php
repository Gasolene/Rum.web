<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a GridView TextBox
	 * 
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	class GridViewTextBox extends GridViewControlBase
	{
		/**
		 * get item text
		 *
		 * @param string $dataField
		 * @param string $parameter
		 * @param string $params
		 * @return string
		 */
		protected function getItemText($dataField, $parameter, $params)
		{
			if($this->ajaxPostBack)
			{
				$params .= "&{$parameter}=\'+this.value+\'";
				return '\'<input type="text" onchange="PHPRum.httpRequestObjects[\\\''.strtolower($parameter).'HTTPRequest\\\'] = PHPRum.sendHttpRequest(\\\''.\System\AppServlet::getInstance()->config->uri.'/\\\',\\\''.htmlentities($params).'\\\',\\\'POST\\\', function() { PHPRum.evalHttpResponse(\\\'PHPRum.httpRequestObjects[\\\\\\\''.strtolower($parameter).'HTTPRequest\\\\\\\']\\\') } );" name="'.$parameter.'" value="\'.%'.$dataField.'%.\'" />\'';
			}
			else
			{
				return '\'<input type="text" name="'.$parameter.'" value="\'.%'.$dataField.'%.\'" />\'';
			}
		}
	}
?>