<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	if(__BACKWARDS_COMPATIBILITY_MODE__) :

	/**
	 * Represents a ComboBox
	 *
	 * @property string $legend form legend
	 * @property string $action form action
	 * @property string $method form submit method
	 * @property string $encodeType form encoding type
	 * @property string $forward controller to forward to
	 * @property bool $autoFocus specifies whether to auto focus
	 * @property bool $hiddenField specifies whether to check for hidden captcha field before processing request
	 * @property string $submitted specifies if form was submitted
	 * @property RequestParameterCollection $parameters form parameters
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 * @ignore
	 */
	class ComboBox extends DropDownList
	{
		/**
		 * Constructor
		 *
		 * @param  string   $controlId  Control Id
		 *
		 * @return void
		 */
		public function __construct( $controlId )
		{
			parent::__construct( $controlId );

			if(__SHOW_DEPRECATED_NOTICES__)
			{
				trigger_error("ComboBox is deprecated, use DropDownList instead");
			}
		}
	}

	endif;
?>