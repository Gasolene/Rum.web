<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a GridView button
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	class GridViewButton extends GridViewControlBase
	{
		/**
		 * specifies whether column can be filtered
		 * @var bool
		 */
		protected $canFilter				= false;

		/**
		 * event request parameter
		 * @var string
		 */
		private $onPostParameter			= '';

		/**
		 * button name
		 * @var string
		 */
		private $buttonName					= '';


		/**
		 * @param  string		$dataField			field name
		 * @param  string		$buttonName			name of button
		 * @param  string		$parameter			parameter
		 * @param  string		$headerText			header text
		 * @param  string		$footerText			footer text
		 * @param  string		$className			css class name
		 * @return void
		 */
		public function __construct( $dataField, $buttonName='', $parameter = '', $headerText='', $footerText='', $className='' )
		{
			$this->buttonName = $buttonName?$buttonName:$dataField;
			$pkey=$dataField;

			parent::__construct($dataField, $pkey, $parameter, $headerText, $footerText, $className);

			$postEvent='on'.ucwords(str_replace(" ","_",$this->parameter)).'Click';
			$this->events->add(new \System\UI\Events\GridViewColumnPostEvent());
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $postEvent))
			{
				$this->events->registerEventHandler(new \System\UI\Events\GridViewColumnPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $postEvent));
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		public function onPost( &$request )
		{
			if( isset( $request[$this->parameter] ))
			{
				$this->events->raise(new \System\UI\Events\GridViewColumnPostEvent(), $this, $request);
			}

			parent::onPost( $request );
		}


		/**
		 * get item text
		 *
		 * @param string $dataField
		 * @param string $parameter
		 * @param string $params
		 * @return string
		 */
		protected function getItemText($dataField, $parameter, $params)
		{
			if( $this->ajaxPostBack )
			{
				$params .= "&{$parameter}='.%{$dataField}%.'";
				return '\'<input type="button" onclick="PHPRum.httpRequestObjects[\\\''.strtolower($parameter).'HTTPRequest\\\'] = PHPRum.sendHttpRequest(\\\''.\System\AppServlet::getInstance()->config->uri.'/\\\',\\\''.\htmlentities($params).'\\\',\\\'POST\\\', function() { PHPRum.evalHttpResponse(\\\'PHPRum.httpRequestObjects[\\\\\\\''.strtolower($parameter).'HTTPRequest\\\\\\\']\\\') } );" value="'.$this->buttonName.'" class=\"button\" />\'';
			}
			else
			{
				return "'<input onclick=\"PHPRum.sendPostBack(\\'".\System\AppServlet::getInstance()->config->uri."\\', \\'".\htmlentities($this->getRequestData())."&amp;{$parameter}='.htmlentities(%{$dataField}%).'\\', \\'POST\\');\" type=\"button\" value=\"{$this->buttonName}\" class=\"button\" />'";
			}
		}
	}
?>