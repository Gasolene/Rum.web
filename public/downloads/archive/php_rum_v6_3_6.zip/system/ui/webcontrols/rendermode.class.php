<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;

	//if(\defined('__BACKWARDS_COMPATIBILITY_MODE__') && \defined('__BACKWARDS_COMPATIBILITY_MODE__')) :

	/**
	 * Represents a render mode type
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	final class RenderMode
	{
		private $flags;

		private function __construct($flags)
		{
			$this->flags = (int)$flags;
		}

		/**
		 * Specifies render mode as HTML
		 * @return RenderMode
		 */
		public static function HTML() {return new RenderMode(1);}

		/**
		 * Specifies render mode as DHTML
		 * @return RenderMode
		 */
		public static function DHTML() {return new RenderMode(2);}

		/**
		 * Specifies render mode as AJAX
		 * @return RenderMode
		 */
		public static function AJAX() {return new RenderMode(4);}
	}

	//endif;
?>