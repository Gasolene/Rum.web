<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 *
	 *
	 */
	namespace System\UI\WebControls;

	/**
	 * name of hidden field
	 * @var string
	 */
	const GOTCHAFIELD = '__gotcha';


	/**
	 * Represents a Form
	 *
	 * @property string $legend form legend
	 * @property string $action form action
	 * @property string $method form submit method
	 * @property string $encodeType form encoding type
	 * @property string $forward controller to forward to
	 * @property bool $ajaxPostBack specifies whether to perform ajax postback, Default is false
	 * @property bool $autoFocus specifies whether to auto focus
	 * @property bool $hiddenField specifies whether to check for hidden captcha field before processing request
	 * @property string $submitted specifies if form was submitted
	 * @property RequestParameterCollection $parameters form parameters
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 *
	 */
	class Form extends WebControlBase
	{
		/**
		 * Fieldset legend, Default is none
		 * @var string
		 */
		protected $legend				= '';

		/**
		 * URL to send form data, Default is self
		 * @var string
		 */
		protected $action				= '';

		/**
		 * method to send form data, Default is 'POST'
		 * @var string
		 */
		protected $method				= 'POST';

		/**
		 * Form encoding type
		 * @var string
		 */
		protected $encodeType			= 'application/x-www-form-urlencoded';

		/**
		 * controller to forward to, Default is the current controller
		 * @var string
		 */
		protected $forward				= '';

		/**
		 * turn on or off auto focusing
		 * @var bool
		 */
		protected $autoFocus			= true;

		/**
		 * turn on or off ajax post backs
		 * @var bool
		 */
		protected $ajaxPostBack			= false;

		/**
		 * specifies whether to check for hidden captcha field before processing request
		 * @var bool
		 */
		protected $hiddenField			= true;

		/**
		 * set if the form was submitted
		 * @var bool
		 */
		protected $submitted			= false;

		/**
		 * array of variables to post on submit
		 * @var RequestParameterCollection
		 */
		protected $parameters			= null;

		/**
		 * specify javascript to execute on form submit
		 * @var string
		 */
		private $_onsubmit				= '';


		/**
		 * Constructor
		 *
		 * @param  string   $controlId  Control Id
		 *
		 * @return void
		 */
		public function __construct( $controlId )
		{
			parent::__construct( $controlId );

			$this->action = \System\AppServlet::getInstance()->config->uri . '/';
			$this->forward = \System\AppServlet::getInstance()->thisPage;
			$this->parameters = new \System\IO\RequestParameterCollection();

			// event handling
			$this->events->add(new \System\UI\Events\FormPostEvent());
			$this->events->add(new \System\UI\Events\FormAjaxPostEvent());

			$onPostMethod = 'on' . ucwords( $this->controlId ) . 'Post';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPostMethod))
			{
				$this->events->registerEventHandler(new \System\UI\Events\FormPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPostMethod));
			}

			$onAjaxPostMethod = 'on' . ucwords( $this->controlId ) . 'AjaxPost';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onAjaxPostMethod))
			{
				$this->ajaxPostBack = true;
				$this->events->registerEventHandler(new \System\UI\Events\FormAjaxPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onAjaxPostMethod));
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'legend' )
			{
				$this->legend = (string)$value;
			}
			elseif( $field === 'action' )
			{
				$this->action = (string)$value;
			}
			elseif( $field === 'method' )
			{
				if( strtolower( $value === 'get' ) ||
					strtolower( $value === 'put' ) ||
					strtolower( $value === 'post' ) ||
					strtolower( $value === 'delete' ))
				{
					$this->method = (string)$value;
				}
				else
				{
					throw new \System\TypeMismatchException(get_class($this)."::method must be a string of get put post or delete");
				}
			}
			elseif( $field === 'encodeType' )
			{
				$this->encodeType = (string)$value;
			}
			elseif( $field === 'forward' )
			{
				$this->forward = (string)$value;
			}
			elseif( $field === 'ajaxPostBack' )
			{
				$this->ajaxPostBack = (bool)$value;
			}
			elseif( $field === 'autoFocus' )
			{
				$this->autoFocus = (bool)$value;
			}
			elseif( $field === 'hiddenField' )
			{
				$this->hiddenField = (string)$value;
			}
			elseif( $field === 'onPost' )
			{
				$this->onPost = (string)$value;
			}
			else
			{
				parent::__set( $field, $value );
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'legend' )
			{
				return $this->legend;
			}
			elseif( $field === 'action' )
			{
				return $this->action;
			}
			elseif( $field === 'method' )
			{
				return $this->method;
			}
			elseif( $field === 'encodeType' )
			{
				return $this->encodeType;
			}
			elseif( $field === 'forward' )
			{
				return $this->forward;
			}
			elseif( $field === 'autoFocus' )
			{
				return $this->autoFocus;
			}
			elseif( $field === 'ajaxPostBack' )
			{
				return $this->ajaxPostBack;
			}
			elseif( $field === 'hiddenField' )
			{
				return $this->hiddenField;
			}
			elseif( $field === 'onPost' )
			{
				return $this->onPost;
			}
			elseif( $field === 'submitted' )
			{
				return $this->submitted;
			}
			elseif( $field === 'parameters' )
			{
				return $this->parameters;
			}
			elseif( $field === 'errorMessage' && __BACKWARDS_COMPATIBILITY_MODE__)
			{
				if(__SHOW_DEPRECATED_NOTICES__) {
						\trigger_error("`".get_class($this)."->errorMessage` is deprecated, use `".get_class($this)."->validate(\$errMsg)` instead", E_USER_NOTICE);
				}
				$errMsg = '';
				$this->validate($errMsg);
				return $errMsg;
			}
			else
			{
				return parent::__get($field);
			}
		}


		/**
		 * adds child control to collection
		 *
		 * @param  InputBase		&$control		instance of an InputBase
		 * @return void
		 */
		final public function add( WebControlBase $control )
		{
			if( $control instanceof InputBase || $control instanceof Fieldset )
			{
				return parent::addControl($control);
			}
			else
			{
				throw new \System\InvalidArgumentException("Argument 1 passed to ".get_class($this)."::add() must be an object of type InputBase or Fieldset");
			}
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			parent::onLoad();

			$page = $this->getParentByType('\System\UI\WebControls\Page');
			$page->addScript( \System\HTTPAppServlet::getInstance()->config->assets . '/form/form.js' );

			// perform ajax request
			if( $this->ajaxPostBack )
			{
				$this->_onsubmit = "return PHPRum.submitForm(this, " . ( $this->ajaxEventHandler?'\'' . addslashes( (string) $this->ajaxEventHandler ) . '\'':'PHPRum.evalFormResponse);' );
			}
		}


		/**
		 * process the HTTP request array
		 *
		 * @param  array	&$request	request array
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( isset( $request[ $this->getHTMLControlIdString() . '__submit'] ))
			{
				if( $this->hiddenField )
				{
					if( isset( $request[ $this->getHTMLControlIdString() . GOTCHAFIELD ] )?!$request[ $this->getHTMLControlIdString() . GOTCHAFIELD]:false )
					{
						$this->submitted = true;
					}
				}
				else
				{
					$this->submitted = true;
				}

				unset( $request[ $this->getHTMLControlIdString() . '__submit'] );
			}
			else
			{
				$this->autoFocus();
			}

			if($this->ajaxPostBack && $this->submitted)
			{
				$this->getParentByType('\\System\\UI\\WebControls\\Page')->loadAjaxJScriptBuffer("");

				if($this->autoFocus)
				{
					$this->validate($errMsg);

					foreach( $this->controls as $childControl )
					{
						if( $childControl->focus )
						{
							$this->getParentByType('\\System\\UI\\WebControls\\Page')->loadAjaxJScriptBuffer("document.getElementById('{$childControl->getHTMLControlIdString()}').focus()");
							break;
						}
					}
				}
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		protected function onPost( array &$request )
		{
			if( $this->submitted )
			{
				if( $this->ajaxPostBack )
				{
					$this->events->raise(new \System\UI\Events\FormAjaxPostEvent(), $this, $request);
				}
				else
				{
					$this->events->raise(new \System\UI\Events\FormPostEvent(), $this, $request);
				}
			}
		}


		/**
		 * bind all child controls in form to datasource
		 *
		 * @return void
		 */
		protected function onDataBind()
		{
			// loop through input controls
			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
				$childControl = $this->controls->itemAt( $i );

				// check if DataField is in datasource
				if(!( array_search( $childControl->dataField, array_keys( $this->dataSource->row )) === false ))
				{
					// check if value of dataField is null
					if( !is_null( $this->dataSource[$childControl->dataField] ))
					{
						// set value of control to value from datasource
						$childControl->value = $this->dataSource[$childControl->dataField];
					}
					else
					{
						// set value of control to value from datasource
						$childControl->value = '';
					}

					// if textbox, auto set max length
					if( $childControl instanceof TextBox && $childControl->maxLength === 0 )
					{
						$childControl->maxLength = $this->dataSource->fields->itemAt( $this->dataSource->fields->indexOf( $childControl->dataField ))->length;
					}
				}
			}
		}


		/**
		 * update DataSet using values from child controls
		 *
		 * @return void
		 * @ignore
		 */
		public function updateDataSource()
		{
			return $this->save();
		}


		/**
		 * update DataSet using values from child controls
		 *
		 * @return void
		 */
		public function save()
		{
			if( $this->dataSource )
			{
				// loop through child controls
				for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
				{
					$childControl = $this->controls->itemAt( $i );

					// check if field is in datasource
					if(!( array_search( $childControl->dataField, array_keys( $this->dataSource->row )) === false ))
					{
						$this->dataSource[$childControl->dataField] = $childControl->value;
					}
				}

				if( isset( $this->dataSource->rows[$this->dataSource->cursor] ))
				{
					// update datasource
					return $this->dataSource->update();
				}
				else
				{
					// update datasource
					return $this->dataSource->insert();
				}
			}
			else
			{
				throw new \System\InvalidOperationException("Form::update() called with null dataSource");
			}
		}


		/**
		 * validate all controls in form object
		 *
		 * @param  string $errMsg error message
		 * @return bool
		 */
		public function validate(&$errMsg = '')
		{
			$fail = false;
			if($this->submitted)
			{
				for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
				{
					$childControl = $this->controls->itemAt( $i );

					if( !$childControl->validate($errMsg) )
					{
						$fail = true;
						if( $this->autoFocus )
						{
							$childControl->focus();
						}
					}
				}

				// set focus to first focused control in list
				$this->autoFocus();
			}

			return !$fail;
		}


		/**
		 * auto Focus's form controls
		 *
		 * @return void
		 */
		public function autoFocus()
		{
			// set focus to first control in list if no post event
			if( $this->autoFocus )
			{
				for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
				{
					$childControl = $this->controls->itemAt( $i );

					if( $childControl->focus )
					{
						$this->getParentByType( '\System\UI\WebControls\Page' )->onload .= 'if( document.getElementById(\'' . $childControl->defaultHTMLControlId . '\')) document.getElementById(\'' . $childControl->defaultHTMLControlId . '\').focus();';
						return;
					}
				}

				// no focused control so auto set
				if( isset( $this->controls[0] ))
				{
					$childControl = $this->controls[0];

					if( !$childControl->value )
					{
						$this->getParentByType( '\System\UI\WebControls\Page' )->onload .= 'if( document.getElementById(\'' . $childControl->defaultHTMLControlId . '\')) document.getElementById(\'' . $childControl->defaultHTMLControlId . '\').focus();';
					}
				}
			}
		}


		/**
		 * renders form open tag
		 *
		 * @param   array	$args	attribute parameters
		 * @return void
		 */
		public function start( $args = array() )
		{
			$result = $this->getFormDomObject()->fetch( $args );
			\System\IO\HTTPResponse::write( str_replace( '</form>', '', $result ));
		}


		/**
		 * renders form close tag
		 *
		 * @return void
		 */
		public function end()
		{
			\System\IO\HTTPResponse::write( '</form>' );
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$form = $this->getFormDomObject();
			$fieldset = new \System\XML\DomObject( 'fieldset' );
			$dl = '<dl>';

			$buttons = array();

			if( $this->legend )
			{
				$fieldset->innerHtml .= "<legend>{$this->legend}</legend>";
			}

			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
				$childControl = $this->controls->itemAt( $i );

				if( $childControl instanceof Button )
				{
					$buttons[] = $childControl;
				}
				else
				{
					// create list item
					if( !$childControl->visible )
					{
						$dt = '<dt style="display:none;">';
						$dd = '<dd style="display:none;">';
					}
					else
					{
						$dt = '<dt>';
						$dd = '<dd>';
					}

					// create label
					$dt .= '<label class="'.($childControl->attributes->contains("class")?$childControl->attributes["class"]:'').'" for="'.$childControl->defaultHTMLControlId.'">' . $childControl->label . '</label>';

					// Get input control
					$dd .= $childControl->fetch();

				  	// create validation message span tag
					$errMsg = '';
					if( $this->submitted )
					{
						$childControl->validate($errMsg);
					}

					$dd .= "<span id=\"{$childControl->getHTMLControlIdString()}__err\" class=\"invalid\">{$errMsg}</span>";

					$dl .= $dt . '</dt>';
					$dl .= $dd . '</dd>';
				}
			}

			$dl .= '</dl>';

			$fieldset->innerHtml .= $dl;

			$div = new \System\XML\DomObject('div');
			$div->setAttribute('class', 'buttons');

			foreach( $buttons as $button )
			{
				$div->innerHtml .= $button->fetch();
			}

			$form->addChild( $fieldset );
			$form->addChild( $div );

			return $form;
		}


		/**
		 * returns form as widget
		 *
		 * @return void
		 */
		protected function getFormDomObject()
		{
			$form = $this->createDomObject( 'form' );

			$form->setAttribute( 'id', $this->getHTMLControlIdString() );
			$form->setAttribute( 'action', $this->action );
			$form->setAttribute( 'method', strtolower( $this->method ));
			$form->setAttribute( 'enctype', $this->encodeType );
			$form->appendAttribute( 'class', ' form' );

			if( $this->_onsubmit )
			{
				$form->appendAttribute( 'onsubmit', $this->_onsubmit );
			}

			// public to check if form has been submitted
			$this->parameters[$this->getHTMLControlIdString() . '__submit'] = '1';

			// send session id as http var
			$this->parameters['PHPSESSID'] = session_id();

			// get current variables
			$vars = array_keys( \System\IO\HTTPRequest::$request );

			for( $x=0, $xCount=count( $vars ); $x < $xCount; $x++ )
			{
				// loop through objects
				for( $b=true, $y=0, $yCount=$this->controls->count; $y < $yCount; $y++ )
				{
					// get control
					$obj = $this->controls->itemAt($y);

					// if request public = object name, unset found flag
					if( $obj->getHTMLControlIdString() === $vars[$x] )
					{
						// found instance
						$b=false;
					}
				}

				// if not found in object
				if( $b && $vars[$x] != $this->getHTMLControlIdString() )
				{
					$this->parameters[$vars[$x]] = \System\IO\HTTPRequest::$request[$vars[$x]];
				}
			}

			$hiddenElements = new \System\XML\DomObject('div');

			// set forward controller
			if( isset( $this->parameters[\System\AppServlet::getInstance()->config->requestParameter] ))
			{
				unset( $this->parameters[\System\AppServlet::getInstance()->config->requestParameter] );
			}

			$this->parameters->add( \System\AppServlet::getInstance()->config->requestParameter, $this->forward );

			foreach( $this->parameters as $field => $value )
			{
				if( !empty( $value ))
				{
					$hiddenElements->innerHtml .= "<input type=\"hidden\" name=\"{$field}\" value=\"{$value}\" />";
				}
			}

			if( $this->hiddenField )
			{
				$hiddenElements->innerHtml .= "<input type=\"text\" name=\"".$this->getHTMLControlIdString() . GOTCHAFIELD."\" style=\"display:none;\" />";
			}

			$form->addChild($hiddenElements);

			return $form;
		}


		/**
		 * create controls from DataSet object
		 *
		 * @param  object	$do			dataobject
		 * @return bool					true on success, false on failure
		 * /
		private function _generateControls()
		{
			if( is_object( $this->dataSource ))
			{
				foreach( $this->dataSource->fields as $field )
				{
					if( !$field->primaryKey )
					{
						$childControl = null;

						if( $field->boolean ) {
							$childControl = new CheckBox( $field->name );
						}
						elseif( $field->blob ) {
							$childControl = new TextBox( $field->name );
							$childControl->multiline=true;
						}
						else {
							$childControl = new TextBox( $field->name );
						}

						if( $field->type === 'string' && $field->length ) {
							$childControl->maxLength = $field->length;
							$childControl->size	  = $field->length;
						}

						$childControl->dataField = $field->name;
						$childControl->label	 = ucwords( str_replace( '_', ' ', $field->name ));
						$this->add( $childControl );
						unset( $childControl );
					}
				}
				return true;
			}
			return false;
		}
		*/
	}
?>