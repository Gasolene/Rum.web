<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;
	use \System\Collections\StringDictionary;


	/**
	 * Represents a Collection of list items
	 * 
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	final class ListItemCollection extends StringDictionary
	{
		/**
		 * Adds a new key/item pair to a Dictionary object if key does not already exist
		 *
		 * @param  mixed		$key			key
		 * @param  mixed		$value			value
		 * @return void
		 */
		public function add( $key, $value )
		{
			$this->items[$key] = $value;
		}


		/**
		 * Returns a Boolean value that indicates whether a specified value exists in the Dictionary object
		 *
		 * @param  mixed		$value		value
		 * @return bool
		 */
		public function containsItem( $value )
		{
			foreach( $this->values as $itemValue )
			{
				if( $value == $itemValue )
				{
					return true;
				}
			}
			return false;
		}


		/**
		 * returns index of key found in Dictionary
		 *
		 * @param  mixed	$key		key
		 * @return int					index of key
		 */
		public function indexOf( $key )
		{
			$keys = $this->keys;
			for( $i = 0, $count = count($keys); $i < $count; $i++ )
			{
				// TODO: convert all dbl spaces and tabs
				if( trim($keys[$i]) === $key )
				{
					return $i;
				}
			}
			return -1;
		}


		/**
		 * returns index of item found in Dictionary
		 *
		 * @param  mixed	$key		key
		 * @return int					index of key
		 */
		public function indexOfItem( $value )
		{
			$values = $this->values;
			for( $i = 0, $count = count($values); $i < $count; $i++ )
			{
				if( $values[$i] === $value )
				{
					return $i;
				}
			}
			return -1;
		}
	}
?>