<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Provides base functionality for Input Controls
	 *
	 * @property string $defaultHTMLControlId Specifies the id of the default html control
	 * @property string $dataField Name of the data field in the datasource
	 * @property bool $autoPostBack Specifies whether form will perform postback on change, Default is false
	 * @property bool $ajaxPostBack specifies whether to perform ajax postback on change, Default is false
	 * @property bool $readonly Specifies whether control is readonly
	 * @property bool $disabled Specifies whether the control is disabled
	 * @property string $label Specifies control label
	 * @property string $tooltip Specifies control tooltip
	 * @property int $tabIndex Specifies the tab order if the control
	 * @property bool $focus Specifies whether the control has focus
	 * @property string $value Gets or sets value of control
	 * @property bool $submitted Specifies whether the data has been submitted
	 * @property bool $changed Specifies whether the data has been changed
	 * @property array $validators Array of validators
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	abstract class InputBase extends WebControlBase
	{
		/**
		 * specifies the id of the default html control
		 * @var string
		 */
		protected $defaultHTMLControlId		= "";

		/**
		 * Name of the data field in the datasource
		 * @var string
		 */
		protected $dataField				= '';

		/**
		 * Specifies whether form will submit postback on change, Default is false
		 * @var bool
		 */
		protected $autoPostBack				= false;

		/**
		 * Specifies whether form will submit ajax postback on change, Default is false
		 * @var bool
		 */
		protected $ajaxPostBack				= false;

		/**
		 * Specifies whether the control is readonly, Default is false
		 * @var bool
		 */
		protected $readonly					= false;

		/**
		 * Specifies whether the control is disabled, Default is false
		 * @var bool
		 */
		protected $disabled					= false;

		/**
		 * Specifies control label
		 * @var string
		 */
		protected $label					= '';

		/**
		 * specifies control tool tip
		 * @var string
		 */
		protected $tooltip					= '';

		/**
		 * Specifies the tab order if the control
		 * @var int
		 */
		protected $tabIndex					= 0;

		/**
		 * Specifies whether the control has focus
		 * @var bool
		 */
		protected $focus					= false;

		/**
		 * Gets or sets value of control
		 * @var string
		 */
		protected $value					= null;

		/**
		 * Specifies whether the data has been submitted
		 * @var bool
		 */
		protected $submitted				= false;

		/**
		 * specifies whether the control has changed
		 * @var bool
		 */
		protected $changed					= false;

		/**
		 * contains a collection of validators
		 * @var ValidatorCollection
		 */
		protected $validators				= null;

		/**
		 * instance of the Form object
		 * @var Form
		 */
		private $_form						= null;


		/**
		 * Constructor
		 *
		 * The constructor sets attributes based on session data, triggering events, and is responcible for
		 * formatting the proper request value and garbage handling
		 *
		 * @param  string   $controlId	  Control Id
		 * @param  string   $default		Default value
		 * @return void
		 */
		public function __construct( $controlId, $default = null )
		{
			parent::__construct( $controlId );

			$this->value       = $default;
			$this->label       = str_replace( '_', ' ', $controlId );
			$this->dataField   = $controlId;
			$this->validators  = new \System\UI\Validators\ValidatorCollection($this);

			// event handling
			$this->events->add(new \System\UI\Events\InputPostEvent());
			$this->events->add(new \System\UI\Events\InputChangeEvent());
			$this->events->add(new \System\UI\Events\InputAjaxPostEvent());
			$this->events->add(new \System\UI\Events\InputAjaxChangeEvent());

			$onPostMethod = 'on' . ucwords( $this->controlId ) . 'Post';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onPostMethod))
			{
				$this->events->registerEventHandler(new \System\UI\Events\InputPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onPostMethod));
			}

			$onChangeMethod = 'on' . ucwords( $this->controlId ) . 'Change';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onChangeMethod))
			{
				$this->events->registerEventHandler(new \System\UI\Events\InputChangeEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onChangeMethod));
			}

			$onAjaxPostMethod = 'on' . ucwords( $this->controlId ) . 'AjaxPost';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onAjaxPostMethod))
			{
				$this->ajaxPostBack = true;
				$this->events->registerEventHandler(new \System\UI\Events\InputAjaxPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onAjaxPostMethod));
			}

			$onAjaxChangeMethod = 'on' . ucwords( $this->controlId ) . 'AjaxChange';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $onAjaxChangeMethod))
			{
				$this->ajaxPostBack = true;
				$this->events->registerEventHandler(new \System\UI\Events\InputAjaxChangeEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $onAjaxChangeMethod));
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'defaultHTMLControlId' ) {
				return $this->defaultHTMLControlId;
			}
			elseif( $field === 'dataField' ) {
				return $this->dataField;
			}
			elseif( $field === 'onPost' ) {
				return $this->onPost;
			}
			elseif( $field === 'onChange' ) {
				return $this->onChange;
			}
			elseif( $field === 'autoPostBack' ) {
				return $this->autoPostBack;
			}
			elseif( $field === 'ajaxPostBack' ) {
				return $this->ajaxPostBack;
			}
			elseif( $field === 'readonly' ) {
				return $this->readonly;
			}
			elseif( $field === 'disabled' ) {
				return $this->disabled;
			}
			elseif( $field === 'label' ) {
				return $this->label;
			}
			elseif( $field === 'tooltip' ) {
				return $this->tooltip;
			}
			elseif( $field === 'tabIndex' ) {
				return $this->tabIndex;
			}
			elseif( $field === 'focus' ) {
				return $this->focus;
			}
			elseif( $field === 'value' ) {
				return $this->value;
			}
			elseif( $field === 'submitted' ) {
				return $this->submitted;
			}
			elseif( $field === 'changed' ) {
				return $this->changed;
			}
			elseif( $field === 'validators' ) {
				return $this->validators;
			}
			elseif( $field === 'errorMessage' && __BACKWARDS_COMPATIBILITY_MODE__)
			{
				if(__SHOW_DEPRECATED_NOTICES__) {
					\trigger_error("`".get_class($this)."->errorMessage` is deprecated, use `".get_class($this)."->validate(\$errMsg)` instead", E_USER_NOTICE);
				}
				$errMsg = '';
				$this->validate($errMsg);
				return $errMsg;
			}
			elseif( $field === 'required' && __BACKWARDS_COMPATIBILITY_MODE__)
			{
				if(__SHOW_DEPRECATED_NOTICES__) {
					\trigger_error("`".get_class($this)."->required` is deprecated, use `".get_class($this)."->addValidator(RequiredValidator())` instead", E_USER_NOTICE);
				}

				foreach($this->validators as $validator)
				{
					if($validator instanceof \System\UI\Validators\RequiredValidator)
					{
						return true;
					}
				}

				return false;
			}
			else {
				return parent::__get($field);
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'dataField' ) {
				$this->dataField = (string)$value;
			}
			elseif( $field === 'onPost' ) {
				$this->onPost = (string)$value;
			}
			elseif( $field === 'onChange' ) {
				$this->onChange = (string)$value;
			}
			elseif( $field === 'autoPostBack' ) {
				$this->autoPostBack = (bool)$value;
			}
			elseif( $field === 'ajaxPostBack' ) {
				$this->ajaxPostBack = (bool)$value;
			}
			elseif( $field === 'readonly' ) {
				$this->readonly = (bool)$value;
			}
			elseif( $field === 'disabled' ) {
				$this->disabled = (bool)$value;
			}
			elseif( $field === 'label' ) {
				$this->label = (string)$value;
			}
			elseif( $field === 'tooltip' ) {
				$this->tooltip = (string)$value;
			}
			elseif( $field === 'tabIndex' ) {
				$this->tabIndex = (int)$value;
			}
			elseif( $field === 'focus' ) {
				$this->focus = (bool)$value;
			}
			elseif( $field === 'value' ) {
				$this->value = $value;
			}
			elseif( $field === 'errorMessage' && __BACKWARDS_COMPATIBILITY_MODE__) {
				if(__SHOW_DEPRECATED_NOTICES__) {
					\trigger_error("`".get_class($this)."->errorMessage` is deprecated, use `".get_class($this)."->addValidator()` instead", E_USER_NOTICE);
				}
				if($this->validators->count > 0)
				{
					$this->validators->itemAt(0)->errorMessage = $value;
				}
			}
			elseif( $field === 'required' && __BACKWARDS_COMPATIBILITY_MODE__) {
				if(__SHOW_DEPRECATED_NOTICES__) {
					\trigger_error("`".get_class($this)."->required` is deprecated, use `".get_class($this)."->addValidator(RequiredValidator())` instead", E_USER_NOTICE);
				}
				$this->validators->add(new \System\UI\Validators\RequiredValidator());
			}
			else {
				parent::__set( $field, $value );
			}
		}


		/**
		 * sets focus to the control
		 *
		 * @return bool			True if changed
		 */
		final public function focus()
		{
			$this->focus = true;
		}


		/**
		 * adds a validator to the control
		 *
		 * @param  ValidatorBase
		 * @return void
		 */
		public function addValidator(\System\UI\Validators\ValidatorBase $validator)
		{
			$this->validators->add($validator);
		}


		/**
		 * validates control data, returns true on success
		 *
		 * @param  string		$errMsg		error message
		 * @return bool						true if control value is valid
		 */
		public function validate(&$errMsg = '')
		{
			$fail = false;
			if(!$this->disabled)
			{
				foreach($this->validators as $validator)
				{
					if(!$validator->validate())
					{
						$fail = true;
						$errMsg .= $validator->errorMessage . \System\CARAGERETURN;
					}
				}
			}

			return !$fail;
		}


		/**
		 * renders error message if control does not validate
		 *
		 * @param   array		$args		parameters
		 * @return void
		 */
		public function error( array $args = array() )
		{
			$errMsg = '';
			if($this->submitted)
			{
				$this->validate($errMsg);
			}

			\System\IO\HTTPResponse::write( "<span id=\"{$this->getHTMLControlIdString()}__err\" class=\"invalid\">{$errMsg}</span>" );
		}


		/**
		 * returns an input DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			return $this->getInputDomObject();
		}


		/**
		 * returns an input DomObject representing control
		 *
		 * @return DomObject
		 */
		protected function getInputDomObject()
		{
			$input = $this->createDomObject( 'input' );
			$input->setAttribute( 'name', $this->getHTMLControlIdString() );
			$input->setAttribute( 'id', $this->getHTMLControlIdString() );
			$input->setAttribute('title', $this->tooltip);

			if( $this->submitted && !$this->validate() )
			{
				$input->appendAttribute( 'class', ' invalid' );
			}

			if( $this->autoPostBack )
			{
				$input->appendAttribute( 'onchange', 'document.getElementById(\''.$this->getParentByType( '\System\UI\WebControls\Form')->getHTMLControlIdString().'\').submit();' );
			}

			if( $this->ajaxPostBack )
			{
				$input->appendAttribute( 'onfocus', 'PHPRum.resetValidationTimer('.__VALIDATION_TIMEOUT__.');' );
				$input->appendAttribute( 'onchange', $this->ajaxHTTPRequest . ' = PHPRum.sendHttpRequest( \'' . $this->ajaxCallback . '\', \'' . \System\HTTPAppServlet::getInstance()->config->requestParameter.'='.\System\HTTPAppServlet::getInstance()->thisPage.'&'.$this->getHTMLControlIdString().'__validate=1&'.$this->getHTMLControlIdString().'=\'+this.value, \'POST\', ' . ( $this->ajaxEventHandler?'\'' . addslashes( (string) $this->ajaxEventHandler ) . '\'':'function() { PHPRum.evalHttpResponse(\''.\addslashes($this->ajaxHTTPRequest).'\') }' ) . ' );' );
				$input->appendAttribute( 'onkeyup',  'if(PHPRum.isValidationReady()){' . $this->ajaxHTTPRequest . ' = PHPRum.sendHttpRequest( \'' . $this->ajaxCallback . '\', \'' . \System\HTTPAppServlet::getInstance()->config->requestParameter.'='.\System\HTTPAppServlet::getInstance()->thisPage.'&'.$this->getHTMLControlIdString().'__validate=1&'.$this->getHTMLControlIdString().'=\'+this.value, \'POST\', ' . ( $this->ajaxEventHandler?'\'' . addslashes( (string) $this->ajaxEventHandler ) . '\'':'function() { PHPRum.evalHttpResponse(\''.\addslashes($this->ajaxHTTPRequest).'\') }' ) . ' ); PHPRum.resetValidationTimer('.__VALIDATION_TIMEOUT__.');}' );
				$input->appendAttribute( 'onblur',  $this->ajaxHTTPRequest . ' = PHPRum.sendHttpRequest( \'' . $this->ajaxCallback . '\', \'' . \System\HTTPAppServlet::getInstance()->config->requestParameter.'='.\System\HTTPAppServlet::getInstance()->thisPage.'&'.$this->getHTMLControlIdString().'__validate=1&'.$this->getHTMLControlIdString().'=\'+this.value, \'POST\', ' . ( $this->ajaxEventHandler?'\'' . addslashes( (string) $this->ajaxEventHandler ) . '\'':'function() { PHPRum.evalHttpResponse(\''.\addslashes($this->ajaxHTTPRequest).'\') }' ) . ' ); PHPRum.resetValidationTimer('.__VALIDATION_TIMEOUT__.');' );
			}

			if( $this->readonly )
			{
				$input->setAttribute( 'readonly', 'readonly' );
			}

			if( $this->disabled )
			{
				$input->setAttribute( 'disabled', 'disabled' );
			}

			if( !$this->visible )
			{
				$input->setAttribute( 'type', 'hidden' );
			}

			return $input;
		}


		/**
		 * read view state from session
		 *
		 * @param  array	&$viewState	session array
		 * @return void
		 */
		protected function onLoadViewState( array &$viewState )
		{
			if( $this->enableViewState )
			{
				if( array_key_exists( 'value', $viewState ))
				{
					$this->value = $viewState['value'];
				}
			}
		}


		/**
		 * bind control to datasource
		 * gets record from dataobject and sets the control value to datafield value
		 *
		 * @return bool			true if successfull
		 */
		protected function onDataBind()
		{
			if( array_search( $this->dataField, array_keys( $this->dataSource->row )))
			{
				$this->value = $this->dataSource[$this->dataField];
			}
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			$this->defaultHTMLControlId = $this->getHTMLControlIdString();
			$this->_form = $this->getParentByType( '\System\UI\WebControls\Form' );
		}


		/**
		 * process the HTTP request array
		 *
		 * @param  array		&$request	request data
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( !$this->disabled )
			{
				if( $this->readonly )
				{
					$this->submitted = true;
				}
				elseif( isset( $request[$this->getHTMLControlIdString()] ))
				{
					// submitted
					$this->submitted = true;

					// changed
					if( $this->value != $request[$this->getHTMLControlIdString()] )
					{
						$this->changed = true;
					}

					// setvalue
					$this->value = $request[$this->getHTMLControlIdString()];
					unset( $request[$this->getHTMLControlIdString()] );
				}
			}

			if($this->ajaxPostBack && $this->submitted)
			{
				$this->validate($errMsg);
				$this->getParentByType('\\System\\UI\\WebControls\\Page')->loadAjaxJScriptBuffer("if(document.getElementById('{$this->getHTMLControlIdString()}__err')){PHPRum.setText(document.getElementById('{$this->getHTMLControlIdString()}__err'), '".\addslashes($errMsg)."')}");
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		protected function onPost( array &$request )
		{
			if( $this->submitted )
			{
				$this->events->raise(new \System\UI\Events\InputPostEvent(), $this, $request);

				if( $this->ajaxPostBack )
				{
					$this->events->raise(new \System\UI\Events\InputAjaxPostEvent(), $this, $request);
				}
			}

			if( $this->changed )
			{
				$this->events->raise(new \System\UI\Events\InputChangeEvent(), $this, $request);

				if( $this->ajaxPostBack )
				{
					$this->events->raise(new \System\UI\Events\InputAjaxChangeEvent(), $this, $request);
				}
			}
		}


		/**
		 * write view state to session
		 *
		 * @param  array	&$viewState	session array
		 * @return void
		 */
		protected function onSaveViewState( array &$viewState )
		{
			if( $this->enableViewState )
			{
				$viewState['value'] = $this->value;
			}
		}


		/**
		 * Event called on ajax callback
		 *
		 * @return void
		 */
		protected function onUpdateAjax()
		{
			$this->getParentByType('\\System\\UI\\WebControls\\Page')->loadAjaxJScriptBuffer("document.getElementById('{$this->getHTMLControlIdString()}').value='$this->value';");
		}
	}
?>