<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 *
	 *
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a Fieldset
	 *
	 * @property string $legend fieldset legend
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 *
	 */
	class Fieldset extends WebControlBase
	{
		/**
		 * Fieldset legend
		 * @var string
		 */
		protected $legend				= '';


		/**
		 * Constructor
		 *
		 * @param  string   $controlId  Control Id
		 *
		 * @return void
		 */
		public function __construct( $controlId )
		{
			parent::__construct( $controlId );

			$this->legend = $controlId;
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __set( $field, $value )
		{
			if( $field === 'legend' )
			{
				$this->legend = (string)$value;
			}
			else
			{
				parent::__set( $field, $value );
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field )
		{
			if( $field === 'legend' )
			{
				return $this->legend;
			}
			else
			{
				return parent::__get($field);
			}
		}


		/**
		 * adds child control to collection
		 *
		 * @param  InputBase		&$control		instance of an InputBase
		 * @return void
		 */
		final public function add( InputBase $control )
		{
			return parent::addControl($control);
		}


		/**
		 * called when control is loaded
		 *
		 * @return bool			true if successfull
		 */
		protected function onLoad()
		{
			parent::onLoad();
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$fieldset = $this->createDomObject( 'fieldset' );
			$fieldset->innerHtml .= "<legend>{$this->legend}</legend>";
			$dl = '<dl>';

			for( $i = 0, $count = $this->controls->count; $i < $count; $i++ )
			{
				$childControl = $this->controls->itemAt( $i );

				// create list item
				if( !$childControl->visible )
				{
					$dt = '<dt style="display:none;">';
					$dd = '<dd style="display:none;">';
				}
				else
				{
					$dt = '<dt>';
					$dd = '<dd>';
				}

				// create label
				$dt .= '<label class="'.($childControl->attributes->contains("class")?$childControl->attributes["class"]:'').'" for="'.$childControl->defaultHTMLControlId.'">' . $childControl->label . '</label>';

				// Get input control
				$dd .= $childControl->fetch();

				// create validation message span tag
				$errMsg = '';
				if( $this->submitted )
				{
					$childControl->validate($errMsg);
				}

				$dd .= "<span id=\"{$childControl->getHTMLControlIdString()}__err\" class=\"invalid\">{$errMsg}</span>";

				$dl .= $dt . '</dt>';
				$dl .= $dd . '</dd>';
			}

			$dl .= '</dl>';

			$fieldset->innerHtml .= $dl;

			return $fieldset;
		}
	}
?>