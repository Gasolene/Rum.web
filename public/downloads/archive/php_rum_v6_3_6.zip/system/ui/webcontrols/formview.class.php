<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a FormView Control
	 * 
	 * @package			PHPRum
	 * @subpackage		UI
	 * @author			Darnell Shinbine
	 */
	class FormView extends Form
	{
		/**
		 * Event called when control is initiated
		 *
		 * @return void
		 */
		protected function onInit()
		{
			$this->add( new Button( 'save', 'Save' ));
		}


		/**
		 * bind all child controls in form to datasource
		 *
		 * @return void
		 */
		protected function onDataBind()
		{
			foreach( $this->dataSource->fields as $field )
			{
				if( $field->autoIncrement )
				{
					continue;
				}
				elseif( $field->boolean )
				{
					$this->add( new CheckBox( $field->name ));
				}
				elseif( $field->blob )
				{
					$this->add( new TextBox( $field->name ));
					$this->getControl( $field->name )->multiline = true;
				}
				else
				{
					$this->add( new TextBox( $field->name ));
				}

				$this->getControl( $field->name )->label = ucwords( str_replace( '_', ' ', $field->name ));
			}

			parent::onDataBind();
		}


		/**
		 * process the HTTP request array
		 * 
		 * @param  HTTPRequest	&$request	HTTPRequest object
		 *
		 * @return void
		 */
		protected function onRequest( array &$request )
		{
			if( $this->getControl('save')->submitted )
			{
				$this->save();
			}
		}


		/**
		 * returns a DomObject representing control
		 *
		 * @return DomObject
		 */
		public function getDomObject()
		{
			$dom = parent::getDomObject();
			$dom->appendAttribute( 'class', ' formview' );
			return $dom;
		}
	}
?>