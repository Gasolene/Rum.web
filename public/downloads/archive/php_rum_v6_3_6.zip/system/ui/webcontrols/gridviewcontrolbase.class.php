<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 *
	 *
	 */
	namespace System\UI\WebControls;


	/**
	 * Represents a GridView control
	 *
	 * @property bool $ajaxPostBack specifies whether to perform ajax postback on change, Default is false
	 *
	 * @package			PHPRum
	 * @subpackage		UI
	 *
	 */
	abstract class GridViewControlBase extends GridViewColumn
	{
		/**
		 * event request parameter
		 * @var string
		 */
		protected $parameter				= '';

		/**
		 * primary key
		 * @var string
		 */
		protected $pkey						= '';

		/**
		 * event request parameter
		 * @var string
		 */
		protected $ajaxPostBack				= false;

		/**
		 * params
		 * @var string
		 */
		private $_params					= '';

		/**
		 * post back
		 * @var bool
		 */
		private $_handlePostBack			= false;

		/**
		 * args
		 * @var array
		 */
		private $_args						= array();


		/**
		 * @param  string		$dataField			field name
		 * @param  string		$pkey				primary key
		 * @param  string		$value				value of Control
		 * @param  string		$parameter			parameter
		 * @param  string		$headerText			header text
		 * @param  string		$footerText			footer text
		 * @param  string		$className			css class name
		 * @return void
		 */
		public function __construct( $dataField, $pkey, $parameter='', $headerText='', $footerText='', $className='' )
		{
			$this->parameter=$parameter?$parameter:str_replace(" ","_",$dataField);
			$this->pkey = $pkey;

			parent::__construct( $dataField, $headerText, '', $footerText, $className );

			$ajaxPostEvent='on'.ucwords(str_replace(" ","_",$this->parameter)).'AjaxPost';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $ajaxPostEvent))
			{
				$this->ajaxPostBack = true;
			}

			// event handling
			$this->events->add(new \System\UI\Events\GridViewColumnPostEvent());
			$this->events->add(new \System\UI\Events\GridViewColumnAjaxPostEvent());

			// default events
			$postEvent='on'.ucwords(str_replace(" ","_",$this->parameter)).'Post';
			if(\method_exists(\System\HTTPAppServlet::getInstance()->requestHandler, $postEvent))
			{
				$this->events->registerEventHandler(new \System\UI\Events\GridViewColumnPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $postEvent));
			}

			if($this->ajaxPostBack)
			{
				$this->events->registerEventHandler(new \System\UI\Events\GridViewColumnAjaxPostEventHandler('\System\HTTPAppServlet::getInstance()->requestHandler->' . $ajaxPostEvent));
			}
		}


		/**
		 * gets object property
		 *
		 * @param  string	$field		name of field
		 * @return string				string of variables
		 * @ignore
		 */
		public function __get( $field ) {
			if( $field === 'ajaxPostBack' ) {
				return $this->ajaxPostBack;
			}
			else {
				return parent::__get($field);
			}
		}


		/**
		 * sets object property
		 *
		 * @param  string	$field		name of field
		 * @param  mixed	$value		value of field
		 * @return mixed
		 * @ignore
		 */
		public function __set( $field, $value ) {
			if( $field === 'ajaxPostBack' ) {
				$this->ajaxPostBack = (bool)$value;
			}
			else {
				parent::__set( $field, $value );
			}
		}


		/**
		 * handle request events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		public function onRequest( &$request )
		{
			if( isset( $request[$this->parameter] ))
			{
				$this->_handlePostBack = true;
				$this->_args = $request;
				unset( $request[$this->parameter] );
			}
		}


		/**
		 * handle post events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		public function onPost( &$request )
		{
			if( $this->_handlePostBack )
			{
				$args = $request;

				if($this->ajaxPostBack)
				{
					\System\HTTPAppServlet::getInstance()->requestHandler->page->loadAjaxJScriptBuffer("");
					$this->events->raise(new \System\UI\Events\GridViewColumnAjaxPostEvent(), $this, $this->_args);
				}
				else
				{
					$this->events->raise(new \System\UI\Events\GridViewColumnPostEvent(), $this, $this->_args);
				}
			}
		}


		/**
		 * handle request events
		 *
		 * @param  array	&$request	request data
		 * @return void
		 */
		public function onRender()
		{
			foreach(\System\IO\HTTPRequest::$request as $key => $value)
			{
				if(!$this->_params)
				{
					$this->_params = \urlencode((string)$key)."=".\urlencode((string)$value);
				}
				else
				{
					$this->_params .= "&" . \urlencode((string)$key)."=".\urlencode((string)$value);
				}
			}

			$params = $this->_params . "&{$this->pkey}='.%{$this->pkey}%.'";
			$this->itemText = $this->getItemText($this->dataField, $this->parameter, $params);
		}


		/**
		 * get item text
		 *
		 * @param string $dataField
		 * @param string $parameter
		 * @param string $params
		 * @return string
		 */
		abstract protected function getItemText($dataField, $parameter, $params);
	}
?>