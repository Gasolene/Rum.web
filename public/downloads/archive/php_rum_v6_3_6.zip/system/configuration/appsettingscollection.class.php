<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace System\Configuration;
	use \System\Collections\StringDictionary;


	/**
	 * Represents a Collection of user-defined settings
	 * 
	 * @package			PHPRum
	 * @subpackage		Configuration
	 * @author			Darnell Shinbine
	 */
	final class AppSettingsCollection extends StringDictionary {}
?>