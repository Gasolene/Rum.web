<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Make;


	/**
	 * Provides functionality to generate a model file
	 * 
	 * @package			PHPRum
	 * @subpackage		Make
	 */
	class Model extends MakeBase
	{
		/**
		 * Default path to models folder
		 * @var string
		 */
		const SubNamespace			= '\\Data';

		/**
		 * Default path to models folder
		 * @var string
		 */
		const DefaultPath			= '/app/models';


		/**
		 * make
		 *
		 * @param string $target target
		 * @return void
		 */
		public function make($target)
		{
			$modelPath = \System\AppServlet::getInstance()->config->root . self::DefaultPath . '/' . $target . __CLASS_EXTENSION__;
			$modelTestCasePath = __UNIT_TESTS_PATH__ . '/' . strtolower($target . __TESTCASE_SUFFIX__) . __CLASS_EXTENSION__;
			$modelFixturePath = __FIXTURES_PATH__ . '/' . strtolower($target) . '.xml';

			$className = ucwords($target);
			$baseNamespace = RootNamespace;
			$namespace = RootNamespace . self::SubNamespace;
			$tableName = strtolower($target);

			if(\strpos($target, 's_id')!==0)
			{
				$primaryKey = str_replace('s_id', '_id', strtolower($target) . '_id');
			}
			elseif(\strpos($target, 'ies_id')!==0)
			{
				$primaryKey = str_replace('ies_id', '_id', strtolower($target) . '_id');
			}
			else
			{
				$primaryKey = strtolower($target) . '_id';
			}

			$modelTemplate = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/model.tpl");
			$modelTemplate = str_replace("<Namespace>", $namespace, $modelTemplate);
			$modelTemplate = str_replace("<ClassName>", $className, $modelTemplate);
			$modelTemplate = str_replace("<TableName>", $tableName, $modelTemplate);
			$modelTemplate = str_replace("<PrimaryKey>", $primaryKey, $modelTemplate);

			$modelTestCaseTemplate = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/modeltestcase.tpl");
			$modelTestCaseTemplate = str_replace("<Namespace>", $namespace, $modelTestCaseTemplate);
			$modelTestCaseTemplate = str_replace("<BaseNamespace>", $baseNamespace, $modelTestCaseTemplate);
			$modelTestCaseTemplate = str_replace("<ClassName>", $className, $modelTestCaseTemplate);
			$modelTestCaseTemplate = str_replace("<TableName>", $tableName, $modelTestCaseTemplate);
			$modelTestCaseTemplate = str_replace("<PrimaryKey>", $primaryKey, $modelTestCaseTemplate);
			$modelTestCaseTemplate = str_replace("<Fixture>", strtolower($className).'.xml', $modelTestCaseTemplate);

			$fixtureTemplate = $template = file_get_contents(\System\AppServlet::getInstance()->config->root . "/rum/make/templates/modelfixture.tpl");
			$fixtureTemplate = str_replace("<ClassName>", strtolower($className), $fixtureTemplate);

			$this->export($modelPath, $modelTemplate);
			$this->export($modelTestCasePath, $modelTestCaseTemplate);
			// $this->export($modelFixturePath, $fixtureTemplate);
		}
	}
?>