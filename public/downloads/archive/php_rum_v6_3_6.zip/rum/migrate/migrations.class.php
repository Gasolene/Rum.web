<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Migrate;


	/**
	 * Provides base functionality for database migration
	 *
	 * @package			PHPRum
	 * @subpackage		Migrate
	 * @author			Darnell Shinbine
	 */
	final class Migrations
	{
		/**
		 * migrations
		 * @var array
		 */
		static private $migrations = array();

		/**
		 * upgrade database
		 * @param int $toVersion optional version, defaults to latest version
		 * @return void
		 */
		public function upgrade($toVersion=null)
		{
			// default latest version
			$toVersion = !is_null($toVersion)?(int)$toVersion:$this->getLatestVersion();

			foreach($this->getMigrations() as $migration)
			{
				\System\AppServlet::getInstance()->dataAdapter->begin();

				if( $migration->version > $this->getCurrentVersion() &&
					$migration->version <= $toVersion)
				{
					echo "Upgrading to version {$migration->version}\n";
					$migration->up();

					// set version
					$this->setVersion($migration->version);
				}

				\System\AppServlet::getInstance()->dataAdapter->commit();
			}
		}

		/**
		 * downgrade database
		 * @param int $toVersion optional version, defaults to previous version
		 * @return void
		 */
		public function downgrade($toVersion=null)
		{
			// default previous version
			$toVersion=!is_null($toVersion)?(int)$toVersion:$this->getPreviousVersion();

			foreach(\array_reverse($this->getMigrations()) as $migration)
			{
				\System\AppServlet::getInstance()->dataAdapter->begin();

				if( $migration->version <= $this->getCurrentVersion() &&
					$migration->version > $toVersion)
				{
					echo "Downgrading from version {$migration->version}\n";
					$migration->down();
				}
				if( $migration->version <= $this->getCurrentVersion() &&
					$migration->version >= $toVersion)
				{
					$this->setVersion($migration->version);
				}

				\System\AppServlet::getInstance()->dataAdapter->commit();
			}
			if($toVersion==0)
			{
				$this->setVersion($toVersion);
			}
		}

		/**
		 * set database version
		 * @param int $toVersion version
		 * @return void
		 */
		public function to($toVersion)
		{
			if($toVersion || $toVersion===0)
			{
				if($toVersion < $this->getCurrentVersion())
				{
					$this->downgrade($toVersion);
				}
				elseif($toVersion > $this->getCurrentVersion())
				{
					$this->upgrade($toVersion);
				}
			}
		}

		/**
		 * get database version
		 * @return int
		 */
		public function getCurrentVersion()
		{
			try
			{
				$ds = \System\AppServlet::getInstance()->dataAdapter->openDataSet("SELECT `version` FROM `db_schema_version`");
				return $ds["version"];
			}
			catch (\System\Data\SQLException $e)
			{
				\System\AppServlet::getInstance()->dataAdapter->execute("CREATE TABLE db_schema_version (`version` INT NOT NULL)");
				\System\AppServlet::getInstance()->dataAdapter->execute("INSERT INTO db_schema_version (`version`) VALUES(0)");
				return 0;
			}
		}

		/**
		 * set version
		 * @param int $version version
		 */
		private function setVersion($version)
		{
			try
			{
				\System\AppServlet::getInstance()->dataAdapter->execute("UPDATE `db_schema_version` SET `version` = " . (int)$version);
			}
			catch (\System\Data\SQLException $e)
			{
				\System\AppServlet::getInstance()->dataAdapter->execute("CREATE TABLE `db_schema_version` (`version` INT NOT NULL)");
				\System\AppServlet::getInstance()->dataAdapter->execute("INSERT INTO `db_schema_version` (`version`) VALUES(".(int)$version."))");
			}
		}

		/**
		 * get latest version
		 * @return int
		 */
		private function getLatestVersion()
		{
			$migrations = $this->getMigrations();
			return $migrations[count($migrations)-1]->version;
		}

		/**
		 * get previous version
		 * @return int
		 */
		private function getPreviousVersion()
		{
			$migrations = $this->getMigrations();
			$current = false;
			foreach(\array_reverse($this->getMigrations()) as $migration)
			{
				if($current)
				{
					return $migration->version;
				}
				if($migration->version == $this->getCurrentVersion())
				{
					$current = true;
					continue;
				}
			}
			return 0;
		}

		/**
		 * get sorted array of MigrationBase objects
		 * @return array
		 */
		private function getMigrations()
		{
			if(self::$migrations)
			{
				return self::$migrations;
			}
			else
			{
				foreach(\System\Data\DataAdapter::create("adapter=dir;source=".__MIGRATIONS_PATH__.";")->openDataSet()->rows as $row)
				{
					if(\strpos($row["name"], '.php'))
					{
						require $row["path"];
						$migration = \str_replace(".php", "", $row["name"]);
						eval("\$migration = new \\Rum\\Migrate\\{$migration}();");

						self::$migrations[] = new $migration();
					}
				}

				$CSort = new MigrationCompare();
				usort( self::$migrations, array( &$CSort, 'compareVersion' ));
				return self::$migrations;
			}
		}
	}
?>