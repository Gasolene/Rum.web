<?php
	/**
	 * @license			see /docs/license.txt
	 * @package			PHPRum
	 * @author			Darnell Shinbine
	 * @copyright		Copyright (c) 2011
	 */
	namespace Rum\Migrate;


	/**
	 * Provides migration sorting
	 * 
	 * @package			PHPRum
	 * @subpackage		Migrate
	 * @author			Darnell Shinbine
	 */
	final class MigrationCompare
	{
		/**
		 * method compares version numbers
		 *
		 * @param  ints		$a			ints a
		 * @param  ints		$b			ints b
		 * @return int					compare result
		 */
		public function compareVersion($a, $b)
		{
			$n1 = (int)$a->version;
			$n2 = (int)$b->version;

			if ($n1 === $n2) return 0;
			else return ($n1 < $n2) ? -1 : 1;
		}
	}
?>