# pickadate.js


A lightweight jQuery dateinput picker


Demo: <http://amsul.github.com/pickadate.js>

Docs: <http://amsul.github.com/pickadate.js/docs.htm>


---

&copy; Amsul Naeem - Licensed under MIT ("expat" flavour) license.