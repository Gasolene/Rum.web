<!--//--><![CDATA[//><!--

	/**
	 * Initialize namespace
	 */
	var Mootools = {};

//--><!]]>