RSS plugin

Version 1.1 - 08.23.11

To Install...

	1. unpack the contents into the /app/plugins folder
