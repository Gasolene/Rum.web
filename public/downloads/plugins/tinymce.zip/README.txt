TinyMCE plugin 3.4.3.1

To Install...

	1. unpack the contents into the /app/plugins folder
	2. copy the assets into the /html/assets folder

Limitations:

	Can only have one instance per controller
