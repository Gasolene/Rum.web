<?php
	/**
	 * Make Configuration script
	 *
	 * Configure this script with your application details
	 *
	**/

	namespace System\Make;

	final class Config
	{
		/**
		 * root application namespace
		 * @var string
		 */
		const RootNamespace = 'MyBlog';
	}
?>