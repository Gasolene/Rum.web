<?php // this is the core application class

	namespace MyBlog;

	class MyBlog extends \System\Web\WebApplicationBase {}
?>