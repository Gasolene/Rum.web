<?php // handles all 404 errors

	namespace MyBlog\Controllers\Errors;

	class PageNotFound extends \MyBlog\ApplicationController {}
?>