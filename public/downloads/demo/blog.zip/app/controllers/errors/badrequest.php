<?php // handles all 400 errors

	namespace MyBlog\Controllers\Errors;

	class BadRequest extends \MyBlog\ApplicationController {}
?>