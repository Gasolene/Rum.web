<?php // handles all 500 errors

	namespace MyBlog\Controllers\Errors;

	class InternalError extends \MyBlog\ApplicationController {}
?>