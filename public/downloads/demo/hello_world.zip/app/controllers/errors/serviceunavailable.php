<?php
	/**
	 * @package MyApp
	 */
	namespace MyApp\Controllers\Errors;

	/**
	 * Handles all 503 errors
	 *
	 * @package			<Namespace>
	 */
	class ServiceunAvailable extends \MyApp\ApplicationController {}
?>