<?php
	/**
	 * @package MyApp
	 */
	namespace MyApp\Controllers\Errors;

	/**
	 * Handles all 400 errors
	 *
	 * @package			<Namespace>
	 */
	class BadRequest extends \MyApp\ApplicationController {}
?>