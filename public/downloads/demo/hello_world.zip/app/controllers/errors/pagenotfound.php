<?php
	/**
	 * @package MyApp
	 */
	namespace MyApp\Controllers\Errors;

	/**
	 * Handles all 404 errors
	 *
	 * @package			<Namespace>
	 */
	class PageNotFound extends \MyApp\ApplicationController {}
?>