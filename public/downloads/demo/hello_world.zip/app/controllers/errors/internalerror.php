<?php
	/**
	 * @package MyApp
	 */
	namespace MyApp\Controllers\Errors;

	/**
	 * Handles all 500 errors
	 *
	 * @package			<Namespace>
	 */
	class InternalError extends \MyApp\ApplicationController {}
?>