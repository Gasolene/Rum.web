<?php
	/**
	 * @package MyApp
	 */
	namespace MyApp\Controllers\Errors;

	/**
	 * Handles all 401 errors
	 *
	 * @package			<Namespace>
	 */
	class Unauthorized extends \MyApp\ApplicationController {}
?>