<?php // handles all 503 errors

	namespace MyBlog\Controllers\Errors;

	class ServiceunAvailable extends \MyBlog\ApplicationController {}
?>