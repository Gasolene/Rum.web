<?php // handles all 401 errors

	namespace MyBlog\Controllers\Errors;

	class Unauthorized extends \MyBlog\ApplicationController {}
?>